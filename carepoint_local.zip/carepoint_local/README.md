# CarePoint HMS - offline APK (doctor phone = server)
No Firebase, no internet. The doctor's phone stores all data and runs the server inside the app. Staff phones join the doctor's Wi-Fi/hotspot.
## Build the APK (GitHub, no installs)
Upload this folder to a GitHub repo -> Actions -> "Build APK" -> Run workflow -> download `carepoint-apk`.
(Local: `flutter create --platforms=android . && sh tools/patch_manifest.sh && flutter build apk --release`)
## First use
1. Doctor phone: install APK -> "Doctor's phone" -> name + password -> Create & start. Turn on hotspot (or join the clinic Wi-Fi). Keep the app open.
2. Doctor opens Staff & Codes: it shows the address (e.g. 192.168.43.1), creates staff IDs, makes reception codes, changes password.
3. Other phones: install APK -> "Staff phone" -> enter the address -> Connect.
4. Reception signs in with a NEW one-time code (15 min) from the doctor. Lab Technician / Lab Verifier / Pharmacy sign in with their permanent staff ID.
