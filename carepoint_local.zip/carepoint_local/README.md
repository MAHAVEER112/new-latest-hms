# CarePoint HMS - offline APK (doctor phone = server)
No Firebase, no internet. The doctor's phone stores all data and runs the server inside the app. Staff phones join the doctor's Wi-Fi/hotspot.
## Build the APK (GitHub, no installs)
Upload this folder to a GitHub repo -> Actions -> "Build APK" -> Run workflow -> download `carepoint-apk`.
(Local: `flutter create --platforms=android . && sh tools/patch_manifest.sh && flutter build apk --release`)
## First use
1. Doctor phone: install APK -> "Doctor's phone" -> name + password -> Create & start. Turn on hotspot (or join the clinic Wi-Fi). Keep the app open.
2. Doctor opens Staff & Codes: it shows the address (e.g. 192.168.43.1), creates staff IDs, makes reception codes, changes password.
3. Other phones: install APK -> "Staff phone" -> enter the address -> Connect.
4. Reception signs in with a NEW one-time code (15 min) from the doctor. Lab Technician / Lab Verifier / Pharmacy sign in with their permanent staff ID.

## Connecting phones with QR codes (doctor phone -> Staff & Codes -> "Connect phones (QR)")
- **Wi-Fi tab**: type the hotspot/Wi-Fi name and password once -> staff scan the QR with the phone camera (or "Scan QR" on the staff sign-in page) to join the network.
- **App tab**: QR with the doctor-phone address. Staff phone -> "Scan QR (optional)" on setup or sign-in connects automatically.
- **Web tab** ("Web page QR"): QR links to `/lab-portal`, `/reception-portal` and `/` (all pages). The web pages look and work like the app; use the browser's "Add to Home screen" to install them.

## Lab
Lab queue -> tap a patient (profile with every test the doctor ordered) -> tap a test (own page): Sample collected -> Start processing -> optional PDF + note -> **Complete**. Same flow in the app and on the web page.

## Look (v2)
Blue hospital theme in the app and on the web pages: header with logo, hospital name and bell, building picture, blue "Current patient" and "Payment History" cards. The hospital name is `_hospital` in `lib/screens/dashboard/dashboard_screen.dart` and `HOSP` in the two web pages.
Payments: "Payment History" on the dashboard opens Payments on the History tab with a back arrow; the Due / History switch is always visible.
