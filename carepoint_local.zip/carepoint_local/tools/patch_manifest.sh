#!/bin/sh
# Run after `flutter create --platforms=android .` : allows LAN (http) traffic + network permission.
M=android/app/src/main/AndroidManifest.xml
grep -q usesCleartextTraffic $M || sed -i 's/<application/<application android:usesCleartextTraffic="true"/' $M
grep -q 'permission.INTERNET' $M || sed -i 's#<application#<uses-permission android:name="android.permission.INTERNET"/>\n    <uses-permission android:name="android.permission.WAKE_LOCK"/>\n    <application#' $M

# Android lint crashes on release builds with some plugin/toolchain combinations: skip the "lintVital" release check.
mkdir -p "$HOME/.gradle/init.d"
cat > "$HOME/.gradle/init.d/nolint.gradle" <<'EOT'
allprojects {
    tasks.configureEach { t ->
        if (t.name.startsWith('lintVital')) { t.enabled = false }
    }
}
EOT

grep -q 'permission.CAMERA' $M || sed -i 's#<application#<uses-permission android:name="android.permission.CAMERA"/>\n    <application#' $M
cat > "$HOME/.gradle/init.d/sdk.gradle" <<'EOT'
allprojects {
    afterEvaluate { p ->
        def ext = p.extensions.findByName('android')
        if (ext != null) {
            try { if ((ext.compileSdk ?: 0) < 35) { ext.compileSdk = 35 } } catch (Throwable t) { }
        }
    }
}
EOT

# `flutter create` adds a sample test that refers to a "MyApp" class this project does not have; it breaks `flutter analyze`.
rm -rf test
