/// Home page of the doctor's phone (http://<doctor-ip>:8080/) plus the "install as app" files for the web pages.
const String appIconSvg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 192 192"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#4ba3f2"/><stop offset="1" stop-color="#0b4a9e"/></linearGradient></defs><rect width="192" height="192" rx="44" fill="url(#g)"/><rect x="82" y="42" width="28" height="108" rx="8" fill="#fff"/><rect x="42" y="82" width="108" height="28" rx="8" fill="#fff"/></svg>''';

String manifestFor(String name, String start) =>
    '{"name":"$name","short_name":"$name","start_url":"$start","scope":"/","display":"standalone","orientation":"portrait","background_color":"#f3f8ff","theme_color":"#0f62c9","icons":[{"src":"/icon.svg","sizes":"any","type":"image/svg+xml","purpose":"any"}]}';

const String launcherHtml = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0f62c9"><link rel="icon" href="/icon.svg">
<title>CarePoint</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:#0b2a55;min-height:100vh;background:radial-gradient(520px 380px at 0 0,#bfdbfe66,transparent),radial-gradient(620px 460px at 100% 38%,#93c5fd55,transparent),radial-gradient(520px 380px at 15% 100%,#bae6fd55,transparent),linear-gradient(135deg,#f3f8ff,#eaf3fe,#f4f9ff);background-attachment:fixed}
.app{max-width:480px;margin:0 auto;padding:36px 18px}
.glass{background:linear-gradient(135deg,#ffffff,#f5f9ff);border:1.4px solid #ffffffd9;border-radius:24px;box-shadow:8px 14px 28px #4a78b833,-3px -3px 8px #fffc}
.logo{width:68px;height:68px;border-radius:20px;display:block;margin:0 auto 10px;box-shadow:0 10px 20px #0f62c955}
h1{text-align:center;margin:0;font-size:28px}.sub{text-align:center;color:#5b6b86;margin:6px 0 26px}
a.tile{display:flex;align-items:center;gap:14px;padding:16px;margin-bottom:14px;text-decoration:none;color:inherit}
.ico{width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:26px;border:1.2px solid #fffd;flex:none}
.tile b{font-size:19px;display:block}.tile small{color:#5b6b86}.go{margin-left:auto;color:#999;font-size:26px}
.note{text-align:center;color:#5b6b86;font-size:13px;margin-top:22px}
</style></head><body><div class="app">
<img class="logo" src="/icon.svg" alt="">
<h1>CarePoint HMS</h1><p class="sub">Choose your page</p>
<a class="glass tile" href="/lab-portal"><div class="ico" style="background:#e0f2fe">&#128300;</div><div><b>Lab</b><small>Tests ordered by the doctor</small></div><span class="go">&rsaquo;</span></a>
<a class="glass tile" href="/reception-portal"><div class="ico" style="background:#e0ecff">&#128203;</div><div><b>Reception</b><small>Check-in, queue and payments</small></div><span class="go">&rsaquo;</span></a>
<p class="note">Tip: open the menu of your browser and choose <b>Add to Home screen</b> to use this page like an app.</p>
</div></body></html>
''';
