import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as pth;
import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;
import 'package:shelf_router/shelf_router.dart';
import 'backup.dart';
import 'files.dart';
import 'launcher.dart';
import 'lab_portal.dart';
import 'reception_portal.dart';
import 'store.dart';

class Err implements Exception {
  Err(this.m, [this.s = 400]);
  final String m;
  final int s;
}

const kPort = 8080;
const D = 'doctor', R = 'receptionist', T = 'lab_technician', V = 'lab_verifier', P = 'pharmacy';
const ALL = [D, R, T, V, P];
final _rnd = Random.secure();

String str(Object? v, [int max = 500]) { final s = '${v ?? ''}'; return s.length > max ? s.substring(0, max) : s; }
String need(Object? v, String m) { final s = '${v ?? ''}'.trim(); if (s.isEmpty) throw Err(m); return s; }
String _sha(String s) => sha256.convert(utf8.encode(s)).toString();
String _pw(String pw, String salt) { List<int> h = utf8.encode('$salt:$pw'); for (var i = 0; i < 20000; i++) { h = sha256.convert(h).bytes; } return base64Url.encode(h); }
String _tok() => base64Url.encode(List.generate(32, (_) => _rnd.nextInt(256))).replaceAll('=', '');
String _today() { final n = DateTime.now(); return '${n.year}${n.month.toString().padLeft(2, '0')}${n.day.toString().padLeft(2, '0')}'; }
bool isToday(String iso) { final d = DateTime.parse(iso).toLocal(), n = DateTime.now(); return d.year == n.year && d.month == n.month && d.day == n.day; }
bool _loop(Request r) => (r.context['shelf.io.connection_info'] as HttpConnectionInfo?)?.remoteAddress.isLoopback == true;

/// The doctor's phone runs this REST server; every record is stored on the doctor's phone.
class LocalServer {
  LocalServer._();
  static final i = LocalServer._();
  final st = Store();
  HttpServer? _srv;
  Timer? _timer;
  final _fails = <String, List<DateTime>>{};

  Future<void> start() async {
    if (_srv != null) return;
    await st.open();
    BackupService.autoIfDue(st).catchError((_) {});
    _srv = await io.serve(_router().call, InternetAddress.anyIPv4, kPort);
    _timer = Timer.periodic(const Duration(minutes: 15), (_) { _remind(); BackupService.autoIfDue(st).catchError((_) {}); });
  }

  Future<List<String>> addresses() async => [
        for (final n in await NetworkInterface.list(type: InternetAddressType.IPv4))
          for (final a in n.addresses) if (!a.isLoopback) a.address
      ];

  Map<String, dynamic> _pub(Map u) => {'id': u['id'], 'email': u['staffId'] ?? '', 'name': u['name'], 'role': u['role'], 'orgId': 'local'};
  Map<String, dynamic> _session(Map u) {
    final t = _tok();
    st.put('sessions', {'tokenHash': _sha(t), 'userId': u['id'], 'expires': DateTime.now().toUtc().add(const Duration(hours: 12)).toIso8601String()});
    return {'token': t, 'user': _pub(u)};
  }
  void _audit(Map u, String action, [Map<String, dynamic> d = const {}]) => st.put('audit', {'actorUid': u['id'], 'actorName': u['name'], 'action': action, 'details': d});

  Map<String, dynamic> _authUser(Request req, List<String> roles) {
    final tok = (req.headers['authorization'] ?? '').replaceFirst('Bearer ', '');
    final s = tok.isEmpty ? [] : st.list('sessions', {'tokenHash': _sha(tok)}, 'createdAt', true, 1);
    if (s.isEmpty || DateTime.parse(s.first['expires']).isBefore(DateTime.now().toUtc())) throw Err('Please sign in again', 401);
    final user = st.get('users', s.first['userId']);
    if (user == null || user['active'] != true) throw Err('Account disabled', 401);
    if (roles.isNotEmpty && !roles.contains(user['role'])) throw Err('Not allowed for your role', 403);
    return user;
  }

  Future<Response> _run(Request req, List<String> roles, FutureOr<Object?> Function(Map<String, dynamic> u, Map<String, dynamic> b, Request r) fn, {bool open = false}) async {
    const h = {'content-type': 'application/json'};
    try {
      final u = open ? <String, dynamic>{} : _authUser(req, roles);
      var b = <String, dynamic>{};
      if (req.method != 'GET') {
        final t = await req.readAsString();
        if (t.isNotEmpty) b = Map<String, dynamic>.from(jsonDecode(t) as Map);
      }
      return Response.ok(jsonEncode(await fn(u, b, req)), headers: h);
    } on Err catch (e) {
      return Response(e.s, body: jsonEncode({'error': e.m}), headers: h);
    } catch (e) {
      stderr.writeln(e);
      return Response(500, body: jsonEncode({'error': 'Server error'}), headers: h);
    }
  }

  String _staffId(String role) {
    final pre = {T: 'LABT', V: 'LABV', P: 'PHARM'}[role]!;
    while (true) {
      final id = '$pre-${100000 + _rnd.nextInt(900000)}';
      if (st.count('users', {'staffId': id}) == 0) return id;
    }
  }

  Router _router() {
    final r = Router();
    String labInfo(Map e) {
      if (e['labReady'] == 1) return ' · report ready';
      final t = DateTime.tryParse('${e['labReadyBy']}');
      if (t == null) return '';
      final m = t.difference(DateTime.now().toUtc()).inMinutes;
      return m > 0 ? ' · back in $m min' : ' · overdue ${-m} min';
    }
    num feeNow() {
      final f = st.list('settings', {'key': 'fee'}, 'createdAt', true, 1);
      return f.isEmpty ? 0 : (f.first['value'] as num);
    }
    num collectedToday() => st.list('payments', {'status': 'paid'}, 'paidAt', true, 1000).where((x) => isToday('${x['paidAt']}')).fold<num>(0, (a, x) => a + (x['amount'] as num));
    String two(int n) => n.toString().padLeft(2, '0');
    String timeOf(String iso) { final d = DateTime.parse(iso).toLocal(); return '${two(d.hour)}:${two(d.minute)}'; }
    String waited(Map e) { final t = DateTime.tryParse('${e['checkedInAt']}'); return t == null ? '' : ' · waiting ${DateTime.now().toUtc().difference(t).inMinutes} min'; }
    List<Map<String, dynamic>> apptsToday() => st.list('appointments', {'status': 'scheduled'}, 'dateTime', false).where((a) => isToday('${a['dateTime']}')).toList();
    Map<String, dynamic>? current() {
      final t = {'dateKey': _today()};
      final a = st.list('queueEntries', {...t, 'status': 'in_consultation'}, 'tokenNumber', false, 1);
      if (a.isNotEmpty) return a.first;
      final c = st.list('queueEntries', {...t, 'status': 'called'}, 'tokenNumber', false, 1);
      return c.isEmpty ? null : c.first;
    }
    Handler h(List<String> roles, Object? Function(Map<String, dynamic>, Map<String, dynamic>, Request) fn, {bool open = false}) =>
        (Request q) => _run(q, roles, fn, open: open);

    r.get('/lab-portal', (Request q) => Response.ok(labPortalHtml, headers: {'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store'}));
    r.get('/', (Request q) => Response.ok(launcherHtml, headers: {'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store'}));
    r.get('/icon.svg', (Request q) => Response.ok(appIconSvg, headers: {'content-type': 'image/svg+xml', 'cache-control': 'max-age=86400'}));
    r.get('/lab.webmanifest', (Request q) => Response.ok(manifestFor('CarePoint Lab', '/lab-portal'), headers: {'content-type': 'application/manifest+json'}));
    r.get('/reception.webmanifest', (Request q) => Response.ok(manifestFor('CarePoint Reception', '/reception-portal'), headers: {'content-type': 'application/manifest+json'}));
    r.get('/reception-portal', (Request q) => Response.ok(receptionPortalHtml, headers: {'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store'}));
    r.get('/status', h([], (u, b, q) => {'app': 'carepoint', 'setup': st.count('users', {'role': D}) > 0}, open: true));

    r.post('/setup', h([], (u, b, q) {
      if (!_loop(q)) throw Err('Setup must be done on the doctor phone', 403);
      if (st.count('users', {'role': D}) > 0) throw Err('Already set up', 409);
      final pw = str(b['password'], 200);
      if (pw.length < 8) throw Err('Password must be at least 8 characters');
      final salt = _tok();
      st.put('users', {'role': D, 'name': need(b['name'], 'Name required'), 'staffId': 'DOCTOR', 'active': true, 'salt': salt, 'pass': _pw(pw, salt)});
      return {'ok': true};
    }, open: true));

    r.post('/auth/login', h([], (u, b, q) {
      final id = str(b['id'], 40).trim(), secret = str(b['secret'], 200).trim(), low = id.toLowerCase();
      final key = (low == 'doctor' || low == 'reception') ? low : 'staff';
      final cut = DateTime.now().subtract(const Duration(minutes: 10));
      final f = (_fails[key] ??= [])..removeWhere((t) => t.isBefore(cut));
      if (f.length >= 8) throw Err('Too many failed attempts. Try again in a few minutes.', 429);
      Never fail(String m) { f.add(DateTime.now()); throw Err(m, 401); }
      if (low == 'doctor') {
        if (!_loop(q)) throw Err('Doctor login is only available on the doctor phone', 403);
        final d = st.list('users', {'role': D}, 'createdAt', false, 1);
        if (d.isEmpty || _pw(secret, d.first['salt']) != d.first['pass']) fail('Wrong password');
        return _session(d.first);
      }
      if (low == 'reception') {
        final c = st.list('codes', {'hash': _sha(secret.toUpperCase()), 'used': false}, 'createdAt', true, 1);
        if (c.isEmpty || DateTime.parse(c.first['expires']).isBefore(DateTime.now().toUtc())) fail('Invalid or expired code');
        st.patch('codes', c.first['id'], {'used': true});
        final rc = st.list('users', {'role': R}, 'createdAt', false, 1);
        final ru = rc.isEmpty ? st.get('users', st.put('users', {'role': R, 'name': 'Reception', 'staffId': 'RECEPTION', 'active': true}))! : rc.first;
        if (ru['active'] != true) throw Err('Reception access is disabled', 403);
        return _session(ru);
      }
      final s = st.list('users', {'staffId': id.toUpperCase(), 'active': true}, 'createdAt', true, 1);
      if (s.isEmpty || ![T, P].contains(s.first['role'])) fail('Unknown staff ID');
      return _session(s.first);
    }, open: true));

    r.get('/auth/me', h(ALL, (u, b, q) => _pub(u)));

    // ----- Doctor: codes, staff IDs, password -----
    r.post('/doctor/reception-code', h([D], (u, b, q) {
      const a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
      final code = List.generate(8, (_) => a[_rnd.nextInt(a.length)]).join();
      st.put('codes', {'hash': _sha(code), 'used': false, 'expires': DateTime.now().toUtc().add(const Duration(minutes: 15)).toIso8601String()});
      _audit(u, 'reception.code');
      return {'code': code};
    }));
    r.post('/doctor/password', h([D], (u, b, q) {
      if (_pw(str(b['oldPassword'], 200), u['salt']) != u['pass']) throw Err('Current password is wrong', 403);
      final n = str(b['newPassword'], 200);
      if (n.length < 8) throw Err('New password must be at least 8 characters');
      final salt = _tok();
      st.patch('users', u['id'], {'salt': salt, 'pass': _pw(n, salt)});
      _audit(u, 'doctor.password');
      return {'ok': true};
    }));
    r.get('/users', h([D], (u, b, q) => [
          for (final x in st.list('users', {}, 'createdAt', false)) if (x['role'] != D)
            {'id': x['id'], 'displayName': x['name'], 'staffId': x['staffId'], 'role': x['role'], 'active': x['active'] == true}
        ]));
    r.post('/users', h([D], (u, b, q) {
      final role = b['role'];
      if (![T, P].contains(role)) throw Err('Invalid role');
      final sid = _staffId(role as String);
      st.put('users', {'role': role, 'name': need(b['name'], 'Name required'), 'staffId': sid, 'active': true});
      _audit(u, 'staff.create', {'role': role});
      return {'staffId': sid};
    }));
    r.patch('/users/<id>/active', (Request q, String id) => _run(q, [D], (u, b, rq) {
      final x = st.get('users', id);
      if (x == null || x['role'] == D) throw Err('User not found', 404);
      st.patch('users', id, {'active': b['active'] == true});
      _audit(u, b['active'] == true ? 'staff.enable' : 'staff.disable', {'userId': id});
      return {'ok': true};
    }));
    r.post('/users/<id>/regenerate', (Request q, String id) => _run(q, [D], (u, b, rq) {
      final x = st.get('users', id);
      if (x == null || ![T, P].contains(x['role'])) throw Err('User not found', 404);
      final sid = _staffId(x['role'] as String);
      st.patch('users', id, {'staffId': sid});
      _audit(u, 'staff.regenerate', {'userId': id});
      return {'staffId': sid};
    }));
    r.get('/audit', h([D], (u, b, q) => st.list('audit', {}, 'createdAt', true, 50)));
    r.get('/notifications', h(ALL, (u, b, q) => st.list('notifications', {'forRole': [u['role']]}, 'createdAt', true, 20)));
    r.get('/reports/revenue', h([D], (u, b, q) {
      final paid = st.list('invoices', {'status': 'paid'}, 'createdAt', true, 5000);
      return {'total': paid.fold<num>(0, (a, i) => a + (i['total'] as num)), 'count': paid.length};
    }));
    r.get('/stats', h([D, R], (u, b, q) {
      final t = {'dateKey': _today()};
      final cur = current();
      final out = <Map<String, Object?>>[
        {'key': 'current', 'label': 'Current patient', 'value': cur?['patientName'] ?? '',
          'sub': cur == null ? '' : 'Token #${cur['tokenNumber']} · ${cur['status'] == 'called' ? 'Called' : 'In consultation'}',
          'callKey': (cur != null && cur['status'] == 'called') ? '${cur['id']}|${cur['calledAt'] ?? cur['updatedAt']}' : ''},
        {'key': 'waiting', 'label': 'Waiting now', 'value': st.count('queueEntries', {...t, 'status': 'waiting'})},
        {'key': 'in_lab', 'label': 'In lab', 'value': st.count('queueEntries', {...t, 'status': 'in_lab'})},
        {'key': 'in_consultation', 'label': 'In consultation', 'value': st.count('queueEntries', {...t, 'status': 'in_consultation'})},
        {'key': 'completed', 'label': 'Completed today', 'value': st.count('queueEntries', {...t, 'status': 'completed'})},
        {'key': 'appointments', 'label': 'Appointments today', 'value': apptsToday().length},
        {'key': 'payments', 'label': 'Payments due', 'value': st.count('payments', {'status': 'due'})},
        {'key': 'collected', 'label': 'Collected today', 'value': collectedToday()},
      ];
      if (u['role'] == D) {
        out.addAll([
          {'key': 'reviews', 'label': 'Lab reports ready', 'value': st.count('doctorReviews', {'status': 'pending'})},
          {'key': 'lab', 'label': 'Lab tests in progress', 'value': st.count('labResults', {'status': ['ordered', 'collected', 'processing']})},
        ]);
      }
      return out;
    }));

    r.get('/dashboard/<key>', (Request q, String key) => _run(q, [D, R], (u, b, rq) {
      final t = {'dateKey': _today()};
      Map<String, dynamic> row(String badge, String title, String sub, [String tag = '']) => {'badge': badge, 'title': title, 'sub': sub, 'tag': tag};
      if (key == 'current' || ['waiting', 'in_lab', 'in_consultation', 'completed', 'skipped'].contains(key)) {
        final statuses = key == 'current' ? ['in_consultation', 'called'] : [key];
        return [
          for (final e in st.list('queueEntries', {...t, 'status': statuses}, 'tokenNumber', false))
            row('${e['tokenNumber']}', '${e['patientName']}', '${e['patientId']}${e['status'] == 'waiting' ? waited(e) : e['status'] == 'in_lab' ? labInfo(e) : ''}', '${e['status']}'.replaceAll('_', ' '))
        ];
      }
      if (key == 'payments') {
        return [for (final x in st.list('payments', {'status': 'due'}, 'createdAt', false, 200)) row(x['queueToken'] == null ? '' : '${x['queueToken']}', '${x['patientName']}', '${x['description']} · ₹${x['amount']}', 'due')];
      }
      if (key == 'collected') {
        return [for (final x in st.list('payments', {'status': 'paid'}, 'paidAt', true, 500).where((x) => isToday('${x['paidAt']}'))) row('', '${x['patientName']}', '₹${x['amount']} · ${x['method']} · by ${x['collectedByName']}', 'paid')];
      }
      if (key == 'appointments') {
        return [for (final a in apptsToday()) row(timeOf('${a['dateTime']}'), '${a['patientName']}', '${a['patientId']} · ${a['reason']}')];
      }
      if (u['role'] != D) throw Err('Not allowed', 403);
      if (key == 'reviews') {
        return [for (final x in st.list('doctorReviews', {'status': 'pending'})) row('', '${x['patientName']}', 'Lab reports ready for your review')];
      }
      if (key == 'lab') {
        return [for (final x in st.list('labResults', {'status': ['ordered', 'collected', 'processing']}, 'createdAt', true, 100)) row('', '${x['patientName']}', '${x['testName']}', '${x['status']}')];
      }
      throw Err('Unknown section', 404);
    }));

    // ----- Patients & queue -----
    r.get('/patients', h(ALL, (u, b, q) {
      final pid = q.url.queryParameters['pid'], s = (q.url.queryParameters['q'] ?? '').trim().toLowerCase();
      if (pid != null && pid.isNotEmpty) return st.list('patients', {'patientId': pid.trim().toUpperCase()}, 'createdAt', true, 1);
      return st.list('patients', s.isEmpty ? {} : {'nameLower': Prefix(s)}, 'nameLower', false, 30);
    }));
    r.post('/patients', h([R, D], (u, b, q) {
      final name = need(b['name'], 'Name required'), phone = need(b['phone'], 'Phone required'), age = int.tryParse('${b['age']}');
      if (age == null || age < 0 || age > 120) throw Err('Age must be 0-120');
      final pid = 'CP-${st.nextVal('patient').toString().padLeft(6, '0')}';
      st.put('patients', {'patientId': pid, 'name': str(name, 120), 'nameLower': str(name, 120).toLowerCase(), 'phone': str(phone, 30),
        'gender': ['Female', 'Male', 'Other'].contains(b['gender']) ? b['gender'] : 'Other', 'age': age, 'allergies': str(b['allergies'], 300)});
      _audit(u, 'patient.register', {'patientId': pid});
      return {'patientId': pid};
    }));
    r.get('/patients/<id>/history', (Request q, String id) => _run(q, [D], (u, b, rq) {
      final pt = st.get('patients', id);
      if (pt == null) throw Err('Patient not found', 404);
      final visits = <Map<String, dynamic>>[];
      for (final c in st.list('consultations', {'patientDocId': id}, 'createdAt', true, 100)) {
        final rx = st.list('prescriptions', {'consultationId': c['id']}, 'createdAt', true, 1);
        final oid = c['labOrderId'];
        final labs = oid == null ? <Map<String, dynamic>>[] : st.list('labResults', {'orderId': oid}, 'createdAt', false, 100);
        final rv = oid == null ? <Map<String, dynamic>>[] : st.list('doctorReviews', {'orderId': oid}, 'createdAt', true, 1);
        visits.add({
          'id': c['id'], 'date': c['createdAt'], 'vitals': c['vitals'], 'complaint': c['chiefComplaint'], 'symptoms': c['symptoms'],
          'diagnosis': c['diagnosis'], 'observations': c['observations'], 'notes': c['notes'], 'plan': c['treatmentPlan'],
          'meds': rx.isEmpty ? [] : rx.first['items'],
          'labs': [for (final l in labs) {'id': l['id'], 'test': l['testName'], 'status': l['status'], 'notes': l['result'], 'hasReport': l['hasReport'] == 1}],
          'review': rv.isEmpty ? null : {'status': rv.first['status'], 'interpretation': rv.first['interpretation'], 'comments': rv.first['comments']},
        });
      }
      return {'patient': {'name': pt['name'], 'patientId': pt['patientId'], 'age': pt['age'], 'gender': pt['gender'], 'allergies': pt['allergies'], 'phone': pt['phone']}, 'visits': visits};
    }));
    r.get('/queue', h([D, R], (u, b, q) => st.list('queueEntries', {'dateKey': _today()}, 'tokenNumber', false)));
    r.post('/queue/checkin', h([R], (u, b, q) {
      final p = st.get('patients', b['patientDocId']);
      if (p == null) throw Err('Patient not found', 404);
      final k = _today();
      if (st.count('queueEntries', {'dateKey': k, 'patientDocId': p['id'], 'status': ['waiting', 'called', 'in_consultation']}) > 0) throw Err('Patient is already in the queue', 409);
      final token = st.nextVal('token:$k');
      st.put('queueEntries', {'dateKey': k, 'tokenNumber': token, 'patientDocId': p['id'], 'patientName': p['name'], 'patientId': p['patientId'], 'status': 'waiting', 'checkedInAt': st.now()});
      st.put('payments', {'patientDocId': p['id'], 'patientName': p['name'], 'patientId': p['patientId'], 'queueToken': token, 'dateKey': k,
        'description': 'Consultation fee', 'amount': feeNow(), 'status': 'due'});
      return {'token': token};
    }));
    r.patch('/queue/<id>', (Request q, String id) => _run(q, [D], (u, b, rq) {
      if (!['waiting', 'called', 'in_consultation', 'completed', 'skipped'].contains(b['status'])) throw Err('Invalid status');
      if (st.patch('queueEntries', id, {'status': b['status'], if (b['status'] == 'called') 'calledAt': DateTime.now().toUtc().toIso8601String()}) == null) throw Err('Not found', 404);
      return {'ok': true};
    }));

    // ----- Consultation -----
    r.post('/consultations', h([D], (u, b, q) {
      final qe = st.get('queueEntries', b['queueId']);
      if (qe == null) throw Err('Queue entry not found', 404);
      final c = Map<String, dynamic>.from(b['clinical'] as Map? ?? {});
      need(c['chiefComplaint'], 'Chief complaint required');
      need(c['diagnosis'], 'Diagnosis required');
      const keys = ['name', 'dosage', 'frequency', 'duration', 'quantity', 'instructions', 'food', 'timing'];
      final meds = [for (final m in (b['meds'] as List? ?? []).take(30)) {for (final k in keys) k: str((m as Map)[k], 200)}];
      final tests = [for (final t in (b['tests'] as List? ?? []).take(30)) str(t, 80)];
      final pr = b['priority'] == 'urgent' ? 'urgent' : 'routine';
      final cid = st.put('consultations', {'doctorId': u['id'], 'queueEntryId': qe['id'], 'patientDocId': qe['patientDocId'], 'patientName': qe['patientName'],
        'vitals': (b['vitals'] as Map? ?? {}).map((k, v) => MapEntry(str(k, 20), str(v, 30))),
        ...c.map((k, v) => MapEntry(str(k, 30), str(v, 2000)))});
      if (meds.isNotEmpty) st.put('prescriptions', {'doctorId': u['id'], 'consultationId': cid, 'patientDocId': qe['patientDocId'], 'patientName': qe['patientName'], 'items': meds, 'status': 'approved'});
      var done = true;
      if (tests.isNotEmpty) {
        final mins = (int.tryParse('${b['labMinutes']}') ?? 30).clamp(5, 480).toInt();
        final oid = st.put('labOrders', {'patientDocId': qe['patientDocId'], 'patientName': qe['patientName'], 'queueEntryId': qe['id'], 'queueToken': qe['tokenNumber'],
          'tests': tests, 'priority': pr, 'notes': str(b['labNotes'], 1000), 'status': 'open'});
        for (final t in tests) {
          st.put('labResults', {'orderId': oid, 'testName': t, 'status': 'ordered', 'priority': pr, 'queueToken': qe['tokenNumber'],
            'patientDocId': qe['patientDocId'], 'patientName': qe['patientName'], 'doctorId': u['id']});
        }
        st.patch('consultations', cid, {'labOrderId': oid});
        st.patch('queueEntries', qe['id'], {'status': 'in_lab', 'labOrderId': oid, 'labReady': 0, 'labMinutes': mins,
          'labReadyBy': DateTime.now().toUtc().add(Duration(minutes: mins)).toIso8601String()});
        done = false;
      }
      if (done) st.patch('queueEntries', qe['id'], {'status': 'completed'});
      _audit(u, 'consultation.save', {'patientId': qe['patientId']});
      return {'ok': true};
    }));

    // ----- Lab: own queue, PDF report goes straight to the doctor -----
    r.get('/lab', h([D, T], (u, b, q) {
      final l = st.list('labResults', {'status': (q.url.queryParameters['status'] ?? '').split(',').where((s) => s.isNotEmpty).toList()}, 'createdAt', false, 200);
      l.sort((a, c) {
        final pa = a['priority'] == 'urgent' ? 0 : 1, pb = c['priority'] == 'urgent' ? 0 : 1;
        return pa != pb ? pa.compareTo(pb) : '${a['createdAt']}'.compareTo('${c['createdAt']}');
      });
      l.removeWhere((x) => x['status'] == 'submitted' && (x['submittedAt'] == null || !isToday('${x['submittedAt']}')));
      return [for (final x in l) {...x, 'orderNotes': str(st.get('labOrders', x['orderId'])?['notes'], 1000)}];
    }));
    r.patch('/lab/<id>', (Request q, String id) => _run(q, [T], (u, b, rq) {
      final x = st.get('labResults', id);
      if (x == null) throw Err('Not found', 404);
      if (!['ordered', 'collected', 'processing'].contains(x['status'])) throw Err('Report already sent', 409);
      if (!['collected', 'processing'].contains(b['status'])) throw Err('Invalid status');
      st.patch('labResults', id, {'status': b['status'], 'technicianId': u['id'], 'technicianName': u['name']});
      return {'ok': true};
    }));
    r.post('/lab/<id>/complete', (Request q, String id) => _run(q, [T], (u, b, rq) async {
      final x = st.get('labResults', id);
      if (x == null) throw Err('Not found', 404);
      if (x['status'] == 'submitted') throw Err('Already completed', 409);
      final f = <String, dynamic>{'status': 'submitted', 'technicianId': u['id'], 'technicianName': u['name'], 'result': str(b['notes'], 4000), 'hasReport': 0, 'submittedAt': st.now()};
      final data = str(b['data'], 25000000);
      if (data.isNotEmpty) {
        List<int> bytes;
        try { bytes = base64Decode(data); } catch (_) { throw Err('Invalid file'); }
        if (bytes.length > 15 * 1024 * 1024) throw Err('PDF is larger than 15 MB');
        if (bytes.length < 5 || String.fromCharCodes(bytes.take(4)) != '%PDF') throw Err('That file is not a PDF');
        final name = '$id.pdf';
        await File(pth.join((await reportsDir()).path, name)).writeAsBytes(bytes);
        f['reportFile'] = name;
        f['reportName'] = str(b['name'], 120);
        f['hasReport'] = 1;
      }
      st.patch('labResults', id, f);
      final all = st.list('labResults', {'orderId': x['orderId']}, 'createdAt', true, 100);
      if (all.every((e) => e['status'] == 'submitted')) {
        st.patch('labOrders', x['orderId'], {'status': 'ready'});
        final o = st.get('labOrders', x['orderId']);
        if (o != null && o['queueEntryId'] != null) st.patch('queueEntries', o['queueEntryId'], {'labReady': 1});
        if (st.count('doctorReviews', {'orderId': x['orderId']}) == 0) {
          st.put('doctorReviews', {'orderId': x['orderId'], 'patientDocId': x['patientDocId'], 'patientName': x['patientName'], 'doctorId': x['doctorId'], 'status': 'pending'});
          st.put('notifications', {'forRole': D, 'title': 'Lab report ready', 'body': 'A lab report is ready for review.'});
        }
      }
      _audit(u, 'lab.complete', {'resultId': id});
      return {'ok': true};
    }));
    r.get('/lab/<id>/report', (Request q, String id) async {
      const h = {'content-type': 'application/json'};
      try {
        _authUser(q, [D]);
        final x = st.get('labResults', id);
        if (x == null || x['reportFile'] == null) throw Err('No report', 404);
        final f = File(pth.join((await reportsDir()).path, '${x['reportFile']}'));
        if (!await f.exists()) throw Err('Report file is missing', 404);
        return Response.ok(await f.readAsBytes(), headers: {'content-type': 'application/pdf'});
      } on Err catch (e) {
        return Response(e.s, body: jsonEncode({'error': e.m}), headers: h);
      }
    });

    r.get('/reviews', h([D], (u, b, q) => st.list('doctorReviews', {'status': 'pending'})));
    r.get('/reviews/order/<oid>/results', (Request q, String oid) => _run(q, [D], (u, b, rq) => st.list('labResults', {'orderId': oid}, 'createdAt', true, 100)));
    r.patch('/reviews/<id>', (Request q, String id) => _run(q, [D], (u, b, rq) {
      final rv = st.get('doctorReviews', id);
      if (rv == null || rv['status'] != 'pending') throw Err('Review not available', 404);
      st.patch('doctorReviews', id, {'status': 'completed', 'interpretation': str(need(b['interpretation'], 'Interpretation required'), 4000),
        'comments': str(b['comments'], 2000), 'followUpDate': b['followUp'], 'reviewedAt': st.now()});
      final ro = st.get('labOrders', rv['orderId']);
      if (ro != null && ro['queueEntryId'] != null) st.patch('queueEntries', ro['queueEntryId'], {'status': 'completed'});
      return {'ok': true};
    }));

    // ----- Pharmacy -----
    r.get('/prescriptions', h([P, D], (u, b, q) => st.list('prescriptions', {}, 'createdAt', true, 50)));
    r.get('/prescriptions/<id>/dispensed', (Request q, String id) => _run(q, [P], (u, b, rq) => st.list('dispensingRecords', {'prescriptionId': id}, 'createdAt', true, 500)));
    r.get('/inventory', h([P, D], (u, b, q) => st.list('inventory', {}, 'createdAt', true, 300)));
    r.post('/inventory', h([P], (u, b, q) {
      final stock = int.tryParse('${b['stock']}'), price = num.tryParse('${b['price']}'), exp = DateTime.tryParse('${b['expiry']}');
      if (stock == null || stock <= 0 || price == null || price < 0 || exp == null) throw Err('Invalid stock, price or expiry');
      final name = str(need(b['name'], 'Name required'), 120);
      st.put('inventory', {'name': name, 'nameLower': name.toLowerCase(), 'batch': str(need(b['batch'], 'Batch required'), 60), 'expiry': exp.toUtc().toIso8601String(), 'stock': stock, 'price': price});
      return {'ok': true};
    }));
    r.post('/prescriptions/<id>/dispense', (Request q, String id) => _run(q, [P], (u, b, rq) {
      final rx = st.get('prescriptions', id);
      if (rx == null) throw Err('Prescription not found', 404);
      final lines = [for (final l in (b['lines'] as List? ?? [])) (str((l as Map)['name']), int.tryParse('${l['qty']}') ?? 0)].where((l) => l.$2 > 0).toList();
      if (lines.isEmpty) throw Err('Nothing to dispense');
      final done = <String, int>{};
      for (final d in st.list('dispensingRecords', {'prescriptionId': id}, 'createdAt', true, 1000)) { done['${d['medicine']}'] = (done['${d['medicine']}'] ?? 0) + (d['qty'] as int); }
      final reserved = <String, int>{};
      final plan = <(Map<String, dynamic>, String, int)>[];
      for (final (name, qty) in lines) {
        final item = (rx['items'] as List).cast<Map>().where((i) => i['name'] == name).firstOrNull;
        if (item == null) throw Err('$name is not on this prescription');
        final left = (int.tryParse('${item['quantity']}') ?? 1) - (done[name] ?? 0);
        if (qty > left) throw Err('$name: only $left left to dispense');
        final cands = st.list('inventory', {'nameLower': name.toLowerCase()}).where((x) => DateTime.parse(x['expiry']).isAfter(DateTime.now().toUtc()) && (x['stock'] as int) - (reserved[x['id']] ?? 0) >= qty).toList()
          ..sort((a, c) => '${a['expiry']}'.compareTo('${c['expiry']}'));
        if (cands.isEmpty) throw Err('Insufficient unexpired stock for $name', 409);
        reserved[cands.first['id']] = (reserved[cands.first['id']] ?? 0) + qty;
        done[name] = (done[name] ?? 0) + qty;
        plan.add((cands.first, name, qty));
      }
      num total = 0;
      final inv = <Map<String, dynamic>>[];
      for (final (batch, name, qty) in plan) {
        final cur = st.get('inventory', batch['id'])!;
        st.patch('inventory', batch['id'], {'stock': (cur['stock'] as int) - qty});
        st.put('dispensingRecords', {'prescriptionId': id, 'medicine': name, 'qty': qty, 'batch': batch['batch'], 'patientName': rx['patientName'], 'dispensedBy': u['id']});
        total += qty * (batch['price'] as num);
        inv.add({'name': name, 'qty': qty, 'price': batch['price'], 'batch': batch['batch']});
      }
      st.put('invoices', {'prescriptionId': id, 'patientName': rx['patientName'], 'lines': inv, 'total': total, 'status': 'unpaid'});
      _audit(u, 'pharmacy.dispense', {'prescriptionId': id});
      return {'ok': true};
    }));
    r.get('/invoices', h([P, D], (u, b, q) => st.list('invoices', {}, 'createdAt', true, 100)));
    r.patch('/invoices/<id>/pay', (Request q, String id) => _run(q, [P], (u, b, rq) {
      final i = st.get('invoices', id);
      if (i == null || i['status'] != 'unpaid') throw Err('Invoice not payable', 409);
      st.patch('invoices', id, {'status': 'paid', 'paidAt': st.now()});
      return {'ok': true};
    }));

    // ----- Payments: doctor OR reception can collect; the first to accept closes it -----
    String hospitalNow() {
      final f = st.list('settings', {'key': 'hospital'}, 'createdAt', true, 1);
      return f.isEmpty ? 'City Care Hospital' : '${f.first['value']}';
    }
    r.get('/settings', h([D, R], (u, b, q) => {'fee': feeNow(), 'hospital': hospitalNow()}));
    r.post('/settings/hospital', h([D, R], (u, b, q) {
      final v = str(need(b['name'], 'Hospital name required'), 60).trim();
      final f = st.list('settings', {'key': 'hospital'}, 'createdAt', true, 1);
      if (f.isEmpty) { st.put('settings', {'key': 'hospital', 'value': v}); } else { st.patch('settings', f.first['id'], {'value': v}); }
      return {'hospital': v};
    }));
    r.get('/bell.wav', (Request q) async {
      final d = await rootBundle.load('assets/sounds/bell.wav');
      return Response.ok(d.buffer.asUint8List(d.offsetInBytes, d.lengthInBytes), headers: {'content-type': 'audio/wav', 'cache-control': 'max-age=86400'});
    });
    r.post('/settings/fee', h([D], (u, b, q) {
      final v = num.tryParse('${b['fee']}');
      if (v == null || v < 0 || v > 1000000) throw Err('Enter a valid amount');
      final f = st.list('settings', {'key': 'fee'}, 'createdAt', true, 1);
      if (f.isEmpty) { st.put('settings', {'key': 'fee', 'value': v}); } else { st.patch('settings', f.first['id'], {'value': v}); }
      return {'fee': v};
    }));
    r.get('/payments', h([D, R], (u, b, q) {
      if ((q.url.queryParameters['view'] ?? 'due') == 'due') return st.list('payments', {'status': 'due'}, 'createdAt', false, 200);
      return st.list('payments', {'status': 'paid'}, 'paidAt', true, 300);
    }));
    r.post('/payments', h([D, R], (u, b, q) {
      final pt = st.get('patients', b['patientDocId']);
      if (pt == null) throw Err('Patient not found', 404);
      final amt = num.tryParse('${b['amount']}');
      if (amt == null || amt <= 0 || amt > 1000000) throw Err('Enter a valid amount');
      st.put('payments', {'patientDocId': pt['id'], 'patientName': pt['name'], 'patientId': pt['patientId'], 'dateKey': _today(),
        'description': str(need(b['description'], 'Description required'), 120), 'amount': amt, 'status': 'due'});
      return {'ok': true};
    }));
    r.post('/payments/<id>/accept', (Request q, String id) => _run(q, [D, R], (u, b, rq) {
      final x = st.get('payments', id);
      if (x == null) throw Err('Payment not found', 404);
      if (x['status'] == 'paid') throw Err('Already collected by ${x['collectedByName']}', 409);
      if (x['status'] != 'due') throw Err('This charge is closed', 409);
      final amt = num.tryParse('${b['amount']}');
      if (amt == null || amt <= 0 || amt > 1000000) throw Err('Enter a valid amount');
      final method = ['cash', 'upi', 'card', 'other'].contains(b['method']) ? b['method'] : 'cash';
      st.patch('payments', id, {'status': 'paid', 'amount': amt, 'method': method, 'note': str(b['note'], 200),
        'collectedBy': u['id'], 'collectedByName': u['name'], 'collectedByRole': u['role'], 'paidAt': st.now()});
      _audit(u, 'payment.accept', {'paymentId': id, 'amount': amt});
      return {'ok': true};
    }));

    // ----- Appointments -----
    r.get('/appointments', h([D, R], (u, b, q) => st.list('appointments', {}, 'dateTime', false)));
    r.post('/appointments', h([D, R], (u, b, q) {
      final p = st.get('patients', b['patientDocId']), w = DateTime.tryParse('${b['dateTime']}');
      if (p == null) throw Err('Patient not found', 404);
      if (w == null) throw Err('Invalid date');
      st.put('appointments', {'patientDocId': p['id'], 'patientName': p['name'], 'patientId': p['patientId'], 'dateTime': w.toUtc().toIso8601String(),
        'reason': str(b['reason'], 300), 'status': 'scheduled', 'reminded24': 0, 'reminded2': 0});
      return {'ok': true};
    }));
    r.patch('/appointments/<id>', (Request q, String id) => _run(q, [D, R], (u, b, rq) {
      final f = <String, dynamic>{};
      if (b['status'] != null) { if (!['scheduled', 'completed', 'cancelled'].contains(b['status'])) throw Err('Invalid status'); f['status'] = b['status']; }
      if (b['reason'] != null) f['reason'] = str(b['reason'], 300);
      if (b['dateTime'] != null) { final d = DateTime.tryParse('${b['dateTime']}'); if (d == null) throw Err('Invalid date'); f..['dateTime'] = d.toUtc().toIso8601String()..['reminded24'] = 0..['reminded2'] = 0; }
      if (st.patch('appointments', id, f) == null) throw Err('Not found', 404);
      return {'ok': true};
    }));

    r.all('/<ignored|.*>', (Request q) => Response.notFound(jsonEncode({'error': 'Not found'}), headers: {'content-type': 'application/json'}));
    return r;
  }

  void _remind() {
    final t = DateTime.now().toUtc();
    for (final a in st.list('appointments', {'status': 'scheduled'}, 'dateTime', false)) {
      final diff = DateTime.parse(a['dateTime']).difference(t);
      if (diff.isNegative || diff > const Duration(hours: 24)) continue;
      String? label;
      Map<String, dynamic> f = {};
      if (diff <= const Duration(hours: 2) && a['reminded2'] == 0) { label = '2 hours'; f = {'reminded2': 1, 'reminded24': 1}; }
      else if (diff > const Duration(hours: 2) && a['reminded24'] == 0) { label = '24 hours'; f = {'reminded24': 1}; }
      if (label == null) continue;
      st.patch('appointments', a['id'], f);
      for (final role in [D, R]) { st.put('notifications', {'forRole': role, 'title': 'Appointment reminder', 'body': 'An appointment is due in $label.'}); }
    }
  }
}
