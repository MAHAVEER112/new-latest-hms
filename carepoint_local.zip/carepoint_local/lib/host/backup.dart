import 'dart:convert';
import 'dart:io';
import 'package:file_selector/file_selector.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'files.dart';
import 'store.dart';

/// Backups of all hospital data held on the doctor's phone.
/// Daily automatic copies stay on the phone (last 10); Export saves a copy anywhere you choose.
class BackupService {
  static String _two(int n) => n.toString().padLeft(2, '0');

  static String fileName([String tag = '']) {
    final n = DateTime.now();
    return 'carepoint-backup-${n.year}${_two(n.month)}${_two(n.day)}-${_two(n.hour)}${_two(n.minute)}$tag.cpbackup';
  }

  static Future<Directory> _dir() async {
    final d = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'backups'));
    await d.create(recursive: true);
    return d;
  }

  static Future<List<File>> list() async {
    final dir = await _dir();
    final fs = (await dir.list().toList()).whereType<File>().where((f) => f.path.endsWith('.cpbackup')).toList()
      ..sort((a, b) => a.path.compareTo(b.path));
    return fs;
  }

  static Future<File> autoBackup(Store st, {String tag = ''}) async {
    final f = File(p.join((await _dir()).path, fileName(tag)));
    await f.writeAsString(jsonEncode(st.snapshot()));
    final fs = await list();
    while (fs.length > 10) { await fs.removeAt(0).delete(); }
    return f;
  }

  static Future<void> autoIfDue(Store st) async {
    final n = DateTime.now();
    final today = '${n.year}${_two(n.month)}${_two(n.day)}';
    if ((await list()).any((f) => p.basename(f.path).contains('-$today-'))) return;
    await autoBackup(st);
  }

  static Future<List<int>?> pick() async {
    final f = await openFile();
    return f == null ? null : await f.readAsBytes();
  }

  /// Writes a fresh backup to a temporary file so it can be shared / saved anywhere.
  static Future<File> exportFile(Store st) async {
    final snap = st.snapshot();
    final files = <String, String>{};
    for (final f in await (await reportsDir()).list().toList()) {
      if (f is File) files[p.basename(f.path)] = base64Encode(await f.readAsBytes());
    }
    snap['files'] = files;
    final out = File(p.join((await getTemporaryDirectory()).path, fileName()));
    await out.writeAsString(jsonEncode(snap));
    return out;
  }

  static Future<void> restoreFiles(Map<String, dynamic> snap) async {
    final files = snap['files'];
    if (files is! Map) return;
    final dir = await reportsDir();
    for (final e in files.entries) {
      final name = p.basename('${e.key}');
      if (name.endsWith('.pdf')) await File(p.join(dir.path, name)).writeAsBytes(base64Decode('${e.value}'));
    }
  }

  static Map<String, dynamic> parse(List<int> bytes) {
    dynamic m;
    try { m = jsonDecode(utf8.decode(bytes)); } catch (_) { throw Exception('This is not a CarePoint backup file'); }
    if (m is! Map || m['app'] != 'carepoint' || m['docs'] is! List) throw Exception('This is not a CarePoint backup file');
    final docs = m['docs'] as List;
    if (!docs.any((d) => d['col'] == 'users' && d['data']['role'] == 'doctor')) throw Exception('This backup has no doctor account');
    return Map<String, dynamic>.from(m);
  }

  static String summary(Map<String, dynamic> m) {
    final d = m['docs'] as List;
    int c(String col) => d.where((e) => e['col'] == col).length;
    return '${c('patients')} patients, ${c('consultations')} consultations, ${c('prescriptions')} prescriptions, ${c('invoices')} invoices.\nCreated: ${m['createdAt']}';
  }
}
