import 'dart:convert';
import 'dart:math';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class Prefix {
  const Prefix(this.v);
  final String v;
}

const _meta = {'id', '_col', 'createdAt', 'updatedAt'};

/// In-memory documents, written through to SQLite on the doctor's phone.
class Store {
  late Database _db;
  final Map<String, Map<String, dynamic>> _m = {};
  final _rnd = Random.secure();

  Future<void> open() async {
    _db = await openDatabase(p.join(await getDatabasesPath(), 'carepoint_host.db'), version: 1,
        onCreate: (d, _) => d.execute('CREATE TABLE docs(id TEXT PRIMARY KEY, col TEXT, data TEXT, created_at TEXT, updated_at TEXT)'));
    for (final r in await _db.query('docs')) {
      _m[r['id'] as String] = {
        ...jsonDecode(r['data'] as String) as Map<String, dynamic>,
        'id': r['id'], '_col': r['col'], 'createdAt': r['created_at'], 'updatedAt': r['updated_at'],
      };
    }
  }

  String _newId() => List.generate(16, (_) => _rnd.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
  String now() => DateTime.now().toUtc().toIso8601String();

  void _save(Map<String, dynamic> m) {
    final data = Map<String, dynamic>.of(m)..removeWhere((k, _) => _meta.contains(k));
    _db.insert('docs', {'id': m['id'], 'col': m['_col'], 'data': jsonEncode(data), 'created_at': m['createdAt'], 'updated_at': m['updatedAt']},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  String put(String col, Map<String, dynamic> data) {
    final t = now();
    final m = <String, dynamic>{...data, 'id': _newId(), '_col': col, 'createdAt': t, 'updatedAt': t};
    _m[m['id']] = m;
    _save(m);
    return m['id'] as String;
  }

  Map<String, dynamic>? get(String col, Object? id) {
    final m = _m[id];
    return (m != null && m['_col'] == col) ? m : null;
  }

  Map<String, dynamic>? patch(String col, String id, Map<String, dynamic> f) {
    final c = get(col, id);
    if (c == null) return null;
    final m = <String, dynamic>{...c, ...f, 'updatedAt': now()};
    _m[id] = m;
    _save(m);
    return m;
  }

  bool _match(Map<String, dynamic> m, Map<String, Object?> w) {
    for (final e in w.entries) {
      final v = m[e.key], x = e.value;
      if (x is List) {
        if (!x.contains(v)) return false;
      } else if (x is Prefix) {
        if (!(v is String && v.startsWith(x.v))) return false;
      } else if (v != x) {
        return false;
      }
    }
    return true;
  }

  List<Map<String, dynamic>> list(String col, [Map<String, Object?> w = const {}, String order = 'createdAt', bool desc = true, int limit = 200]) {
    final r = _m.values.where((m) => m['_col'] == col && _match(m, w)).toList();
    r.sort((a, b) {
      final x = a[order], y = b[order];
      final c = (x is num && y is num) ? x.compareTo(y) : '$x'.compareTo('$y');
      return desc ? -c : c;
    });
    return r.take(limit).toList();
  }

  int count(String col, [Map<String, Object?> w = const {}]) => _m.values.where((m) => m['_col'] == col && _match(m, w)).length;

  int nextVal(String key) {
    final c = list('counters', {'key': key}, 'createdAt', true, 1);
    if (c.isEmpty) { put('counters', {'key': key, 'value': 1}); return 1; }
    final v = (c.first['value'] as int) + 1;
    patch('counters', c.first['id'], {'value': v});
    return v;
  }

  Map<String, dynamic> _data(Map<String, dynamic> m) => Map<String, dynamic>.of(m)..removeWhere((k, _) => _meta.contains(k));

  /// Everything except login sessions.
  Map<String, dynamic> snapshot() => {
        'app': 'carepoint', 'version': 1, 'createdAt': now(),
        'docs': [
          for (final m in _m.values)
            if (m['_col'] != 'sessions') {'id': m['id'], 'col': m['_col'], 'data': _data(m), 'createdAt': m['createdAt'], 'updatedAt': m['updatedAt']}
        ],
      };

  /// Replaces ALL data on this phone with the backup.
  Future<void> restore(Map<String, dynamic> snap) async {
    final docs = snap['docs'] as List;
    await _db.transaction((txn) async {
      await txn.delete('docs');
      final b = txn.batch();
      for (final d in docs) {
        b.insert('docs', {'id': d['id'], 'col': d['col'], 'data': jsonEncode(d['data']), 'created_at': d['createdAt'], 'updated_at': d['updatedAt']});
      }
      await b.commit(noResult: true);
    });
    _m.clear();
    for (final d in docs) {
      _m[d['id'] as String] = {...Map<String, dynamic>.from(d['data'] as Map), 'id': d['id'], '_col': d['col'], 'createdAt': d['createdAt'], 'updatedAt': d['updatedAt']};
    }
  }
}
