import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Lab report PDFs are stored here on the doctor's phone.
Future<Directory> reportsDir() async {
  final d = Directory(p.join((await getApplicationDocumentsDirectory()).path, 'reports'));
  await d.create(recursive: true);
  return d;
}
