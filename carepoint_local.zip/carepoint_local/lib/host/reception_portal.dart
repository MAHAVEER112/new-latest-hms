/// Web page for the reception computer (open http://<doctor-ip>:8080/reception-portal).
const String receptionPortalHtml = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CarePoint Reception</title>
<style>
:root{--p:#6D4CFF;--ink:#1E1B3A}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;color:var(--ink);min-height:100vh;background:radial-gradient(600px 400px at 0 0,#f9a8d466,transparent),radial-gradient(700px 500px at 100% 40%,#a78bfa55,transparent),radial-gradient(600px 400px at 20% 100%,#67e8f955,transparent),linear-gradient(135deg,#f6f0f3,#ebeef8,#f1f6f7);background-attachment:fixed}
.wrap{max-width:1000px;margin:0 auto;padding:20px}
.glass{background:linear-gradient(135deg,#ffffffb8,#ffffff66);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1.4px solid #ffffffd5;border-radius:24px;box-shadow:8px 14px 28px #8b7fb833,-3px -3px 8px #fffc}
.card{padding:26px;max-width:420px;margin:12vh auto 0;text-align:center}
h1{margin:0 0 4px;font-size:24px}h3{margin:6px 0 10px}
input,select{width:100%;padding:12px 18px;border-radius:24px;border:1.4px solid #ffffffd5;background:#ffffffc0;font-size:15px;margin:6px 0}
#code{text-transform:uppercase;text-align:center;font-size:18px}
button{border:0;border-radius:30px;padding:11px 20px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;background:linear-gradient(135deg,#a48bff,#6d4cff);box-shadow:0 8px 16px #6d4cff55}
button.ghost{background:#ffffff99;color:var(--ink);box-shadow:none;border:1.4px solid #ffffffd5}
button.on{background:linear-gradient(135deg,#a48bff,#6d4cff);color:#fff}
.bar{display:flex;align-items:center;justify-content:space-between;padding:12px 18px;margin-bottom:12px;gap:10px;flex-wrap:wrap}
.tabs{display:flex;gap:8px;flex-wrap:wrap}
.tools{display:flex;gap:10px;padding:12px 16px;margin-bottom:12px;align-items:center}
.tools input{margin:0;flex:1}
.row{display:flex;align-items:center;gap:14px;padding:12px 18px;margin-bottom:10px}
.tok{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,#b8a6ff,#6d4cff);flex:none}
.tok.lab{background:linear-gradient(135deg,#7dd3fc,#0ea5e9)}
.info{flex:1;min-width:0}.info small{color:#555;display:block}.ok{color:#1b9e6e;font-weight:700}
.amt{font-weight:800;font-size:18px}
.empty{text-align:center;color:#666;padding:26px}
#err,#conn{color:#e5484d;font-weight:600}
h4{margin:14px 4px 8px}
dialog{border:0;padding:22px;width:min(92vw,400px);color:var(--ink)}
dialog::backdrop{background:#1e1b3a55}
dialog label{display:block;font-size:13px;margin-top:8px}
.acts{display:flex;justify-content:flex-end;gap:10px;margin-top:14px}
#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#1e1b3ae6;color:#fff;padding:12px 22px;border-radius:30px;font-weight:600}
</style></head><body>
<div class="wrap">
  <div id="login" class="glass card" hidden>
    <h1>CarePoint Reception</h1>
    <div>Enter the one-time code from the doctor</div>
    <input id="code" type="text" placeholder="CODE" autocomplete="off">
    <button id="go">Sign in</button>
    <p id="err"></p>
  </div>
  <div id="app" hidden>
    <div class="glass bar">
      <div><b>CarePoint Reception</b></div>
      <div class="tabs">
        <button class="tab ghost" data-tab="patients">Patients</button>
        <button class="tab ghost" data-tab="queue">Queue</button>
        <button class="tab ghost" data-tab="appts">Appointments</button>
        <button class="tab ghost" data-tab="pay">Payments</button>
        <button class="ghost" id="out">Sign out</button>
      </div>
    </div>
    <div id="conn"></div>
    <div id="view"></div>
  </div>
</div>
<dialog id="dlg" class="glass"><h3 id="dt"></h3><div id="df"></div><div class="acts"><button class="ghost" id="dno">Cancel</button><button id="dok">OK</button></div></dialog>
<div id="toast" hidden></div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=sessionStorage.getItem('rp_t'),me=null,tab='patients',timer=null,payView='due';
const ROLE={doctor:'Doctor',receptionist:'Reception'};
async function api(method,path,body){
  const r=await fetch(path,{method:method,headers:Object.assign({'Content-Type':'application/json'},token?{Authorization:'Bearer '+token}:{}),body:body?JSON.stringify(body):undefined});
  let d={};try{d=await r.json();}catch(e){}
  if(r.status===401&&token&&path!=='/auth/login'){logout();}
  if(!r.ok)throw new Error(d.error||'Request failed ('+r.status+')');
  return d;
}
function toast(m){const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>{t.hidden=true;},3500);}
const fmt=iso=>iso?new Date(iso).toLocaleString([],{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'';
const money=v=>'\u20b9'+(Number(v)%1===0?Number(v):Number(v).toFixed(2));
function ask(title,fields){
  return new Promise(res=>{
    const d=$('#dlg');$('#dt').textContent=title;
    $('#df').innerHTML=fields.map(f=>'<label>'+esc(f.label)+(f.type==='select'?'<select id="f_'+f.id+'">'+f.options.map(o=>'<option value="'+esc(o)+'">'+esc(o)+'</option>').join('')+'</select>':'<input id="f_'+f.id+'" type="'+(f.type||'text')+'" value="'+esc(f.value||'')+'">')+'</label>').join('');
    const done=v=>{d.close();res(v);};
    $('#dok').onclick=()=>done(Object.fromEntries(fields.map(f=>[f.id,$('#f_'+f.id).value.trim()])));
    $('#dno').onclick=()=>done(null);
    d.addEventListener('cancel',()=>res(null),{once:true});
    d.showModal();
  });
}
function show(w){$('#login').hidden=w!=='login';$('#app').hidden=w!=='app';}
async function login(){
  $('#err').textContent='';
  try{
    const d=await api('POST','/auth/login',{id:'reception',secret:$('#code').value.trim()});
    if(d.user.role!=='receptionist')throw new Error('This page is only for Reception.');
    token=d.token;sessionStorage.setItem('rp_t',token);me=d.user;start();
  }catch(e){$('#err').textContent=e.message;}
}
function logout(){token=null;me=null;sessionStorage.removeItem('rp_t');clearInterval(timer);show('login');}
function start(){show('app');setTab(tab);}
function setTab(t){
  tab=t;document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('on',b.dataset.tab===t));
  clearInterval(timer);$('#view').innerHTML='';render();
  timer=setInterval(()=>{if(!$('#dlg').open&&tab!=='patients')render();},4000);
}
async function render(){try{await views[tab]();$('#conn').textContent='';}catch(e){$('#conn').textContent=e.message;}}
const views={};
// ---- Patients
views.patients=async()=>{
  if(!$('#pq')){
    $('#view').innerHTML='<div class="glass tools"><input id="pq" placeholder="Search patient by name"><button id="pn">Register new patient</button></div><div id="plist"></div>';
    $('#pq').oninput=()=>{clearTimeout(window.pt);window.pt=setTimeout(loadP,300);};
    $('#pn').onclick=registerP;
  }
  await loadP();
};
async function loadP(){
  const rows=await api('GET','/patients?q='+encodeURIComponent($('#pq').value.trim()));
  $('#plist').innerHTML=rows.length?rows.map(r=>'<div class="row glass"><div class="info"><b>'+esc(r.name)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(r.age)+' yrs \u00b7 '+esc(r.gender)+' \u00b7 '+esc(r.phone)+(r.allergies?' \u00b7 Allergies: '+esc(r.allergies):'')+'</small></div><button data-act="checkin" data-id="'+esc(r.id)+'">Check in</button></div>').join(''):'<p class="empty">No patients found.</p>';
}
async function registerP(){
  const v=await ask('Register patient',[{id:'name',label:'Full name'},{id:'phone',label:'Phone',type:'tel'},{id:'age',label:'Age',type:'number'},{id:'gender',label:'Gender',type:'select',options:['Female','Male','Other']},{id:'allergies',label:'Allergies (optional)'}]);
  if(!v)return;
  try{const d=await api('POST','/patients',{name:v.name,phone:v.phone,age:v.age,gender:v.gender,allergies:v.allergies});toast('Registered. Patient ID: '+d.patientId);loadP();}catch(e){toast(e.message);}
}
// ---- Queue
views.queue=async()=>{
  const rows=await api('GET','/queue');
  const lab=rows.filter(r=>r.status==='in_lab'),gen=rows.filter(r=>r.status!=='in_lab');
  const g=r=>'<div class="row glass"><div class="tok">'+esc(r.tokenNumber)+'</div><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(String(r.status).replace('_',' '))+'</small></div></div>';
  const l=r=>{let t='In lab';if(r.labReady===1)t='Report ready';else if(r.labReadyBy){const m=Math.round((new Date(r.labReadyBy)-Date.now())/60000);t=m>0?'Back in '+m+' min':'Overdue by '+(-m)+' min';}
    return '<div class="row glass"><div class="tok lab">'+esc(r.tokenNumber)+'</div><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(t)+'</small></div></div>';};
  $('#view').innerHTML='<h4>General queue ('+gen.length+')</h4>'+(gen.map(g).join('')||'<p class="empty">Empty.</p>')+'<h4>Lab queue ('+lab.length+')</h4>'+(lab.map(l).join('')||'<p class="empty">Empty.</p>');
};
// ---- Appointments
views.appts=async()=>{
  const rows=(await api('GET','/appointments')).filter(r=>r.status==='scheduled');
  $('#view').innerHTML='<div class="glass tools"><b style="flex:1">Scheduled appointments</b><button id="na">New appointment</button></div>'+(rows.length?rows.map(r=>'<div class="row glass"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(fmt(r.dateTime))+(r.reason?' \u00b7 '+esc(r.reason):'')+'</small></div><button class="ghost" data-act="adone" data-id="'+esc(r.id)+'">Complete</button><button class="ghost" data-act="acancel" data-id="'+esc(r.id)+'">Cancel</button></div>').join(''):'<p class="empty">No scheduled appointments.</p>');
  $('#na').onclick=newAppt;
};
async function newAppt(){
  const v=await ask('New appointment',[{id:'pid',label:'Patient ID (e.g. CP-000001)'},{id:'when',label:'Date and time',type:'datetime-local'},{id:'reason',label:'Reason'}]);
  if(!v)return;
  try{
    const p=await api('GET','/patients?pid='+encodeURIComponent(v.pid));
    if(!p.length)throw new Error('Patient not found');
    const d=new Date(v.when);if(isNaN(d))throw new Error('Choose a date and time');
    await api('POST','/appointments',{patientDocId:p[0].id,dateTime:d.toISOString(),reason:v.reason});toast('Appointment created');render();
  }catch(e){toast(e.message);}
}
// ---- Payments (doctor or reception may collect; once collected it is closed for the other)
views.pay=async()=>{
  const rows=await api('GET','/payments?view='+payView);
  const sub='<div class="glass tools"><button class="'+(payView==='due'?'on':'ghost')+'" data-act="pv" data-v="due">Due</button><button class="'+(payView==='paid'?'on':'ghost')+'" data-act="pv" data-v="paid">History</button><span style="flex:1"></span><button id="nc">New charge</button></div>';
  let body='';
  if(payView==='due'){
    body=rows.length?rows.map(r=>'<div class="row glass"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(r.description)+'</small></div><div class="amt">'+money(r.amount)+'</div><button data-act="pay" data-id="'+esc(r.id)+'" data-amt="'+esc(r.amount)+'">Accept payment</button></div>').join(''):'<p class="empty">No payments due.</p>';
  }else{
    const today=new Date().toDateString();
    const tot=rows.filter(r=>new Date(r.paidAt).toDateString()===today).reduce((a,r)=>a+Number(r.amount),0);
    body='<h4>Collected today: '+money(tot)+'</h4>'+(rows.length?rows.map(r=>'<div class="row glass"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.description)+' \u00b7 '+esc(String(r.method).toUpperCase())+' \u00b7 by '+esc(r.collectedByName)+' ('+esc(ROLE[r.collectedByRole]||r.collectedByRole)+') \u00b7 '+esc(fmt(r.paidAt))+'</small></div><div class="amt ok">'+money(r.amount)+'</div></div>').join(''):'<p class="empty">No payments yet.</p>');
  }
  $('#view').innerHTML=sub+body;$('#nc').onclick=newCharge;
};
async function newCharge(){
  const v=await ask('New charge',[{id:'pid',label:'Patient ID (e.g. CP-000001)'},{id:'desc',label:'Description',value:'Lab / other charge'},{id:'amt',label:'Amount',type:'number'}]);
  if(!v)return;
  try{
    const p=await api('GET','/patients?pid='+encodeURIComponent(v.pid));
    if(!p.length)throw new Error('Patient not found');
    await api('POST','/payments',{patientDocId:p[0].id,description:v.desc,amount:v.amt});toast('Charge added');render();
  }catch(e){toast(e.message);}
}
document.addEventListener('click',async e=>{
  const t=e.target.closest('[data-act],[data-tab]');if(!t)return;
  if(t.dataset.tab){setTab(t.dataset.tab);return;}
  const act=t.dataset.act,id=t.dataset.id;
  try{
    if(act==='pv'){payView=t.dataset.v;render();}
    else if(act==='checkin'){const d=await api('POST','/queue/checkin',{patientDocId:id});toast('Checked in. Token #'+d.token);}
    else if(act==='adone'||act==='acancel'){await api('PATCH','/appointments/'+id,{status:act==='adone'?'completed':'cancelled'});render();}
    else if(act==='pay'){
      const v=await ask('Accept payment',[{id:'amt',label:'Amount received',type:'number',value:t.dataset.amt},{id:'method',label:'Method',type:'select',options:['cash','upi','card']},{id:'note',label:'Note (optional)'}]);
      if(!v)return;
      await api('POST','/payments/'+id+'/accept',{amount:v.amt,method:v.method,note:v.note});toast('Payment collected');render();
    }
  }catch(x){toast(x.message);render();}
});
$('#go').addEventListener('click',login);
$('#code').addEventListener('keydown',e=>{if(e.key==='Enter')login();});
$('#out').addEventListener('click',logout);
(async()=>{
  if(token){try{me=await api('GET','/auth/me');if(me.role==='receptionist'){start();return;}}catch(e){}}
  show('login');
})();
</script></body></html>
''';
