/// Reception web page, designed like the app (open http://<doctor-ip>:8080/reception-portal).
const String receptionPortalHtml = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0f62c9"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><link rel="manifest" href="/reception.webmanifest"><link rel="icon" href="/icon.svg"><link rel="apple-touch-icon" href="/icon.svg">
<title>CarePoint Reception</title>
<style>
:root{--p:#0f62c9;--ink:#0b2a55;--mut:#5b6b86}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ink);min-height:100vh;background:radial-gradient(520px 380px at 0 0,#bfdbfe66,transparent),radial-gradient(620px 460px at 100% 38%,#93c5fd55,transparent),radial-gradient(520px 380px at 15% 100%,#bae6fd55,transparent),linear-gradient(135deg,#f3f8ff,#eaf3fe,#f4f9ff);background-attachment:fixed}
.app{max-width:560px;margin:0 auto;padding:16px 16px 120px}
.glass{background:linear-gradient(135deg,#ffffffc0,#ffffff66);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1.4px solid #ffffffd9;border-radius:24px;box-shadow:8px 14px 28px #4a78b833,-3px -3px 8px #fffc}
h1,h2,h3,h4{margin:0}
.head{display:flex;align-items:center;justify-content:space-between;gap:10px}
.greet{font-size:25px;font-weight:800}
.mut{color:var(--mut);font-size:14px}
.hero{margin-top:12px;border-radius:28px;padding:16px;display:flex;align-items:center;gap:14px;color:#fff;background:linear-gradient(100deg,#2f86e0,#1b6fd0 55%,#0b4a9e);box-shadow:0 14px 28px #0f62c955;border:1.2px solid #ffffff99}
.hero.click{cursor:pointer}
.avatar{width:60px;height:60px;border-radius:50%;background:#ffffff2e;border:1.5px solid #ffffffaa;display:flex;align-items:center;justify-content:center;font-size:30px;flex:none}
.hero small{opacity:.85}.hero .big{font-size:21px;font-weight:800;line-height:1.15}
.pill-white{margin-left:auto;background:#fff!important;color:#0b4a9e!important;box-shadow:0 6px 12px #0b4a9e33!important;white-space:nowrap}
.row2{display:flex;align-items:center;justify-content:space-between;margin:22px 0 14px}
.row2 h2{font-size:21px}
.chip{background:#ffffffb0;border:1.2px solid #fffd;border-radius:20px;padding:7px 12px;font-size:13px;font-weight:600;white-space:nowrap}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.stat{display:flex;align-items:center;gap:10px;padding:12px;cursor:pointer;min-height:84px}
.stat.wide{margin-top:14px;padding:16px}
.ico{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;flex:none;border:1.2px solid #fffd}
.num{font-size:27px;font-weight:800;line-height:1.05}.lbl{font-size:13px;line-height:1.15}.ttl{font-size:19px;font-weight:800}
.arr{color:#999;font-size:18px}
.row{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:10px}
.row.click{cursor:pointer}
.tok{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,#7db8f5,#0f62c9);flex:none}
.tok.lab{background:linear-gradient(135deg,#7dd3fc,#0ea5e9)}.tok.urgent{background:linear-gradient(135deg,#ff9a9a,#e5484d)}
.info{flex:1;min-width:0}.info small{display:block;color:var(--mut)}
.ok{color:#1b9e6e;font-weight:700}.red{color:#e5484d}.amt{font-weight:800;font-size:18px}
.empty{text-align:center;color:#666;padding:26px}
button,.btn{border:0;border-radius:30px;padding:11px 20px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;background:linear-gradient(135deg,#4ba3f2,#0f62c9);box-shadow:0 8px 16px #0f62c955}
button.ghost{background:#ffffff99;color:var(--ink);box-shadow:none;border:1.4px solid #ffffffd5}
button.on{background:linear-gradient(135deg,#4ba3f2,#0f62c9);color:#fff}
button.full{width:100%;margin-top:18px;padding:14px}
button:disabled{opacity:.6;cursor:default}
input,select{width:100%;padding:12px 18px;border-radius:24px;border:1.4px solid #ffffffd5;background:#ffffffc0;font-size:15px;margin:6px 0;font-family:inherit}
.tools{display:flex;gap:10px;padding:12px 14px;margin:14px 0;align-items:center}
.tools input{margin:0;flex:1}
.card{padding:26px;max-width:420px;margin:12vh auto 0;text-align:center}
.card input{text-transform:uppercase;text-align:center;font-size:18px;margin:14px 0}
#err,#conn{color:#e5484d;font-weight:600}
nav{position:fixed;left:0;right:0;bottom:calc(10px + env(safe-area-inset-bottom));display:flex;justify-content:center;z-index:5}
nav .bar{display:flex;width:min(540px,calc(100% - 20px));padding:6px;border-radius:30px}
nav button{flex:1;border:0;background:none;box-shadow:none;color:#55546b;padding:8px 2px;border-radius:24px;font-size:11px;font-weight:500;display:flex;flex-direction:column;align-items:center;gap:2px}
nav button.on{background:linear-gradient(135deg,#e3eeff,#d3e5ff);color:#0b4a9e;font-weight:800;box-shadow:0 4px 10px #0f62c933}
nav .e{font-size:20px}
.bar2{height:10px;border-radius:8px;background:#ffffffaa;overflow:hidden;margin-top:10px}.bar2 i{display:block;height:100%;background:linear-gradient(90deg,#4ba3f2,#0f62c9)}
dialog{border:0;padding:22px;width:min(92vw,400px);color:var(--ink)}
dialog::backdrop{background:#0b2a5555}
dialog label{display:block;font-size:13px;margin-top:8px}
.acts{display:flex;justify-content:flex-end;gap:10px;margin-top:14px}
#toast{position:fixed;left:50%;bottom:96px;transform:translateX(-50%);background:#0b2a55e6;color:#fff;padding:12px 22px;border-radius:30px;font-weight:600;z-index:9}
.back{margin:6px 0 12px}

.top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px;line-height:1.08;color:#0b2a55}
.logo{width:46px;height:46px}
.bell{position:relative;width:54px;height:54px;padding:0;border-radius:18px;background:#ffffffd8;box-shadow:0 8px 16px #4a78b833;color:#0b2a55;font-size:22px;border:1.4px solid #fff}
.bell i{position:absolute;top:13px;right:14px;width:10px;height:10px;border-radius:50%;background:#f59e0b;border:2px solid #fff}
.art{width:190px;height:118px;flex:none;margin-right:-16px;margin-bottom:-14px}
.greet{line-height:1.12}
.hero .vd,.payb .vd{width:1px;align-self:stretch;background:#ffffff59}
.stat,.row{background:linear-gradient(135deg,#ffffff,#f5f9ff)}
.stat .arr{font-size:26px;line-height:1}
.payb{margin-top:16px;border-radius:28px;padding:18px;display:flex;align-items:center;gap:14px;color:#fff;background:linear-gradient(100deg,#1f7ddb,#0b4a9e);box-shadow:0 14px 28px #0f62c955;cursor:pointer}
.payb .ico{background:#ffffff26;border:1.5px solid #ffffffaa;width:56px;height:56px}
.payb .ttl{font-size:21px}.payb small{opacity:.9;font-size:14px}
.payb .circ{width:44px;height:44px;border-radius:50%;background:#ffffff33;display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}
.hero .pill-white{box-shadow:0 6px 12px #0b4a9e33!important}
</style></head><body>
<div id="login" class="app" hidden>
  <div class="glass card">
    <h1>CarePoint Reception</h1>
    <p class="mut">Enter the one-time code from the doctor</p>
    <input id="code" type="text" placeholder="CODE" autocomplete="off">
    <button id="go">Sign in</button>
    <p id="err"></p>
  </div>
</div>
<div id="app" class="app" hidden><div id="conn"></div><div id="view"></div></div>
<nav id="nav" hidden><div class="bar glass" id="navbar"></div></nav>
<dialog id="dlg" class="glass"><h3 id="dt"></h3><div id="df"></div><div class="acts"><button class="ghost" id="dno">Cancel</button><button id="dok">OK</button></div></dialog>
<div id="toast" hidden></div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(method,path,body){
  const r=await fetch(path,{method:method,headers:Object.assign({'Content-Type':'application/json'},token?{Authorization:'Bearer '+token}:{}),body:body?JSON.stringify(body):undefined});
  let d={};try{d=await r.json();}catch(e){}
  if(r.status===401&&token&&path!=='/auth/login'){logout();}
  if(!r.ok)throw new Error(d.error||'Request failed ('+r.status+')');
  return d;
}
function toast(m){const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>{t.hidden=true;},3500);}
const fmt=iso=>iso?new Date(iso).toLocaleString([],{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'';
const money=v=>'\u20b9'+(Number(v)%1===0?Number(v):Number(v).toFixed(2));
const greetWord=()=>{const h=new Date().getHours();return h<12?'Good Morning':h<17?'Good Afternoon':'Good Evening';};
const dateLine=()=>new Date().toLocaleDateString([],{weekday:'long',day:'numeric',month:'long'});
const LOGO='<svg class="logo" viewBox="0 0 48 48"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b9bf0"/><stop offset="1" stop-color="#0b4a9e"/></linearGradient></defs><path d="M18 4h12a2 2 0 0 1 2 2v10h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H32v10a2 2 0 0 1-2 2H18a2 2 0 0 1-2-2V32H6a2 2 0 0 1-2-2V18a2 2 0 0 1 2-2h10V6a2 2 0 0 1 2-2z" fill="url(#lg)"/><path d="M21 12h6v9h9v6h-9v9h-6v-9h-9v-6h9z" fill="#fff" opacity=".92"/></svg>';
const ART='<svg class="art" viewBox="0 0 200 130"><ellipse cx="110" cy="122" rx="104" ry="9" fill="#9bd48a"/><rect x="46" y="64" width="146" height="50" rx="3" fill="#e9eef6"/><rect x="46" y="60" width="146" height="6" fill="#c9d4e4"/><rect x="118" y="22" width="52" height="92" rx="3" fill="#2f7fd6"/><g fill="#8fc2f4" opacity=".7"><rect x="122" y="56" width="10" height="10"/><rect x="136" y="56" width="10" height="10"/><rect x="150" y="56" width="10" height="10"/><rect x="122" y="72" width="10" height="10"/><rect x="136" y="72" width="10" height="10"/><rect x="150" y="72" width="10" height="10"/><rect x="122" y="88" width="10" height="10"/><rect x="136" y="88" width="10" height="10"/><rect x="150" y="88" width="10" height="10"/></g><path d="M139 30h10v8h8v10h-8v8h-10v-8h-8V38h8z" fill="#fff"/><g fill="#3f8be0"><rect x="54" y="72" width="12" height="9"/><rect x="72" y="72" width="12" height="9"/><rect x="90" y="72" width="12" height="9"/><rect x="54" y="88" width="12" height="9"/><rect x="72" y="88" width="12" height="9"/><rect x="90" y="88" width="12" height="9"/></g><rect x="172" y="76" width="18" height="38" fill="#c9dcf3"/><rect x="26" y="96" width="5" height="18" fill="#8b6b4a"/><circle cx="28" cy="86" r="15" fill="#3f9b4f"/><circle cx="17" cy="95" r="10" fill="#4aa85a"/><circle cx="40" cy="95" r="10" fill="#4aa85a"/><circle cx="62" cy="116" r="6" fill="#4aa85a"/><circle cx="80" cy="117" r="5" fill="#5bb86a"/></svg>';
let HOSP='City Care Hospital';
function topbar(){return '<div class="top"><div class="brand" id="hname" style="cursor:pointer" title="Tap to change hospital name">'+LOGO+'<div>'+esc(HOSP).replace(/ (?=[^ ]+$)/,'<br>')+'</div><span style="font-size:14px;opacity:.6">\u270E</span></div><button class="bell" data-t="more" aria-label="Notifications">\u{1F514}<i id="dot" hidden></i></button></div>';}
function loadDot(){api('GET','/notifications').then(n=>{const d=$('#dot');if(d&&n.length)d.hidden=false;}).catch(()=>{});}
function drawNav(){$('#navbar').innerHTML=NAV.map(n=>'<button data-t="'+n[0]+'" class="'+(tab===n[0]?'on':'')+'"><span class="e">'+n[1]+'</span><span>'+n[2]+'</span></button>').join('');}
function show(w){$('#login').hidden=w!=='login';$('#app').hidden=w!=='app';$('#nav').hidden=w!=='app';}
let token=sessionStorage.getItem('rp_t'),me=null,tab='dash',timer=null,payView='due',detail=null;
const ROLE={doctor:'Doctor',receptionist:'Reception'};
const NAV=[['dash','🏠','Dashboard'],['patients','📁','Patients'],['appts','🗓️','Appointments'],['queue','👥','Queue'],['pay','💳','Payments'],['more','⋯','More']];
const META={waiting:['⏳','#22c55e','Waiting now'],in_lab:['🔬','#0ea5e9','In lab'],completed:['✅','#22c55e','Completed today'],appointments:['📅','#f43f8e','Appointments today'],current:['🧑','#0f62c9','Current patient']};
function ask(title,fields){
  return new Promise(res=>{
    const d=$('#dlg');$('#dt').textContent=title;
    $('#df').innerHTML=fields.map(f=>'<label>'+esc(f.label)+(f.type==='select'?'<select id="f_'+f.id+'">'+f.options.map(o=>'<option value="'+esc(o)+'">'+esc(o)+'</option>').join('')+'</select>':'<input id="f_'+f.id+'" type="'+(f.type||'text')+'" value="'+esc(f.value||'')+'" style="text-transform:none;text-align:left;font-size:15px">')+'</label>').join('');
    const done=v=>{d.close();res(v);};
    $('#dok').onclick=()=>done(Object.fromEntries(fields.map(f=>[f.id,$('#f_'+f.id).value.trim()])));
    $('#dno').onclick=()=>done(null);
    d.addEventListener('cancel',()=>res(null),{once:true});
    d.showModal();
  });
}

const BELL=new Audio('/bell.wav');BELL.preload='auto';let lastCall=null,primed=false;
document.addEventListener('pointerdown',()=>{if(primed)return;primed=true;BELL.muted=true;BELL.play().then(()=>{BELL.pause();BELL.currentTime=0;BELL.muted=false;}).catch(()=>{BELL.muted=false;});},{once:true});
async function checkCall(){
  if(!token)return;
  try{
    const st=await api('GET','/stats'),cur=st.find(s=>s.key==='current')||{},k=String(cur.callKey||'');
    if(lastCall!==null&&k&&k!==lastCall){try{BELL.currentTime=0;await BELL.play();}catch(e){}toast('\u{1F514} Doctor is calling: '+(cur.value||'patient'));}
    lastCall=k;
  }catch(e){}
}
setInterval(checkCall,3000);
async function loadHosp(){try{const d=await api('GET','/settings');if(d.hospital){HOSP=d.hospital;const h=$('#hname');if(h)h.querySelector('div').innerHTML=esc(HOSP).replace(/ (?=[^ ]+$)/,'<br>');}}catch(e){}}
document.addEventListener('click',async e=>{
  if(!e.target.closest('#hname'))return;
  const v=await ask('Hospital name',[{id:'n',label:'Name',value:HOSP}]);
  if(!v||!v.n)return;
  try{const d=await api('POST','/settings/hospital',{name:v.n});HOSP=d.hospital;toast('Hospital name updated');render();}catch(er){toast(er.message);}
});
async function login(){
  $('#err').textContent='';
  try{
    const d=await api('POST','/auth/login',{id:'reception',secret:$('#code').value.trim()});
    if(d.user.role!=='receptionist')throw new Error('This page is only for Reception.');
    token=d.token;sessionStorage.setItem('rp_t',token);me=d.user;start();
  }catch(e){$('#err').textContent=e.message;}
}
function logout(){token=null;me=null;sessionStorage.removeItem('rp_t');clearInterval(timer);show('login');}
function start(){show('app');lastCall=null;loadHosp();go('dash');}
function go(t){tab=t;detail=null;draw();}
function draw(){
  drawNav();clearInterval(timer);$('#view').innerHTML='';render();
  timer=setInterval(()=>{if(!$('#dlg').open&&['dash','queue','appts','pay'].includes(tab))render();},4000);
}
async function render(){try{if(detail)await views.detail();else await views[tab]();$('#conn').textContent='';}catch(e){$('#conn').textContent=e.message;}}
const views={};
views.dash=async()=>{
  const st=await api('GET','/stats'),by={};st.forEach(s=>{by[s.key]=s;});
  const cur=by.current||{},name=String(cur.value||'');
  const cards=['waiting','in_lab','completed','appointments'].filter(k=>by[k]).map(k=>'<div class="glass stat" data-d="'+k+'"><div class="ico" style="background:'+META[k][1]+'26">'+META[k][0]+'</div><div style="flex:1"><div class="num">'+esc(by[k].value)+'</div><div class="lbl">'+esc(META[k][2])+'</div></div><span class="arr">&rsaquo;</span></div>').join('');
  $('#view').innerHTML=topbar()+'<div class="head"><div><h1 class="greet">'+greetWord()+',<br>'+esc(me.name)+' \u{1F44B}</h1><div class="mut">'+dateLine()+'</div></div>'+ART+'</div>'
   +'<div class="hero click" data-d="current"><div class="avatar">\u{1F464}</div><div class="vd"></div><div><small>Current Patient</small><div class="big">'+esc(name||'No patient right now')+'</div>'+(name?'<small>'+esc(cur.sub)+'</small>':'')+'</div><button class="pill-white" id="addp">Add Patient +</button></div>'
   +'<div class="row2"><h2>Today\u2019s Overview</h2><span class="chip">\u{1F4C5} Today, '+new Date().toLocaleDateString([],{day:'numeric',month:'short'})+'</span></div><div class="grid">'+cards+'</div>'
   +'<div class="payb" data-go="pay-paid"><div class="ico">\u{1F4B3}</div><div class="vd"></div><div style="flex:1"><div class="ttl">Payment History</div><small>View past payments and transactions</small></div><span class="circ">&rarr;</span></div>';
  loadDot();
};
views.detail=async()=>{
  const rows=await api('GET','/dashboard/'+detail.key);
  $('#view').innerHTML='<button class="ghost back" data-go="back">&larr; Back</button><h2 style="margin:0 4px 12px">'+esc(detail.title)+'</h2>'+(rows.length?rows.map(r=>'<div class="glass row"><div class="tok">'+esc(r.badge||'\u{1F464}')+'</div><div class="info"><b>'+esc(r.title)+'</b><small>'+esc(r.sub)+'</small></div>'+(r.tag?'<span class="chip">'+esc(r.tag)+'</span>':'')+'</div>').join(''):'<p class="empty">Nobody here right now.</p>');
};
views.patients=async()=>{
  $('#view').innerHTML='<h1 class="greet">Patients</h1><div class="glass tools"><input id="pq" placeholder="Search by name"><button id="pn">+ Register</button></div><div id="plist"></div>';
  $('#pq').oninput=()=>{clearTimeout(window.pt);window.pt=setTimeout(loadP,300);};
  await loadP();
};
async function loadP(){
  const rows=await api('GET','/patients?q='+encodeURIComponent($('#pq').value.trim()));
  $('#plist').innerHTML=rows.length?rows.map(r=>'<div class="glass row"><div class="info"><b>'+esc(r.name)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(r.age)+' yrs \u00b7 '+esc(r.gender)+' \u00b7 '+esc(r.phone)+(r.allergies?' \u00b7 Allergies: '+esc(r.allergies):'')+'</small></div><button data-act="checkin" data-id="'+esc(r.id)+'">Check in</button></div>').join(''):'<p class="empty">No patients found.</p>';
}
async function registerP(){
  const v=await ask('Register patient',[{id:'name',label:'Full name'},{id:'phone',label:'Phone',type:'tel'},{id:'age',label:'Age',type:'number'},{id:'gender',label:'Gender',type:'select',options:['Female','Male','Other']},{id:'allergies',label:'Allergies (optional)'}]);
  if(!v)return;
  try{const d=await api('POST','/patients',{name:v.name,phone:v.phone,age:v.age,gender:v.gender,allergies:v.allergies});toast('Registered. Patient ID: '+d.patientId);render();}catch(e){toast(e.message);}
}
views.queue=async()=>{
  const rows=await api('GET','/queue');
  const lab=rows.filter(r=>r.status==='in_lab'),gen=rows.filter(r=>r.status!=='in_lab');
  const g=r=>'<div class="glass row"><div class="tok">'+esc(r.tokenNumber)+'</div><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(String(r.status).replace('_',' '))+'</small></div></div>';
  const l=r=>{let t='In lab';if(r.labReady===1)t='Report ready';else if(r.labReadyBy){const m=Math.round((new Date(r.labReadyBy)-Date.now())/60000);t=m>0?'Back in '+m+' min':'Overdue by '+(-m)+' min';}
    return '<div class="glass row"><div class="tok lab">'+esc(r.tokenNumber)+'</div><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(t)+'</small></div></div>';};
  $('#view').innerHTML='<h1 class="greet">Queue</h1><h3 style="margin:14px 4px 10px">General ('+gen.length+')</h3>'+(gen.map(g).join('')||'<p class="empty">Empty.</p>')+'<h3 style="margin:14px 4px 10px">Lab ('+lab.length+')</h3>'+(lab.map(l).join('')||'<p class="empty">Empty.</p>');
};
views.appts=async()=>{
  const rows=(await api('GET','/appointments')).filter(r=>r.status==='scheduled');
  $('#view').innerHTML='<div class="head"><h1 class="greet">Appointments</h1><button id="na">+ New</button></div><div style="height:12px"></div>'+(rows.length?rows.map(r=>'<div class="glass row"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(fmt(r.dateTime))+(r.reason?' \u00b7 '+esc(r.reason):'')+'</small></div><button class="ghost" data-act="adone" data-id="'+esc(r.id)+'">Done</button><button class="ghost" data-act="acancel" data-id="'+esc(r.id)+'">Cancel</button></div>').join(''):'<p class="empty">No scheduled appointments.</p>');
  $('#na').onclick=newAppt;
};
async function newAppt(){
  const v=await ask('New appointment',[{id:'pid',label:'Patient ID (e.g. CP-000001)'},{id:'when',label:'Date and time',type:'datetime-local'},{id:'reason',label:'Reason'}]);
  if(!v)return;
  try{
    const p=await api('GET','/patients?pid='+encodeURIComponent(v.pid));
    if(!p.length)throw new Error('Patient not found');
    const d=new Date(v.when);if(isNaN(d))throw new Error('Choose a date and time');
    await api('POST','/appointments',{patientDocId:p[0].id,dateTime:d.toISOString(),reason:v.reason});toast('Appointment created');render();
  }catch(e){toast(e.message);}
}
views.pay=async()=>{
  const rows=await api('GET','/payments?view='+payView);
  const sub='<div class="head"><h1 class="greet">Payments</h1><button id="nc">+ Charge</button></div><div class="glass tools"><button class="'+(payView==='due'?'on':'ghost')+'" data-act="pv" data-v="due">Due</button><button class="'+(payView==='paid'?'on':'ghost')+'" data-act="pv" data-v="paid">History</button></div>';
  let body='';
  if(payView==='due'){
    body=rows.length?rows.map(r=>'<div class="glass row"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.patientId)+' \u00b7 '+esc(r.description)+'</small></div><div class="amt">'+money(r.amount)+'</div><button data-act="pay" data-id="'+esc(r.id)+'" data-amt="'+esc(r.amount)+'">Accept</button></div>').join(''):'<p class="empty">No payments due.</p>';
  }else{
    const today=new Date().toDateString();
    const tot=rows.filter(r=>new Date(r.paidAt).toDateString()===today).reduce((a,r)=>a+Number(r.amount),0);
    body='<h3 style="margin:4px 4px 12px">Collected today: '+money(tot)+'</h3>'+(rows.length?rows.map(r=>'<div class="glass row"><div class="info"><b>'+esc(r.patientName)+'</b><small>'+esc(r.description)+' \u00b7 '+esc(String(r.method).toUpperCase())+' \u00b7 by '+esc(r.collectedByName)+' ('+esc(ROLE[r.collectedByRole]||r.collectedByRole)+') \u00b7 '+esc(fmt(r.paidAt))+'</small></div><div class="amt ok">'+money(r.amount)+'</div></div>').join(''):'<p class="empty">No payments yet.</p>');
  }
  $('#view').innerHTML=sub+body;$('#nc').onclick=newCharge;
};
async function newCharge(){
  const v=await ask('New charge',[{id:'pid',label:'Patient ID (e.g. CP-000001)'},{id:'desc',label:'Description',value:'Lab / other charge'},{id:'amt',label:'Amount',type:'number'}]);
  if(!v)return;
  try{
    const p=await api('GET','/patients?pid='+encodeURIComponent(v.pid));
    if(!p.length)throw new Error('Patient not found');
    await api('POST','/payments',{patientDocId:p[0].id,description:v.desc,amount:v.amt});toast('Charge added');render();
  }catch(e){toast(e.message);}
}
views.more=async()=>{
  const n=await api('GET','/notifications');
  $('#view').innerHTML='<h1 class="greet">More</h1><div class="glass row" style="margin-top:14px"><div class="tok">'+esc((me.name||'R')[0])+'</div><div class="info"><b>'+esc(me.name)+'</b><small>Reception</small></div></div><h3 style="margin:18px 4px 10px">Notifications</h3>'+(n.length?n.map(x=>'<div class="glass row"><div class="info"><b>'+esc(x.title)+'</b><small>'+esc(x.body)+'</small></div></div>').join(''):'<p class="empty">No notifications.</p>')+'<button class="full" data-go="out">Sign out</button>';
};
document.addEventListener('click',async e=>{
  if(e.target.closest('#addp')){registerP();return;}
  if(e.target.closest('#pn')){registerP();return;}
  const t=e.target.closest('[data-t],[data-d],[data-act],[data-go]');if(!t)return;
  if(t.dataset.t){go(t.dataset.t);return;}
  if(t.dataset.d){detail={key:t.dataset.d,title:(META[t.dataset.d]||[0,0,'Details'])[2]};draw();return;}
  if(t.dataset.go==='pay-paid'){payView='paid';go('pay');return;}
  if(t.dataset.go==='back'){detail=null;draw();return;}
  if(t.dataset.go==='out'){logout();return;}
  const act=t.dataset.act,id=t.dataset.id;
  try{
    if(act==='pv'){payView=t.dataset.v;render();}
    else if(act==='checkin'){const d=await api('POST','/queue/checkin',{patientDocId:id});toast('Checked in. Token #'+d.token);}
    else if(act==='adone'||act==='acancel'){await api('PATCH','/appointments/'+id,{status:act==='adone'?'completed':'cancelled'});render();}
    else if(act==='pay'){
      const v=await ask('Accept payment',[{id:'amt',label:'Amount received',type:'number',value:t.dataset.amt},{id:'method',label:'Method',type:'select',options:['cash','upi','card']},{id:'note',label:'Note (optional)'}]);
      if(!v)return;
      await api('POST','/payments/'+id+'/accept',{amount:v.amt,method:v.method,note:v.note});toast('Payment collected');render();
    }
  }catch(x){toast(x.message);render();}
});
$('#go').addEventListener('click',login);
$('#code').addEventListener('keydown',e=>{if(e.key==='Enter')login();});
(async()=>{
  if(token){try{me=await api('GET','/auth/me');if(me.role==='receptionist'){start();return;}}catch(e){}}
  show('login');
})();
</script></body></html>
''';
