/// Web page served by the doctor's phone for a lab computer (open http://<doctor-ip>:8080/lab-portal).
const String labPortalHtml = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>CarePoint Lab</title>
<style>
:root{--p:#6D4CFF;--ink:#1E1B3A}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;color:var(--ink);min-height:100vh;background:radial-gradient(600px 400px at 0 0,#f9a8d466,transparent),radial-gradient(700px 500px at 100% 40%,#a78bfa55,transparent),radial-gradient(600px 400px at 20% 100%,#67e8f955,transparent),linear-gradient(135deg,#f6f0f3,#ebeef8,#f1f6f7);background-attachment:fixed}
.wrap{max-width:960px;margin:0 auto;padding:20px}
.glass{background:linear-gradient(135deg,#ffffffb8,#ffffff66);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1.4px solid #ffffffd5;border-radius:24px;box-shadow:8px 14px 28px #8b7fb833,-3px -3px 8px #fffc}
.card{padding:26px;max-width:420px;margin:12vh auto 0;text-align:center}
h1{margin:0 0 4px;font-size:24px}
input[type=text]{width:100%;padding:14px 20px;border-radius:30px;border:1.4px solid #ffffffd5;background:#ffffffb3;font-size:17px;margin:14px 0;text-transform:uppercase;text-align:center}
button{border:0;border-radius:30px;padding:12px 22px;font-size:15px;font-weight:700;color:#fff;cursor:pointer;background:linear-gradient(135deg,#a48bff,#6d4cff);box-shadow:0 8px 16px #6d4cff55}
button.ghost{background:#ffffff99;color:var(--ink);box-shadow:none;border:1.4px solid #ffffffd5}
button.tab.on{background:linear-gradient(135deg,#a48bff,#6d4cff);color:#fff}
.bar{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;margin-bottom:14px;gap:10px;flex-wrap:wrap}
.row{display:flex;align-items:center;gap:14px;padding:14px 18px;margin-bottom:10px}
.tok{width:50px;height:50px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,#b8a6ff,#6d4cff);flex:none}
.tok.urgent{background:linear-gradient(135deg,#ff9a9a,#e5484d)}
.info{flex:1;min-width:0}.info small{color:#555}.red{color:#e5484d}.ok{color:#1b9e6e;font-weight:700}
.empty{text-align:center;color:#666;padding:30px}
#err,#conn{color:#e5484d;font-weight:600}
#up{padding:12px 18px;margin-bottom:10px;font-weight:700}
</style></head><body>
<div class="wrap">
  <div id="login" class="glass card" hidden>
    <h1>CarePoint Lab</h1>
    <div>Enter your Lab staff ID from the doctor</div>
    <input id="sid" type="text" placeholder="LABT-123456" autocomplete="off">
    <button id="go">Sign in</button>
    <p id="err"></p>
  </div>
  <div id="app" hidden>
    <div class="glass bar">
      <div><b>CarePoint Lab</b> &middot; <span id="who"></span><br><small id="cnt"></small></div>
      <div>
        <button class="tab ghost on" data-tab="pending">Waiting</button>
        <button class="tab ghost" data-tab="sent">Sent</button>
        <button class="ghost" id="out">Sign out</button>
      </div>
    </div>
    <div id="conn"></div>
    <div id="up" class="glass" hidden></div>
    <div id="list"></div>
  </div>
  <input id="file" type="file" accept="application/pdf,.pdf" hidden>
</div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let token=sessionStorage.getItem('cp_t'),me=null,busy=false,rows=[],tab='pending',timer=null,pendingId=null;
const LABEL={ordered:'Waiting for sample',collected:'Sample collected',processing:'Processing',submitted:'Report sent to doctor'};
async function api(method,path,body){
  const r=await fetch(path,{method:method,headers:Object.assign({'Content-Type':'application/json'},token?{Authorization:'Bearer '+token}:{}),body:body?JSON.stringify(body):undefined});
  let d={};try{d=await r.json();}catch(e){}
  if(r.status===401&&token){logout();}
  if(!r.ok)throw new Error(d.error||'Request failed ('+r.status+')');
  return d;
}
function show(w){$('#login').hidden=w!=='login';$('#app').hidden=w!=='app';}
async function login(){
  $('#err').textContent='';
  try{
    const d=await api('POST','/auth/login',{id:$('#sid').value.trim(),secret:''});
    if(d.user.role!=='lab_technician')throw new Error('This page is only for the Lab. Use a Lab staff ID.');
    token=d.token;sessionStorage.setItem('cp_t',token);me=d.user;start();
  }catch(e){$('#err').textContent=e.message;}
}
function start(){show('app');$('#who').textContent=me.name;load();clearInterval(timer);timer=setInterval(()=>{if(!busy)load();},5000);}
function logout(){token=null;me=null;sessionStorage.removeItem('cp_t');clearInterval(timer);show('login');}
async function load(){
  try{rows=await api('GET','/lab?status=ordered,collected,processing,submitted');$('#conn').textContent='';render();}
  catch(e){$('#conn').textContent='Cannot reach the doctor phone: '+e.message;}
}
function row(r){
  const urgent=r.priority==='urgent',id=esc(r.id);
  let btn='';
  if(r.status==='ordered')btn='<button data-act="collected" data-id="'+id+'">Sample collected</button>';
  else if(r.status==='collected')btn='<button data-act="processing" data-id="'+id+'">Start processing</button>';
  else if(r.status==='processing')btn='<button data-act="upload" data-id="'+id+'">Upload PDF report</button>';
  else btn='<span class="ok">&#10003; '+esc(r.reportName||'Sent')+'</span>';
  return '<div class="row glass"><div class="tok'+(urgent?' urgent':'')+'">'+esc(r.queueToken==null?'-':r.queueToken)+'</div><div class="info"><b>'+esc(r.patientName)+'</b><div>'+esc(r.testName)+(urgent?' &middot; <b class="red">URGENT</b>':'')+'</div><small>'+esc(LABEL[r.status]||r.status)+'</small></div><div>'+btn+'</div></div>';
}
function render(){
  const pending=rows.filter(r=>r.status!=='submitted'),sent=rows.filter(r=>r.status==='submitted');
  $('#cnt').textContent=pending.length+' waiting \u00b7 '+sent.length+' sent';
  const list=tab==='pending'?pending:sent;
  $('#list').innerHTML=list.length?list.map(row).join(''):'<p class="empty">Nothing here.</p>';
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('on',b.dataset.tab===tab));
}
const toB64=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(f);});
document.addEventListener('click',async e=>{
  const t=e.target.closest('[data-act],[data-tab]');if(!t)return;
  if(t.dataset.tab){tab=t.dataset.tab;render();return;}
  const id=t.dataset.id,act=t.dataset.act;
  if(act==='upload'){pendingId=id;$('#file').value='';$('#file').click();return;}
  busy=true;
  try{await api('PATCH','/lab/'+id,{status:act});}catch(x){alert(x.message);}finally{busy=false;}
  load();
});
$('#file').addEventListener('change',async()=>{
  const f=$('#file').files[0];if(!f||!pendingId)return;
  const r=rows.find(x=>x.id===pendingId);
  if(f.type!=='application/pdf'&&!f.name.toLowerCase().endsWith('.pdf')){alert('Please choose a PDF file.');return;}
  if(f.size>15*1024*1024){alert('PDF is larger than 15 MB.');return;}
  const note=prompt('Short note for the doctor (optional):','');
  if(note===null)return;
  if(!confirm('Send "'+f.name+'" to the doctor for '+(r?r.patientName+' - '+r.testName:'this test')+'?'))return;
  busy=true;$('#up').hidden=false;$('#up').textContent='Uploading '+f.name+' ...';
  try{const data=await toB64(f);await api('POST','/lab/'+pendingId+'/report',{name:f.name,data:data,notes:note});$('#up').textContent='Sent to the doctor.';}
  catch(x){$('#up').textContent='';alert(x.message);}
  finally{busy=false;pendingId=null;setTimeout(()=>{$('#up').hidden=true;},2500);load();}
});
$('#go').addEventListener('click',login);
$('#sid').addEventListener('keydown',e=>{if(e.key==='Enter')login();});
$('#out').addEventListener('click',logout);
(async()=>{
  if(token){try{me=await api('GET','/auth/me');if(me.role==='lab_technician'){start();return;}}catch(e){}}
  show('login');
})();
</script></body></html>
''';
