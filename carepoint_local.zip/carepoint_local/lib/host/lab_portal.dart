/// Lab web page, designed like the app (open http://<doctor-ip>:8080/lab-portal).
const String labPortalHtml = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0f62c9"><meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><link rel="manifest" href="/lab.webmanifest"><link rel="icon" href="/icon.svg"><link rel="apple-touch-icon" href="/icon.svg">
<title>CarePoint Lab</title>
<style>
:root{--p:#0f62c9;--ink:#0b2a55;--mut:#5b6b86}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ink);min-height:100vh;background:radial-gradient(520px 380px at 0 0,#bfdbfe66,transparent),radial-gradient(620px 460px at 100% 38%,#93c5fd55,transparent),radial-gradient(520px 380px at 15% 100%,#bae6fd55,transparent),linear-gradient(135deg,#f3f8ff,#eaf3fe,#f4f9ff);background-attachment:fixed}
.app{max-width:560px;margin:0 auto;padding:16px 16px 120px}
.glass{background:linear-gradient(135deg,#ffffffc0,#ffffff66);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border:1.4px solid #ffffffd9;border-radius:24px;box-shadow:8px 14px 28px #4a78b833,-3px -3px 8px #fffc}
h1,h2,h3,h4{margin:0}
.head{display:flex;align-items:center;justify-content:space-between;gap:10px}
.greet{font-size:25px;font-weight:800}
.mut{color:var(--mut);font-size:14px}
.hero{margin-top:12px;border-radius:28px;padding:16px;display:flex;align-items:center;gap:14px;color:#fff;background:linear-gradient(100deg,#2f86e0,#1b6fd0 55%,#0b4a9e);box-shadow:0 14px 28px #0f62c955;border:1.2px solid #ffffff99}
.hero.click{cursor:pointer}
.avatar{width:60px;height:60px;border-radius:50%;background:#ffffff2e;border:1.5px solid #ffffffaa;display:flex;align-items:center;justify-content:center;font-size:30px;flex:none}
.hero small{opacity:.85}.hero .big{font-size:21px;font-weight:800;line-height:1.15}
.pill-white{margin-left:auto;background:#fff!important;color:#0b4a9e!important;box-shadow:0 6px 12px #0b4a9e33!important;white-space:nowrap}
.row2{display:flex;align-items:center;justify-content:space-between;margin:22px 0 14px}
.row2 h2{font-size:21px}
.chip{background:#ffffffb0;border:1.2px solid #fffd;border-radius:20px;padding:7px 12px;font-size:13px;font-weight:600;white-space:nowrap}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.stat{display:flex;align-items:center;gap:10px;padding:12px;cursor:pointer;min-height:84px}
.stat.wide{margin-top:14px;padding:16px}
.ico{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:22px;flex:none;border:1.2px solid #fffd}
.num{font-size:27px;font-weight:800;line-height:1.05}.lbl{font-size:13px;line-height:1.15}.ttl{font-size:19px;font-weight:800}
.arr{color:#999;font-size:18px}
.row{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:10px}
.row.click{cursor:pointer}
.tok{width:46px;height:46px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;background:linear-gradient(135deg,#7db8f5,#0f62c9);flex:none}
.tok.lab{background:linear-gradient(135deg,#7dd3fc,#0ea5e9)}.tok.urgent{background:linear-gradient(135deg,#ff9a9a,#e5484d)}
.info{flex:1;min-width:0}.info small{display:block;color:var(--mut)}
.ok{color:#1b9e6e;font-weight:700}.red{color:#e5484d}.amt{font-weight:800;font-size:18px}
.empty{text-align:center;color:#666;padding:26px}
button,.btn{border:0;border-radius:30px;padding:11px 20px;font-size:14px;font-weight:700;color:#fff;cursor:pointer;background:linear-gradient(135deg,#4ba3f2,#0f62c9);box-shadow:0 8px 16px #0f62c955}
button.ghost{background:#ffffff99;color:var(--ink);box-shadow:none;border:1.4px solid #ffffffd5}
button.on{background:linear-gradient(135deg,#4ba3f2,#0f62c9);color:#fff}
button.full{width:100%;margin-top:18px;padding:14px}
button:disabled{opacity:.6;cursor:default}
input,select{width:100%;padding:12px 18px;border-radius:24px;border:1.4px solid #ffffffd5;background:#ffffffc0;font-size:15px;margin:6px 0;font-family:inherit}
.tools{display:flex;gap:10px;padding:12px 14px;margin:14px 0;align-items:center}
.tools input{margin:0;flex:1}
.card{padding:26px;max-width:420px;margin:12vh auto 0;text-align:center}
.card input{text-transform:uppercase;text-align:center;font-size:18px;margin:14px 0}
#err,#conn{color:#e5484d;font-weight:600}
nav{position:fixed;left:0;right:0;bottom:calc(10px + env(safe-area-inset-bottom));display:flex;justify-content:center;z-index:5}
nav .bar{display:flex;width:min(540px,calc(100% - 20px));padding:6px;border-radius:30px}
nav button{flex:1;border:0;background:none;box-shadow:none;color:#55546b;padding:8px 2px;border-radius:24px;font-size:11px;font-weight:500;display:flex;flex-direction:column;align-items:center;gap:2px}
nav button.on{background:linear-gradient(135deg,#e3eeff,#d3e5ff);color:#0b4a9e;font-weight:800;box-shadow:0 4px 10px #0f62c933}
nav .e{font-size:20px}
.bar2{height:10px;border-radius:8px;background:#ffffffaa;overflow:hidden;margin-top:10px}.bar2 i{display:block;height:100%;background:linear-gradient(90deg,#4ba3f2,#0f62c9)}
#toast{position:fixed;left:50%;bottom:96px;transform:translateX(-50%);background:#0b2a55e6;color:#fff;padding:12px 22px;border-radius:30px;font-weight:600;z-index:9}
.back{margin:6px 0 12px}
.steps{display:flex;margin:18px 0 4px}.st{flex:1;text-align:center;font-size:11px;color:var(--mut)}
.st i{display:flex;width:30px;height:30px;margin:0 auto 4px;border-radius:50%;background:#ffffffaa;border:1.2px solid #fffd;align-items:center;justify-content:center;font-style:normal;font-weight:800;font-size:13px}
.st.on{color:#0b4a9e;font-weight:700}.st.on i{background:linear-gradient(135deg,#4ba3f2,#0f62c9);color:#fff;border-color:transparent}
.pad{padding:18px;margin-bottom:14px}.pad label{display:block;font-size:13px;font-weight:600;margin-top:12px}
.chipu{display:inline-block;background:#fee2e2;color:#e5484d;font-weight:800;font-size:12px;border-radius:14px;padding:3px 10px;margin-left:8px;vertical-align:middle}
.done{text-align:center;padding:22px}.done .big{font-size:42px}

.top{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px;line-height:1.08;color:#0b2a55}
.logo{width:46px;height:46px}
.bell{position:relative;width:54px;height:54px;padding:0;border-radius:18px;background:#ffffffd8;box-shadow:0 8px 16px #4a78b833;color:#0b2a55;font-size:22px;border:1.4px solid #fff}
.bell i{position:absolute;top:13px;right:14px;width:10px;height:10px;border-radius:50%;background:#f59e0b;border:2px solid #fff}
.art{width:190px;height:118px;flex:none;margin-right:-16px;margin-bottom:-14px}
.greet{line-height:1.12}
.hero .vd,.payb .vd{width:1px;align-self:stretch;background:#ffffff59}
.stat,.row{background:linear-gradient(135deg,#ffffff,#f5f9ff)}
.stat .arr{font-size:26px;line-height:1}
.payb{margin-top:16px;border-radius:28px;padding:18px;display:flex;align-items:center;gap:14px;color:#fff;background:linear-gradient(100deg,#1f7ddb,#0b4a9e);box-shadow:0 14px 28px #0f62c955;cursor:pointer}
.payb .ico{background:#ffffff26;border:1.5px solid #ffffffaa;width:56px;height:56px}
.payb .ttl{font-size:21px}.payb small{opacity:.9;font-size:14px}
.payb .circ{width:44px;height:44px;border-radius:50%;background:#ffffff33;display:flex;align-items:center;justify-content:center;font-size:20px;flex:none}
.hero .pill-white{box-shadow:0 6px 12px #0b4a9e33!important}
</style></head><body>
<div id="login" class="app" hidden>
  <div class="glass card">
    <h1>CarePoint Lab</h1>
    <p class="mut">Enter your Lab staff ID from the doctor</p>
    <input id="sid" type="text" placeholder="LABT-123456" autocomplete="off">
    <button id="go">Sign in</button>
    <p id="err"></p>
  </div>
</div>
<div id="app" class="app" hidden><div id="conn"></div><div id="view"></div></div>
<nav id="nav" hidden><div class="bar glass" id="navbar"></div></nav>

<div id="toast" hidden></div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(method,path,body){
  const r=await fetch(path,{method:method,headers:Object.assign({'Content-Type':'application/json'},token?{Authorization:'Bearer '+token}:{}),body:body?JSON.stringify(body):undefined});
  let d={};try{d=await r.json();}catch(e){}
  if(r.status===401&&token&&path!=='/auth/login'){logout();}
  if(!r.ok)throw new Error(d.error||'Request failed ('+r.status+')');
  return d;
}
function toast(m){const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>{t.hidden=true;},3500);}
const fmt=iso=>iso?new Date(iso).toLocaleString([],{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'';
const money=v=>'\u20b9'+(Number(v)%1===0?Number(v):Number(v).toFixed(2));
const greetWord=()=>{const h=new Date().getHours();return h<12?'Good Morning':h<17?'Good Afternoon':'Good Evening';};
const dateLine=()=>new Date().toLocaleDateString([],{weekday:'long',day:'numeric',month:'long'});
const LOGO='<svg class="logo" viewBox="0 0 48 48"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3b9bf0"/><stop offset="1" stop-color="#0b4a9e"/></linearGradient></defs><path d="M18 4h12a2 2 0 0 1 2 2v10h10a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H32v10a2 2 0 0 1-2 2H18a2 2 0 0 1-2-2V32H6a2 2 0 0 1-2-2V18a2 2 0 0 1 2-2h10V6a2 2 0 0 1 2-2z" fill="url(#lg)"/><path d="M21 12h6v9h9v6h-9v9h-6v-9h-9v-6h9z" fill="#fff" opacity=".92"/></svg>';
const ART='<svg class="art" viewBox="0 0 200 130"><ellipse cx="110" cy="122" rx="104" ry="9" fill="#9bd48a"/><rect x="46" y="64" width="146" height="50" rx="3" fill="#e9eef6"/><rect x="46" y="60" width="146" height="6" fill="#c9d4e4"/><rect x="118" y="22" width="52" height="92" rx="3" fill="#2f7fd6"/><g fill="#8fc2f4" opacity=".7"><rect x="122" y="56" width="10" height="10"/><rect x="136" y="56" width="10" height="10"/><rect x="150" y="56" width="10" height="10"/><rect x="122" y="72" width="10" height="10"/><rect x="136" y="72" width="10" height="10"/><rect x="150" y="72" width="10" height="10"/><rect x="122" y="88" width="10" height="10"/><rect x="136" y="88" width="10" height="10"/><rect x="150" y="88" width="10" height="10"/></g><path d="M139 30h10v8h8v10h-8v8h-10v-8h-8V38h8z" fill="#fff"/><g fill="#3f8be0"><rect x="54" y="72" width="12" height="9"/><rect x="72" y="72" width="12" height="9"/><rect x="90" y="72" width="12" height="9"/><rect x="54" y="88" width="12" height="9"/><rect x="72" y="88" width="12" height="9"/><rect x="90" y="88" width="12" height="9"/></g><rect x="172" y="76" width="18" height="38" fill="#c9dcf3"/><rect x="26" y="96" width="5" height="18" fill="#8b6b4a"/><circle cx="28" cy="86" r="15" fill="#3f9b4f"/><circle cx="17" cy="95" r="10" fill="#4aa85a"/><circle cx="40" cy="95" r="10" fill="#4aa85a"/><circle cx="62" cy="116" r="6" fill="#4aa85a"/><circle cx="80" cy="117" r="5" fill="#5bb86a"/></svg>';
const HOSP='City Care Hospital';
function topbar(){return '<div class="top"><div class="brand">'+LOGO+'<div>'+esc(HOSP).replace(/ (?=[^ ]+$)/,'<br>')+'</div></div><button class="bell" data-t="more" aria-label="Notifications">\u{1F514}<i id="dot" hidden></i></button></div>';}
function loadDot(){api('GET','/notifications').then(n=>{const d=$('#dot');if(d&&n.length)d.hidden=false;}).catch(()=>{});}
function drawNav(){$('#navbar').innerHTML=NAV.map(n=>'<button data-t="'+n[0]+'" class="'+(tab===n[0]?'on':'')+'"><span class="e">'+n[1]+'</span><span>'+n[2]+'</span></button>').join('');}
function show(w){$('#login').hidden=w!=='login';$('#app').hidden=w!=='app';$('#nav').hidden=w!=='app';}
let token=sessionStorage.getItem('lp_t'),me=null,tab='queue',timer=null,patient=null,curTest=null;
const NAV=[['queue','🔬','Lab Queue'],['more','⋯','More']];
const LABEL={ordered:'Waiting for sample',collected:'Sample collected',processing:'Processing',submitted:'Completed'};
const toB64=f=>new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(',')[1]);r.onerror=rej;r.readAsDataURL(f);});
async function login(){
  $('#err').textContent='';
  try{
    const d=await api('POST','/auth/login',{id:$('#sid').value.trim(),secret:''});
    if(d.user.role!=='lab_technician')throw new Error('This page is only for the Lab. Use a Lab staff ID.');
    token=d.token;sessionStorage.setItem('lp_t',token);me=d.user;start();
  }catch(e){$('#err').textContent=e.message;}
}
function logout(){token=null;me=null;sessionStorage.removeItem('lp_t');clearInterval(timer);show('login');}
function start(){show('app');go('queue');}
function go(t){tab=t;patient=null;curTest=null;draw();}
function draw(){
  drawNav();clearInterval(timer);$('#view').innerHTML='';render();
  timer=setInterval(()=>{if(tab==='queue'&&!curTest)render();},5000);
}
async function render(){try{await views[tab]();$('#conn').textContent='';}catch(e){$('#conn').textContent=e.message;}}
const views={};
views.queue=async()=>{
  const rows=await api('GET','/lab?status=ordered,collected,processing,submitted');
  if(patient&&curTest){testView(rows);return;}
  if(patient){patientView(rows);return;}
  const order=[],g={};
  rows.forEach(r=>{if(!g[r.patientDocId]){g[r.patientDocId]=[];order.push(r.patientDocId);}g[r.patientDocId].push(r);});
  const open=k=>g[k].some(r=>r.status!=='submitted');
  const todo=order.filter(open),done=order.filter(k=>!open(k));
  const card=k=>{const rs=g[k],f=rs[0],dn=rs.filter(r=>r.status==='submitted').length,urgent=rs.some(r=>r.priority==='urgent');
    return '<div class="glass row click" data-p="'+esc(k)+'"><div class="tok'+(urgent?' urgent':'')+'">'+esc(f.queueToken==null?'-':f.queueToken)+'</div><div class="info"><b>'+esc(f.patientName)+'</b><small>'+rs.length+(rs.length===1?' test':' tests')+' \u00b7 '+dn+' done'+(urgent?' \u00b7 URGENT':'')+'</small></div><span class="'+(dn===rs.length?'ok':'arr')+'">'+(dn===rs.length?'\u2713':'&rarr;')+'</span></div>';};
  $('#view').innerHTML=topbar()+'<div class="head"><div><h1 class="greet">'+greetWord()+',<br>'+esc(me.name)+' \u{1F44B}</h1><div class="mut">'+dateLine()+'</div></div>'+ART+'</div>'
   +'<div class="hero"><div class="avatar">\u{1F52C}</div><div class="vd"></div><div><small>Lab queue</small><div class="big">'+todo.length+(todo.length===1?' patient waiting':' patients waiting')+'</div></div></div>'
   +'<div class="row2"><h2>Patients</h2><span class="chip">Tap a patient to open tests</span></div>'
   +(todo.map(card).join('')||'<p class="empty">No tests waiting.</p>')
   +(done.length?'<h3 style="margin:18px 4px 10px">Completed today</h3>'+done.map(card).join(''):'');
  loadDot();
};
function patientView(rows){
  const mine=rows.filter(r=>r.patientDocId===patient);
  if(!mine.length){$('#view').innerHTML='<button class="ghost back" data-go="back">&larr; Back</button><p class="empty">No tests for this patient.</p>';return;}
  const done=mine.filter(r=>r.status==='submitted').length,f=mine[0],urgent=mine.some(r=>r.priority==='urgent');
  const tests=mine.map(r=>{
    const fin=r.status==='submitted';
    return '<div class="glass row click" data-test="'+esc(r.id)+'"><div class="tok lab">&#129514;</div><div class="info"><b>'+esc(r.testName)+'</b><small>'+esc(LABEL[r.status]||r.status)+(r.priority==='urgent'?' \u00b7 URGENT':'')+'</small></div><span class="'+(fin?'ok':'arr')+'">'+(fin?'\u2713':'&rarr;')+'</span></div>';
  }).join('');
  $('#view').innerHTML='<button class="ghost back" data-go="back">&larr; Back</button>'
   +'<div class="glass" style="padding:16px;margin-bottom:14px"><div style="display:flex;align-items:center;gap:12px"><div class="tok'+(urgent?' urgent':'')+'">'+esc(f.queueToken==null?'-':f.queueToken)+'</div><div><h2>'+esc(f.patientName)+'</h2><div class="mut">Patient profile \u00b7 tests from the doctor'+(urgent?' \u00b7 <span class="red"><b>URGENT</b></span>':'')+'</div></div></div>'
   +'<div class="mut" style="margin-top:12px">'+done+' of '+mine.length+' tests completed</div><div class="bar2"><i style="width:'+Math.round(done*100/mine.length)+'%"></i></div></div>'
   +'<div class="row2" style="margin-top:6px"><h2>Tests</h2><span class="chip">Tap a test to open it</span></div>'+tests;
}
const STEPS=[['ordered','Ordered'],['collected','Sample'],['processing','Processing'],['submitted','Done']];
function testView(rows){
  const r=rows.find(x=>x.id===curTest);
  if(!r){curTest=null;patientView(rows);return;}
  const idx=STEPS.findIndex(x=>x[0]===r.status),fin=r.status==='submitted',id=esc(r.id);
  const steps='<div class="steps">'+STEPS.map((x,i)=>'<div class="st'+(i<=idx?' on':'')+'"><i>'+((i<idx||fin)?'\u2713':(i+1))+'</i>'+x[1]+'</div>').join('')+'</div>';
  let body='';
  if(r.status==='ordered')body='<p class="mut" style="margin:14px 0 0">Collect the sample, then tap the button.</p><button class="full" data-act="collected" data-id="'+id+'">Sample collected</button>';
  else if(r.status==='collected')body='<button class="full ghost" data-act="processing" data-id="'+id+'" style="margin-top:14px">Start processing</button>';
  if(r.status==='collected'||r.status==='processing'){
    body+='<div class="glass pad" style="margin-top:14px"><h3>Finish this test</h3><label>PDF report (optional)</label><input id="cfile" type="file" accept=".pdf,application/pdf"><label>Result note (optional)</label><input id="cnote" type="text" placeholder="Short note for the doctor" style="text-transform:none"><button class="full" id="cdone" data-act="complete">&#10003; Complete</button></div>';
  }
  if(fin)body='<div class="glass done" style="margin-top:14px"><div class="big">&#9989;</div><h3>Test completed</h3><p class="ok" style="margin:8px 0 0">'+(r.hasReport===1?'PDF report attached':'Completed without a PDF')+'</p>'+(r.result?'<p class="mut">Note: '+esc(r.result)+'</p>':'')+'<p class="mut">Sent to the doctor.</p></div>';
  $('#view').innerHTML='<button class="ghost back" data-go="backt">&larr; '+esc(r.patientName)+'</button>'
   +'<div class="glass pad"><h2>'+esc(r.testName)+(r.priority==='urgent'?'<span class="chipu">URGENT</span>':'')+'</h2><div class="mut" style="margin-top:4px">'+esc(r.patientName)+(r.queueToken==null?'':' \u00b7 Token '+esc(r.queueToken))+'</div>'
   +(r.orderNotes?'<div style="margin-top:12px;padding:10px 14px;border-radius:16px;background:#ffffffaa"><small class="mut">Doctor note</small><div>'+esc(r.orderNotes)+'</div></div>':'')+steps+'</div>'+body;
}
views.more=async()=>{
  const n=await api('GET','/notifications');
  $('#view').innerHTML='<h1 class="greet">More</h1><div class="glass row" style="margin-top:14px"><div class="tok">'+esc((me.name||'L')[0])+'</div><div class="info"><b>'+esc(me.name)+'</b><small>Lab</small></div></div><h3 style="margin:18px 4px 10px">Notifications</h3>'+(n.length?n.map(x=>'<div class="glass row"><div class="info"><b>'+esc(x.title)+'</b><small>'+esc(x.body)+'</small></div></div>').join(''):'<p class="empty">No notifications.</p>')+'<button class="full" data-go="out">Sign out</button>';
};
async function completeTest(){
  const f=$('#cfile').files[0];
  if(f){
    if(!(f.type==='application/pdf'||f.name.toLowerCase().endsWith('.pdf'))){toast('Please choose a PDF file');return;}
    if(f.size>15*1024*1024){toast('PDF is larger than 15 MB');return;}
  }
  const btn=$('#cdone');btn.disabled=true;btn.textContent='Sending...';
  try{
    const data=f?await toB64(f):'';
    await api('POST','/lab/'+curTest+'/complete',{name:f?f.name:'',data:data,notes:$('#cnote').value.trim()});
    toast('Test completed');curTest=null;draw();
  }catch(x){toast(x.message);btn.disabled=false;btn.innerHTML='&#10003; Complete';}
}
document.addEventListener('click',async e=>{
  const t=e.target.closest('[data-t],[data-p],[data-test],[data-act],[data-go]');if(!t)return;
  if(t.dataset.t){go(t.dataset.t);return;}
  if(t.dataset.p){patient=t.dataset.p;curTest=null;draw();return;}
  if(t.dataset.test){curTest=t.dataset.test;draw();return;}
  if(t.dataset.go==='back'){patient=null;curTest=null;draw();return;}
  if(t.dataset.go==='backt'){curTest=null;draw();return;}
  if(t.dataset.go==='out'){logout();return;}
  const act=t.dataset.act;
  if(act==='complete'){completeTest();return;}
  try{await api('PATCH','/lab/'+t.dataset.id,{status:act});render();}catch(x){toast(x.message);}
});
$('#go').addEventListener('click',login);
$('#sid').addEventListener('keydown',e=>{if(e.key==='Enter')login();});
(async()=>{
  if(token){try{me=await api('GET','/auth/me');if(me.role==='lab_technician'){start();return;}}catch(e){}}
  show('login');
})();
</script></body></html>
''';
