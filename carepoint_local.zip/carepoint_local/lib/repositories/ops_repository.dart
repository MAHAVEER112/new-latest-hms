import '../core/api/api_client.dart';
import '../core/compat.dart';

class OpsRepository {
  final _a = Api.i;

  // Appointments
  Stream<Snap> appointments(String org) => poll(() async => snapOf(await _a.get('/appointments')));
  Future<Rec?> findPatient(String org, String pid) async {
    final l = snapOf(await _a.get('/patients?pid=${Uri.encodeQueryComponent(pid.trim())}')).docs;
    return l.isEmpty ? null : l.first;
  }
  Future<void> createAppointment({required String org, required String uid, required Rec patient, required DateTime when, required String reason}) =>
      _a.post('/appointments', {'patientDocId': patient.id, 'dateTime': when.toUtc().toIso8601String(), 'reason': reason});
  Future<void> updateAppointment(String id, Map<String, dynamic> data) =>
      _a.patch('/appointments/$id', {for (final k in ['dateTime', 'status', 'reason']) if (data.containsKey(k)) k: data[k]});

  // Pharmacy
  Stream<Snap> inventory(String org) => poll(() async => snapOf(await _a.get('/inventory')));
  Stream<Snap> prescriptions(String org) => poll(() async => snapOf(await _a.get('/prescriptions')));
  Stream<Snap> invoices(String org) => poll(() async => snapOf(await _a.get('/invoices')));
  Future<Snap> dispensedFor(String rxId) async => snapOf(await _a.get('/prescriptions/$rxId/dispensed'));
  Future<void> addStock({required String org, required String uid, required String name, required String batch, required DateTime expiry, required int stock, required double price}) =>
      _a.post('/inventory', {'name': name, 'batch': batch, 'expiry': expiry.toUtc().toIso8601String(), 'stock': stock, 'price': price});
  Future<void> dispense({required String org, required String uid, required String rxId, required String patientName, required List<(String, int)> lines}) =>
      _a.post('/prescriptions/$rxId/dispense', {'lines': [for (final (n, q) in lines) {'name': n, 'qty': q}]});
  Future<void> markPaid(String id) => _a.patch('/invoices/$id/pay', {});

  // Admin / dashboards
  Stream<Snap> staff(String org) => poll(() async => snapOf(await _a.get('/users')), every: const Duration(seconds: 10));
  Stream<Snap> audit(String org) => poll(() async => snapOf(await _a.get('/audit')), every: const Duration(seconds: 10));
  Future<void> setStaffActive(String uid, bool active) => _a.patch('/users/$uid/active', {'active': active});
  Stream<List<Map<String, dynamic>>> stats() => poll(() async => [for (final e in await _a.get('/stats') as List) Map<String, dynamic>.from(e)], every: const Duration(seconds: 5));
  Stream<List<Map<String, dynamic>>> detail(String key) =>
      poll(() async => [for (final e in await _a.get('/dashboard/$key') as List) Map<String, dynamic>.from(e)], every: const Duration(seconds: 4));
  Future<Map<String, dynamic>> revenue() async => Map<String, dynamic>.from(await _a.get('/reports/revenue'));
  Future<List<Rec>> notifications() async => snapOf(await _a.get('/notifications')).docs;

  // Doctor: codes, staff IDs, password
  Future<String> receptionCode() async => (await _a.post('/doctor/reception-code'))['code'] as String;
  Future<String> createStaff(String role, String name) async => (await _a.post('/users', {'role': role, 'name': name}))['staffId'] as String;
  Future<String> regenerate(String id) async => (await _a.post('/users/$id/regenerate'))['staffId'] as String;
  Future<void> changePassword(String o, String n) => _a.post('/doctor/password', {'oldPassword': o, 'newPassword': n});

  // Payments (doctor or reception)
  Stream<Snap> payments(String view) => poll(() async => snapOf(await _a.get('/payments?view=$view')));
  Future<void> acceptPayment(String id, num amount, String method, String note) => _a.post('/payments/$id/accept', {'amount': amount, 'method': method, 'note': note});
  Future<void> addCharge(String patientDocId, String description, num amount) => _a.post('/payments', {'patientDocId': patientDocId, 'description': description, 'amount': amount});
  Future<num> fee() async => (await _a.get('/settings'))['fee'] as num;
  Future<String> hospital() async => '${(await _a.get('/settings'))['hospital'] ?? 'City Care Hospital'}';
  Future<void> setHospital(String name) => _a.post('/settings/hospital', {'name': name});
  Future<void> setFee(num v) => _a.post('/settings/fee', {'fee': v});
}
