import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../core/api/api_client.dart';
import '../core/compat.dart';

class ClinicalRepository {
  final _a = Api.i;

  Future<void> saveConsultation({
    required String org, required String uid, required String queueId, required String patientDocId, required String patientName,
    required Map<String, String> vitals, required Map<String, String> clinical, required List<Map<String, String>> meds,
    required List<String> tests, required String priority, String labNotes = '', int labMinutes = 30,
  }) => _a.post('/consultations', {'queueId': queueId, 'vitals': vitals, 'clinical': clinical, 'meds': meds, 'tests': tests, 'priority': priority, 'labNotes': labNotes, 'labMinutes': labMinutes});

  Stream<Snap> labByStatus(String org, List<String> statuses) => poll(() async => snapOf(await _a.get('/lab?status=${statuses.join(',')}')));

  Future<void> techUpdate(String id, String status, String uid) => _a.patch('/lab/$id', {'status': status});

  Future<void> uploadReport(String id, String fileName, List<int> bytes, String notes) =>
      _a.post('/lab/$id/report', {'name': fileName, 'data': base64Encode(bytes), 'notes': notes}, const Duration(seconds: 90));

  /// Downloads the lab PDF from the doctor's phone to a temp file and returns its path.
  Future<String> downloadReport(String id) async {
    final bytes = await _a.getBytes('/lab/$id/report');
    final f = File(p.join((await getTemporaryDirectory()).path, 'report-$id.pdf'));
    await f.writeAsBytes(bytes);
    return f.path;
  }

  Stream<Snap> pendingReviews(String org) => poll(() async => snapOf(await _a.get('/reviews')));
  Future<Snap> resultsForOrder(String orderId) async => snapOf(await _a.get('/reviews/order/$orderId/results'));
  Future<void> completeReview(String id, String interpretation, String comments, DateTime? followUp, String uid) =>
      _a.patch('/reviews/$id', {'interpretation': interpretation, 'comments': comments, 'followUp': followUp?.toUtc().toIso8601String()});

  Future<Map<String, dynamic>> history(String patientDocId) async => Map<String, dynamic>.from(await _a.get('/patients/$patientDocId/history'));
}
