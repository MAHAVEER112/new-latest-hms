import '../core/api/api_client.dart';
import '../core/compat.dart';

class ClinicRepository {
  final _a = Api.i;

  Future<List<Rec>> searchPatients(String org, String q) async => snapOf(await _a.get('/patients?q=${Uri.encodeQueryComponent(q.trim())}')).docs;

  Future<String> registerPatient({required String org, required String uid, required String name, required String phone,
      required String gender, required int age, String allergies = ''}) async =>
      (await _a.post('/patients', {'name': name, 'phone': phone, 'gender': gender, 'age': age, 'allergies': allergies}))['patientId'] as String;

  Future<int> checkIn({required String org, required String uid, required String patientDocId, required String patientName, required String patientId}) async =>
      (await _a.post('/queue/checkin', {'patientDocId': patientDocId}))['token'] as int;

  Stream<Snap> queue(String org) => poll(() async => snapOf(await _a.get('/queue')));

  Future<void> setQueueStatus(String id, String status, String uid) => _a.patch('/queue/$id', {'status': status});
}
