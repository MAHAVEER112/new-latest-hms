import '../core/api/api_client.dart';
import '../core/constants/roles.dart';
import '../models/app_user.dart';

class AuthRepository {
  final _a = Api.i;

  AppUser? _user(Map m) {
    final role = UserRole.parse(m['role'] as String?);
    if (role == null) return null;
    return AppUser(uid: m['id'], email: '${m['email'] ?? ''}', displayName: m['name'], role: role, organizationId: 'local');
  }

  Future<AppUser?> restore() async {
    if (_a.token == null) return null;
    try { return _user(await _a.get('/auth/me')); } catch (_) { return null; }
  }

  Future<AppUser?> signIn(String id, String secret) async {
    final r = await _a.post('/auth/login', {'id': id, 'secret': secret});
    await _a.setToken(r['token']);
    return _user(r['user']);
  }

  Future<void> signOut() => _a.setToken(null);
}
