import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/glass.dart';
import 'core/theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'routes/app_router.dart';

class CarePointApp extends StatefulWidget {
  const CarePointApp({super.key});
  @override
  State<CarePointApp> createState() => _CarePointAppState();
}

class _CarePointAppState extends State<CarePointApp> {
  late final _router = buildRouter(context.read<AuthProvider>());
  @override
  Widget build(BuildContext context) => MaterialApp.router(
        title: 'CarePoint HMS',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        routerConfig: _router,
        builder: (c, child) => AppBackground(child: child ?? const SizedBox.shrink()),
      );
}
