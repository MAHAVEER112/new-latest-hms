import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../host/server.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';
import 'backup_dialog.dart';

class StaffCodesScreen extends StatefulWidget {
  const StaffCodesScreen({super.key});
  @override
  State<StaffCodesScreen> createState() => _StaffCodesScreenState();
}

class _StaffCodesScreenState extends State<StaffCodesScreen> {
  void _snack(String m) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m))); }

  Future<void> _show(String title, String value, String note) => showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(title),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            SelectableText(value, style: Theme.of(ctx).textTheme.headlineSmall), const SizedBox(height: 8), Text(note)]),
          actions: [TextButton(onPressed: () => Clipboard.setData(ClipboardData(text: value)), child: const Text('Copy')), FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Done'))],
        ),
      );

  Future<void> _newStaff() async {
    final repo = context.read<OpsRepository>();
    final name = TextEditingController();
    String role = 'lab_technician';
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
      title: const Text('New staff ID'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: role, decoration: const InputDecoration(labelText: 'Role'), items: const [
          DropdownMenuItem(value: 'lab_technician', child: Text('Lab')),
          DropdownMenuItem(value: 'pharmacy', child: Text('Pharmacy')),
        ], onChanged: (v) => set(() => role = v!)),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () { if (name.text.trim().isNotEmpty) Navigator.pop(ctx, true); }, child: const Text('Create'))],
    )));
    if (ok != true) return;
    try { _show('Permanent staff ID', await repo.createStaff(role, name.text.trim()), 'Give this ID to ${name.text.trim()}. It works until you disable or regenerate it.'); }
    catch (e) { _snack('$e'); }
  }

  Future<void> _password() async {
    final repo = context.read<OpsRepository>();
    final o = TextEditingController(), n = TextEditingController();
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Change password'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: o, obscureText: true, decoration: const InputDecoration(labelText: 'Current password')),
        const SizedBox(height: 10),
        TextField(controller: n, obscureText: true, decoration: const InputDecoration(labelText: 'New password (8+)')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Change'))],
    ));
    if (ok != true) return;
    try { await repo.changePassword(o.text, n.text); _snack('Password changed'); } catch (e) { _snack('$e'); }
  }

  Future<void> _fee() async {
    final repo = context.read<OpsRepository>();
    num cur = 0;
    try { cur = await repo.fee(); } catch (_) {}
    final c = TextEditingController(text: cur % 1 == 0 ? '${cur.toInt()}' : '$cur');
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Consultation fee'),
      content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (₹) added at every check-in')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save'))],
    ));
    if (ok != true) return;
    final v = num.tryParse(c.text.trim());
    if (v == null || v < 0) { _snack('Enter a valid amount'); return; }
    try { await repo.setFee(v); _snack('Fee saved'); } catch (e) { _snack('$e'); }
  }

  Future<void> _wifi() async {
    final a = await LocalServer.i.addresses();
    if (!mounted) return;
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Wi-Fi address'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("Staff phones type this address. Everyone must be on the same Wi-Fi, or on this phone's hotspot."),
        const SizedBox(height: 10),
        if (a.isEmpty) const Text('No network found. Turn on Wi-Fi or the hotspot.'),
        for (final x in a)
          Row(children: [
            Expanded(child: SelectableText(x, style: Theme.of(ctx).textTheme.titleLarge)),
            IconButton(icon: const Icon(Icons.copy), onPressed: () => Clipboard.setData(ClipboardData(text: x))),
          ]),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
    ));
  }

  Future<void> _links() async {
    final a = await LocalServer.i.addresses();
    if (!mounted) return;
    Widget link(BuildContext ctx, String label, String url) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
              SelectableText(url),
            ])),
            IconButton(icon: const Icon(Icons.copy), onPressed: () => Clipboard.setData(ClipboardData(text: url))),
          ]),
        );
    await showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Computer links'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Open in a browser on a computer connected to the same Wi-Fi.'),
        const SizedBox(height: 12),
        if (a.isEmpty) const Text('No network found. Turn on Wi-Fi or the hotspot.'),
        for (final x in a.take(1)) ...[
          link(ctx, 'Lab computer', 'http://$x:8080/lab-portal'),
          link(ctx, 'Reception computer', 'http://$x:8080/reception-portal'),
        ],
        if (a.length > 1) Text('Other addresses: ${a.skip(1).join(', ')}'),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
    ));
  }

  void _more() => showModalBottomSheet(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(leading: const Icon(Icons.wifi), title: const Text('Wi-Fi address'), onTap: () { Navigator.pop(ctx); _wifi(); }),
            ListTile(leading: const Icon(Icons.computer), title: const Text('Computer links'), onTap: () { Navigator.pop(ctx); _links(); }),
            ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Consultation fee'), onTap: () { Navigator.pop(ctx); _fee(); }),
            ListTile(leading: const Icon(Icons.backup_outlined), title: const Text('Backup (import / export)'), onTap: () { Navigator.pop(ctx); showBackupDialog(context); }),
            ListTile(leading: const Icon(Icons.lock_outline), title: const Text('Change my password'), onTap: () { Navigator.pop(ctx); _password(); }),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Wrap(spacing: 10, runSpacing: 10, children: [
        FilledButton.icon(icon: const Icon(Icons.vpn_key), label: const Text('New reception code'), onPressed: () async {
          try { _show('Reception code', await repo.receptionCode(), 'One-time use. Valid for 15 minutes.'); } catch (e) { _snack('$e'); }
        }),
        FilledButton.icon(icon: const Icon(Icons.person_add), label: const Text('New staff ID'), onPressed: _newStaff),
        OutlinedButton.icon(icon: const Icon(Icons.more_horiz), label: const Text('More options'), onPressed: _more),
      ]),
      const SizedBox(height: 18),
      Text('Staff', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
      StreamBuilder<Snap>(stream: repo.staff(u.organizationId), builder: (c, s) {
        if (!s.hasData) return const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator()));
        if (s.data!.docs.isEmpty) return const Padding(padding: EdgeInsets.all(16), child: Text('No staff yet.'));
        return Column(children: [for (final d in s.data!.docs) ListTile(
          title: Text('${d['displayName']} · ${d['role'] == 'lab_technician' ? 'Lab' : d['role'] == 'receptionist' ? 'Reception' : 'Pharmacy'}'),
          subtitle: Text('${d['staffId']}'),
          trailing: Wrap(children: [
            if (d['role'] != 'receptionist') IconButton(tooltip: 'Regenerate ID', icon: const Icon(Icons.refresh), onPressed: () async {
              try { _show('New staff ID', await repo.regenerate(d.id), 'The old ID no longer works.'); } catch (e) { _snack('$e'); }
            }),
            Switch(value: d['active'] == true, onChanged: (v) async { try { await repo.setStaffActive(d.id, v); } catch (e) { _snack('$e'); } }),
          ]),
        )]);
      }),
    ]);
  }
}
