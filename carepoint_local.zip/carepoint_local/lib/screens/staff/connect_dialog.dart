import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/qr_actions.dart';
import '../../host/server.dart';

/// Doctor phone: three QR codes for connecting other phones. 0 = Wi-Fi, 1 = app address, 2 = web pages.
Future<void> showConnectDialog(BuildContext context, {int initial = 0}) async {
  final prefs = await SharedPreferences.getInstance();
  final addrs = await LocalServer.i.addresses();
  if (!context.mounted) return;
  await showDialog(context: context, builder: (_) => _ConnectDialog(prefs: prefs, addrs: addrs, initial: initial));
}

class _ConnectDialog extends StatefulWidget {
  const _ConnectDialog({required this.prefs, required this.addrs, required this.initial});
  final SharedPreferences prefs;
  final List<String> addrs;
  final int initial;
  @override
  State<_ConnectDialog> createState() => _ConnectDialogState();
}

class _ConnectDialogState extends State<_ConnectDialog> {
  late int tab = widget.initial;
  late final TextEditingController _ssid = TextEditingController(text: widget.prefs.getString('cp_wifi_ssid') ?? '');
  late final TextEditingController _pass = TextEditingController(text: widget.prefs.getString('cp_wifi_pass') ?? '');
  bool _show = false;

  @override
  void dispose() { _ssid.dispose(); _pass.dispose(); super.dispose(); }

  void _save() {
    widget.prefs.setString('cp_wifi_ssid', _ssid.text);
    widget.prefs.setString('cp_wifi_pass', _pass.text);
    setState(() {});
  }

  Widget _qr(String data, double size) => Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
        child: QrImageView(data: data, size: size),
      );

  Widget _copyRow(String text) => Row(children: [
        Expanded(child: SelectableText(text, textAlign: TextAlign.center)),
        IconButton(icon: const Icon(Icons.copy), onPressed: () => Clipboard.setData(ClipboardData(text: text))),
      ]);

  Widget _wifi() => Column(mainAxisSize: MainAxisSize.min, children: [
        const Text("Step 1 · Staff phones scan this to join your hotspot or Wi-Fi. Type its name and password once.", textAlign: TextAlign.center),
        const SizedBox(height: 10),
        TextField(controller: _ssid, onChanged: (_) => _save(), decoration: const InputDecoration(labelText: 'Wi-Fi / hotspot name')),
        const SizedBox(height: 8),
        TextField(
          controller: _pass, obscureText: !_show, onChanged: (_) => _save(),
          decoration: InputDecoration(labelText: 'Wi-Fi password (empty if open)', suffixIcon: IconButton(icon: Icon(_show ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _show = !_show))),
        ),
        const SizedBox(height: 14),
        if (_ssid.text.trim().isEmpty)
          const Text('Enter the Wi-Fi name to see the QR.', style: TextStyle(color: Colors.black54))
        else ...[
          _qr(wifiQrData(_ssid.text.trim(), _pass.text), 200),
          const SizedBox(height: 8),
          const Text("Scan with the phone's camera, or with Scan QR on the staff sign-in page. Android cannot read the hotspot password by itself, so it is typed here and kept only on this phone.", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
        ],
      ]);

  Widget _app() => Column(mainAxisSize: MainAxisSize.min, children: [
        if (widget.addrs.isEmpty) const Text('No network found. Turn on Wi-Fi or the hotspot.') else ...[
          const Text('Step 2 · After joining the Wi-Fi, staff scan this in the CarePoint app (Staff phone → Scan QR).', textAlign: TextAlign.center),
          const SizedBox(height: 12),
          _qr('carepoint://${widget.addrs.first}:8080', 200),
          const SizedBox(height: 8),
          for (final a in widget.addrs) _copyRow(a),
        ],
      ]);

  Widget _link(String label, String url) => Padding(
        padding: const EdgeInsets.only(bottom: 16),
        child: Column(children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          const SizedBox(height: 8),
          _qr(url, 150),
          _copyRow(url),
        ]),
      );

  Widget _web() => Column(mainAxisSize: MainAxisSize.min, children: [
        if (widget.addrs.isEmpty) const Text('No network found. Turn on Wi-Fi or the hotspot.') else ...[
          const Text('Scan with any phone camera to open the page. It looks and works like the app. Same Wi-Fi needed.', textAlign: TextAlign.center),
          const SizedBox(height: 14),
          _link('Lab page', 'http://${widget.addrs.first}:8080/lab-portal'),
          _link('Reception page', 'http://${widget.addrs.first}:8080/reception-portal'),
          _link('All pages', 'http://${widget.addrs.first}:8080/'),
        ],
      ]);

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Connect phones'),
        content: SizedBox(
          width: 360,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              SegmentedButton<int>(
                showSelectedIcon: false,
                segments: const [ButtonSegment(value: 0, label: Text('Wi-Fi')), ButtonSegment(value: 1, label: Text('App')), ButtonSegment(value: 2, label: Text('Web'))],
                selected: {tab},
                onSelectionChanged: (s) => setState(() => tab = s.first),
              ),
              const SizedBox(height: 16),
              if (tab == 0) _wifi() else if (tab == 1) _app() else _web(),
            ]),
          ),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      );
}
