import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../host/backup.dart';
import '../../host/server.dart';
import '../../providers/auth_provider.dart';

/// Pop-up with Export and Import buttons (plus backups kept on this phone).
Future<void> showBackupDialog(BuildContext context) => showDialog(context: context, builder: (_) => const _BackupDialog());

class _BackupDialog extends StatefulWidget {
  const _BackupDialog();
  @override
  State<_BackupDialog> createState() => _BackupDialogState();
}

class _BackupDialogState extends State<_BackupDialog> {
  late final Future<List<File>> _files = BackupService.list();

  void _snack(String m) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m))); }

  Future<void> _export() async {
    try {
      final f = await BackupService.exportFile(LocalServer.i.st);
      await Share.shareXFiles([XFile(f.path)], subject: 'CarePoint backup');
    } catch (e) { _snack('Export failed: $e'); }
  }

  Future<void> _import() async {
    final bytes = await BackupService.pick();
    if (bytes != null) await _restore(bytes);
  }

  Future<void> _restore(List<int> bytes) async {
    final auth = context.read<AuthProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    try {
      final snap = BackupService.parse(bytes);
      if (!mounted) return;
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Restore this backup?'),
          content: Text('All data on this phone will be replaced by:\n\n${BackupService.summary(snap)}\n\nYou will be signed out.'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Replace data'))],
        ),
      );
      if (ok != true) return;
      nav.pop();
      if (!await auth.restoreBackup(bytes)) messenger.showSnackBar(SnackBar(content: Text(auth.error ?? 'Restore failed')));
    } catch (e) { messenger.showSnackBar(SnackBar(content: Text('$e'.replaceFirst('Exception: ', '')))); }
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: const Text('Backup'),
        content: SizedBox(
          width: 360,
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: FilledButton.icon(icon: const Icon(Icons.file_upload), label: const Text('Export'), onPressed: _export)),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(icon: const Icon(Icons.file_download), label: const Text('Import'), onPressed: _import)),
            ]),
            FutureBuilder<List<File>>(
              future: _files,
              builder: (c, s) {
                final fs = (s.data ?? []).reversed.take(4).toList();
                if (fs.isEmpty) return const SizedBox.shrink();
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const SizedBox(height: 14),
                  Text('Saved on this phone', style: Theme.of(c).textTheme.titleSmall),
                  for (final f in fs)
                    ListTile(
                      dense: true, contentPadding: EdgeInsets.zero,
                      title: Text(DateFormat('d MMM y, HH:mm').format(f.lastModifiedSync())),
                      trailing: TextButton(onPressed: () async => _restore(await f.readAsBytes()), child: const Text('Restore')),
                    ),
                ]);
              },
            ),
          ]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
      );
}
