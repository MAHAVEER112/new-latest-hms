import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../core/glass.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/clinical_repository.dart';

void _snack(BuildContext c, String m) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m))); }

Future<void> openReport(BuildContext c, String resultId) async {
  try {
    final path = await c.read<ClinicalRepository>().downloadReport(resultId);
    final r = await OpenFilex.open(path);
    if (r.type != ResultType.done) _snack(c, 'Could not open the PDF. Install a PDF viewer app.');
  } catch (e) { _snack(c, '$e'); }
}

/// Lab queue: sample -> processing -> attach PDF report -> report goes straight to the doctor.
class LabTechScreen extends StatelessWidget {
  const LabTechScreen({super.key});

  static const _label = {'ordered': 'Waiting for sample', 'collected': 'Sample collected', 'processing': 'Processing', 'submitted': 'Report sent to doctor'};

  Future<void> _addReport(BuildContext c, Rec d) async {
    final repo = c.read<ClinicalRepository>();
    final notes = TextEditingController();
    XFile? file;
    final ok = await showDialog<bool>(
      context: c,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text('Report: ${d['testName']}'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${d['patientName']}'),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              icon: const Icon(Icons.picture_as_pdf),
              label: Text(file == null ? 'Choose PDF from this phone' : file!.name, overflow: TextOverflow.ellipsis),
              onPressed: () async {
                final f = await openFile(acceptedTypeGroups: [const XTypeGroup(label: 'PDF', extensions: ['pdf'], mimeTypes: ['application/pdf'])]);
                if (f != null) set(() => file = f);
              },
            ),
            const SizedBox(height: 10),
            TextField(controller: notes, maxLines: 2, decoration: const InputDecoration(labelText: 'Short note (optional)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: file == null ? null : () => Navigator.pop(ctx, true), child: const Text('Send to doctor')),
          ],
        ),
      ),
    );
    if (ok != true || file == null) return;
    try {
      await repo.uploadReport(d.id, file!.name, await file!.readAsBytes(), notes.text.trim());
      _snack(c, 'Report sent to the doctor');
    } catch (e) { _snack(c, '$e'); }
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    return StreamBuilder<Snap>(
      stream: repo.labByStatus(u.organizationId, const ['ordered', 'collected', 'processing', 'submitted']),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final all = s.data!.docs;
        final pending = all.where((d) => d['status'] != 'submitted').toList();
        final sent = all.where((d) => d['status'] == 'submitted').toList();
        if (all.isEmpty) return const Center(child: Text('Lab queue is empty.'));
        Widget tile(Rec d) {
          final st = '${d['status']}';
          final urgent = d['priority'] == 'urgent';
          return GlassCard(
            blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
            child: Row(children: [
              CircleAvatar(backgroundColor: urgent ? Colors.red.shade400 : const Color(0xFF6D4CFF), foregroundColor: Colors.white, child: Text('${d['queueToken'] ?? '-'}')),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('${d['testName']}${urgent ? '  ·  URGENT' : ''}'),
                Text(_label[st] ?? st, style: const TextStyle(color: Colors.black54)),
              ])),
              if (st == 'ordered') FilledButton(onPressed: () => repo.techUpdate(d.id, 'collected', u.uid), child: const Text('Collected')),
              if (st == 'collected') FilledButton(onPressed: () => repo.techUpdate(d.id, 'processing', u.uid), child: const Text('Start')),
              if (st == 'processing') FilledButton(onPressed: () => _addReport(c, d), child: const Text('Add report')),
              if (st == 'submitted') const Icon(Icons.check_circle, color: Color(0xFF34C38F)),
            ]),
          );
        }
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text('Lab queue · ${pending.length} waiting', style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          for (final d in pending) tile(d),
          if (sent.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text('Reports sent', style: Theme.of(c).textTheme.titleSmall),
            const SizedBox(height: 8),
            for (final d in sent) tile(d),
          ],
        ]);
      },
    );
  }
}

/// Doctor checks the lab PDFs directly (no separate verifier).
class ReviewsScreen extends StatelessWidget {
  const ReviewsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    return StreamBuilder<Snap>(
      stream: repo.pendingReviews(u.organizationId),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('No lab reports waiting for review.'));
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final d in s.data!.docs)
            GlassCard(
              blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
              child: Row(children: [
                const Icon(Icons.picture_as_pdf, color: Color(0xFF6D4CFF)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const Text('Lab reports ready'),
                ])),
                FilledButton(onPressed: () => _review(c, d.id, '${d['orderId']}', u.uid), child: const Text('Review')),
              ]),
            ),
        ]);
      },
    );
  }

  Future<void> _review(BuildContext c, String id, String orderId, String uid) async {
    final repo = c.read<ClinicalRepository>();
    final res = await repo.resultsForOrder(orderId);
    final interp = TextEditingController(), comm = TextEditingController();
    DateTime? follow;
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Review lab reports'),
          content: SingleChildScrollView(child: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final r in res.docs)
              ListTile(
                dense: true, contentPadding: EdgeInsets.zero,
                title: Text('${r['testName']}'),
                subtitle: Text('${r['result'] ?? ''}'),
                trailing: r['hasReport'] == 1 ? TextButton.icon(icon: const Icon(Icons.picture_as_pdf), label: const Text('Open PDF'), onPressed: () => openReport(c, r.id)) : null,
              ),
            const SizedBox(height: 8),
            TextField(controller: interp, maxLines: 3, decoration: const InputDecoration(labelText: 'Clinical interpretation')),
            const SizedBox(height: 8),
            TextField(controller: comm, maxLines: 2, decoration: const InputDecoration(labelText: 'Comments / recommended treatment')),
            TextButton.icon(
              icon: const Icon(Icons.event),
              label: Text(follow == null ? 'Schedule follow-up (optional)' : follow!.toString().substring(0, 10)),
              onPressed: () async {
                final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)), initialDate: DateTime.now().add(const Duration(days: 7)));
                if (d != null) set(() => follow = d);
              },
            ),
          ]))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () async {
              if (interp.text.trim().isEmpty) return;
              try {
                await repo.completeReview(id, interp.text.trim(), comm.text.trim(), follow, uid);
                if (ctx.mounted) Navigator.pop(ctx);
              } catch (e) { _snack(ctx, '$e'); }
            }, child: const Text('Mark review completed')),
          ],
        ),
      ),
    );
  }
}
