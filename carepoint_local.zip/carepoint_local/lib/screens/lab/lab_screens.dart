import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../core/glass.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/clinical_repository.dart';

const _kStatuses = ['ordered', 'collected', 'processing', 'submitted'];
const _labels = {'ordered': 'Waiting for sample', 'collected': 'Sample collected', 'processing': 'Processing', 'submitted': 'Completed'};

void _snack(BuildContext c, String m) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m))); }

Future<void> openReport(BuildContext c, String resultId) async {
  try {
    final path = await c.read<ClinicalRepository>().downloadReport(resultId);
    final r = await OpenFilex.open(path);
    if (r.type != ResultType.done) _snack(c, 'Could not open the PDF. Install a PDF viewer app.');
  } catch (e) { _snack(c, '$e'); }
}

Widget _patientCard(BuildContext c, List<Rec> rows) {
  final first = rows.first;
  final total = rows.length;
  final done = rows.where((d) => d['status'] == 'submitted').length;
  final urgent = rows.any((d) => d['priority'] == 'urgent');
  return GestureDetector(
    onTap: () => Navigator.of(c).push(MaterialPageRoute(builder: (_) => LabPatientScreen(patientDocId: '${first['patientDocId']}', name: '${first['patientName']}'))),
    child: GlassCard(
      blur: false, margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14),
      child: Row(children: [
        CircleAvatar(radius: 26, backgroundColor: urgent ? Colors.red.shade400 : const Color(0xFF0F62C9), foregroundColor: Colors.white,
            child: Text('${first['queueToken'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${first['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          Text('$total ${total == 1 ? 'test' : 'tests'} · $done done${urgent ? ' · URGENT' : ''}'),
        ])),
        done == total ? const Icon(Icons.check_circle, color: Color(0xFF22C55E)) : const Icon(Icons.chevron_right),
      ]),
    ),
  );
}

/// Lab queue: one card per patient. Tap a patient to open that patient's tests.
class LabTechScreen extends StatelessWidget {
  const LabTechScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    return StreamBuilder<Snap>(
      stream: repo.labByStatus(u.organizationId, _kStatuses),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final order = <String>[];
        final groups = <String, List<Rec>>{};
        for (final d in s.data!.docs) {
          final k = '${d['patientDocId']}';
          if (!groups.containsKey(k)) { order.add(k); groups[k] = []; }
          groups[k]!.add(d);
        }
        bool open(String k) => groups[k]!.any((d) => d['status'] != 'submitted');
        final todo = order.where(open).toList();
        final done = order.where((k) => !open(k)).toList();
        final t = Theme.of(c).textTheme;
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text('Lab queue', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          Text('${todo.length} ${todo.length == 1 ? 'patient' : 'patients'} waiting. Tap a patient to open their tests.'),
          const SizedBox(height: 14),
          if (order.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(30), child: Text('No tests ordered yet.'))),
          for (final k in todo) _patientCard(c, groups[k]!),
          if (done.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text('Completed today', style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            for (final k in done) _patientCard(c, groups[k]!),
          ],
        ]);
      },
    );
  }
}

Widget _testTile(BuildContext c, Rec d) {
  final st = '${d['status']}';
  final fin = st == 'submitted';
  final urgent = d['priority'] == 'urgent';
  return GestureDetector(
    onTap: () => Navigator.of(c).push(MaterialPageRoute(builder: (_) => LabTestScreen(testId: d.id))),
    child: GlassCard(
      blur: false, margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(14),
      child: Row(children: [
        IconBubble(icon: Icons.science_rounded, color: fin ? const Color(0xFF22C55E) : const Color(0xFF0EA5E9), size: 46),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${d['testName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          Text('${_labels[st] ?? st}${urgent ? ' · URGENT' : ''}', style: TextStyle(color: urgent ? Colors.red : Colors.black54)),
        ])),
        fin ? const Icon(Icons.check_circle, color: Color(0xFF22C55E)) : const Icon(Icons.chevron_right),
      ]),
    ),
  );
}

/// Patient profile: every test the doctor ordered. Tap a test to open it on its own page.
class LabPatientScreen extends StatefulWidget {
  const LabPatientScreen({super.key, required this.patientDocId, required this.name});
  final String patientDocId, name;
  @override
  State<LabPatientScreen> createState() => _LabPatientScreenState();
}

class _LabPatientScreenState extends State<LabPatientScreen> {
  Stream<Snap>? _s;

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    _s ??= repo.labByStatus(u.organizationId, _kStatuses);
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: StreamBuilder<Snap>(
        stream: _s,
        builder: (c, s) {
          if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final rows = s.data!.docs.where((d) => d['patientDocId'] == widget.patientDocId).toList();
          if (rows.isEmpty) return const Center(child: Text('No tests for this patient.'));
          final done = rows.where((d) => d['status'] == 'submitted').length;
          final urgent = rows.any((d) => d['priority'] == 'urgent');
          final t = Theme.of(c).textTheme;
          return ListView(padding: const EdgeInsets.all(16), children: [
            GlassCard(
              padding: const EdgeInsets.all(16), margin: const EdgeInsets.only(bottom: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  CircleAvatar(radius: 24, backgroundColor: urgent ? Colors.red.shade400 : const Color(0xFF0F62C9), foregroundColor: Colors.white,
                      child: Text('${rows.first['queueToken'] ?? '-'}', style: const TextStyle(fontWeight: FontWeight.w800))),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(widget.name, style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                    Text('Patient profile · tests from the doctor${urgent ? ' · URGENT' : ''}', style: TextStyle(color: urgent ? Colors.red : Colors.black54)),
                  ])),
                ]),
                const SizedBox(height: 12),
                Text('$done of ${rows.length} tests completed'),
                const SizedBox(height: 8),
                ClipRRect(borderRadius: BorderRadius.circular(8), child: LinearProgressIndicator(value: done / rows.length, minHeight: 10, backgroundColor: Colors.white70, color: const Color(0xFF0F62C9))),
              ]),
            ),
            Padding(padding: const EdgeInsets.fromLTRB(4, 4, 4, 10), child: Text('Tests · tap one to open', style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800))),
            for (final d in rows) _testTile(c, d),
          ]);
        },
      ),
    );
  }
}

/// One test on its own page: steps, optional PDF report, note and the Complete button.
class LabTestScreen extends StatefulWidget {
  const LabTestScreen({super.key, required this.testId});
  final String testId;
  @override
  State<LabTestScreen> createState() => _LabTestScreenState();
}

class _LabTestScreenState extends State<LabTestScreen> {
  Stream<Snap>? _s;
  final _notes = TextEditingController();
  XFile? _file;
  bool _busy = false;
  String? _forced; // shows a step right away, until the doctor's phone confirms it

  @override
  void dispose() { _notes.dispose(); super.dispose(); }

  Future<void> _step(Rec d, String status) async {
    final u = context.read<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    setState(() => _busy = true);
    try {
      await repo.techUpdate(d.id, status, u.uid);
      _forced = status;
    } catch (e) { _snack(context, '$e'); }
    if (mounted) setState(() => _busy = false);
  }

  Future<void> _pick() async {
    final f = await openFile(acceptedTypeGroups: [const XTypeGroup(label: 'PDF', extensions: ['pdf'], mimeTypes: ['application/pdf'])]);
    if (f != null && mounted) setState(() => _file = f);
  }

  Future<void> _complete(Rec d) async {
    final repo = context.read<ClinicalRepository>();
    setState(() => _busy = true);
    try {
      final f = _file;
      await repo.completeTest(d.id, fileName: f?.name, bytes: f == null ? null : await f.readAsBytes(), notes: _notes.text.trim());
      if (!mounted) return;
      _snack(context, 'Test completed');
      Navigator.of(context).pop();
    } catch (e) {
      _snack(context, '$e');
      if (mounted) setState(() => _busy = false);
    }
  }

  Widget _steps(String status) {
    const keys = ['ordered', 'collected', 'processing', 'submitted'];
    const names = ['Ordered', 'Sample', 'Processing', 'Done'];
    final idx = keys.indexOf(status);
    final done = status == 'submitted';
    return Row(children: [
      for (var i = 0; i < 4; i++)
        Expanded(child: Column(children: [
          CircleAvatar(
            radius: 15,
            backgroundColor: i <= idx ? const Color(0xFF0F62C9) : Colors.white70,
            foregroundColor: i <= idx ? Colors.white : Colors.black54,
            child: (i < idx || done) ? const Icon(Icons.check, size: 16) : Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
          ),
          const SizedBox(height: 4),
          Text(names[i], style: TextStyle(fontSize: 11, fontWeight: i <= idx ? FontWeight.w700 : FontWeight.w400)),
        ])),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    _s ??= repo.labByStatus(u.organizationId, _kStatuses);
    final big = FilledButton.styleFrom(minimumSize: const Size.fromHeight(52));
    return Scaffold(
      appBar: AppBar(title: const Text('Test')),
      body: StreamBuilder<Snap>(
        stream: _s,
        builder: (c, s) {
          if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final found = s.data!.docs.where((d) => d.id == widget.testId).toList();
          if (found.isEmpty) return const Center(child: Text('This test is no longer in the lab list.'));
          final d = found.first;
          if (_forced != null && '${d['status']}' == _forced) _forced = null;
          final status = _forced ?? '${d['status']}';
          final t = Theme.of(c).textTheme;
          final urgent = d['priority'] == 'urgent';
          final note = '${d['orderNotes'] ?? ''}';
          return ListView(padding: const EdgeInsets.all(16), children: [
            GlassCard(
              padding: const EdgeInsets.all(18), margin: const EdgeInsets.only(bottom: 14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text('${d['testName']}', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800))),
                  if (urgent) Chip(label: const Text('URGENT'), backgroundColor: Colors.red.shade50, side: BorderSide.none, labelStyle: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
                ]),
                Text('${d['patientName']}${d['queueToken'] == null ? '' : ' · Token ${d['queueToken']}'}', style: const TextStyle(color: Colors.black54)),
                if (note.isNotEmpty) Container(
                  width: double.infinity, margin: const EdgeInsets.only(top: 12), padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: Colors.white70, borderRadius: BorderRadius.circular(16)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Doctor note', style: TextStyle(fontSize: 12, color: Colors.black54)),
                    Text(note),
                  ]),
                ),
                const SizedBox(height: 18),
                _steps(status),
              ]),
            ),
            if (status == 'ordered') ...[
              const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Collect the sample, then tap the button.')),
              FilledButton(style: big, onPressed: _busy ? null : () => _step(d, 'collected'), child: const Text('Sample collected')),
            ],
            if (status == 'collected')
              FilledButton.tonal(style: big, onPressed: _busy ? null : () => _step(d, 'processing'), child: const Text('Start processing')),
            if (status == 'collected' || status == 'processing')
              GlassCard(
                blur: false, margin: const EdgeInsets.only(top: 14), padding: const EdgeInsets.all(18),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Text('Finish this test', style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: Text(_file == null ? 'Attach PDF report (optional)' : _file!.name, overflow: TextOverflow.ellipsis),
                    onPressed: _busy ? null : _pick,
                  ),
                  if (_file != null) TextButton(onPressed: _busy ? null : () => setState(() => _file = null), child: const Text('Remove PDF')),
                  const SizedBox(height: 8),
                  TextField(controller: _notes, maxLines: 2, decoration: const InputDecoration(labelText: 'Result note (optional)')),
                  const SizedBox(height: 16),
                  FilledButton.icon(style: big, icon: const Icon(Icons.check), onPressed: _busy ? null : () => _complete(d), label: Text(_busy ? 'Please wait...' : 'Complete')),
                ]),
              ),
            if (status == 'submitted')
              GlassCard(
                blur: false, padding: const EdgeInsets.all(22),
                child: Column(children: [
                  const Icon(Icons.check_circle, size: 52, color: Color(0xFF22C55E)),
                  const SizedBox(height: 8),
                  Text('Test completed', style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(d['hasReport'] == 1 ? 'PDF report attached' : 'Completed without a PDF', style: const TextStyle(color: Color(0xFF1B9E6E), fontWeight: FontWeight.w700)),
                  if ('${d['result'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Note: ${d['result']}')),
                  const Padding(padding: EdgeInsets.only(top: 6), child: Text('Sent to the doctor.')),
                ]),
              ),
          ]);
        },
      ),
    );
  }
}

/// Doctor checks the lab PDFs directly (no separate verifier).
class ReviewsScreen extends StatelessWidget {
  const ReviewsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicalRepository>();
    return StreamBuilder<Snap>(
      stream: repo.pendingReviews(u.organizationId),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('No lab reports waiting for review.'));
        return ListView(padding: const EdgeInsets.all(16), children: [
          for (final d in s.data!.docs)
            GlassCard(
              blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
              child: Row(children: [
                const Icon(Icons.picture_as_pdf, color: Color(0xFF0F62C9)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  const Text('Lab reports ready'),
                ])),
                FilledButton(onPressed: () => _review(c, d.id, '${d['orderId']}', u.uid), child: const Text('Review')),
              ]),
            ),
        ]);
      },
    );
  }

  Future<void> _review(BuildContext c, String id, String orderId, String uid) async {
    final repo = c.read<ClinicalRepository>();
    final res = await repo.resultsForOrder(orderId);
    final interp = TextEditingController(), comm = TextEditingController();
    DateTime? follow;
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Review lab reports'),
          content: SingleChildScrollView(child: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (final r in res.docs)
              ListTile(
                dense: true, contentPadding: EdgeInsets.zero,
                title: Text('${r['testName']}'),
                subtitle: Text('${r['result'] ?? ''}'.isEmpty ? (r['hasReport'] == 1 ? 'PDF attached' : 'No report attached') : '${r['result']}'),
                trailing: r['hasReport'] == 1 ? TextButton.icon(icon: const Icon(Icons.picture_as_pdf), label: const Text('Open PDF'), onPressed: () => openReport(c, r.id)) : null,
              ),
            const SizedBox(height: 8),
            TextField(controller: interp, maxLines: 3, decoration: const InputDecoration(labelText: 'Clinical interpretation')),
            const SizedBox(height: 8),
            TextField(controller: comm, maxLines: 2, decoration: const InputDecoration(labelText: 'Comments / recommended treatment')),
            TextButton.icon(
              icon: const Icon(Icons.event),
              label: Text(follow == null ? 'Schedule follow-up (optional)' : follow!.toString().substring(0, 10)),
              onPressed: () async {
                final d = await showDatePicker(context: ctx, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 730)), initialDate: DateTime.now().add(const Duration(days: 7)));
                if (d != null) set(() => follow = d);
              },
            ),
          ]))),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            FilledButton(onPressed: () async {
              if (interp.text.trim().isEmpty) return;
              try {
                await repo.completeReview(id, interp.text.trim(), comm.text.trim(), follow, uid);
                if (ctx.mounted) Navigator.pop(ctx);
              } catch (e) { _snack(ctx, '$e'); }
            }, child: const Text('Mark review completed')),
          ],
        ),
      ),
    );
  }
}
