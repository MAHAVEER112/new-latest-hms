import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../core/glass.dart';
import '../../repositories/ops_repository.dart';

String _plain(Object? v) => v is num ? (v % 1 == 0 ? '${v.toInt()}' : v.toStringAsFixed(2)) : '$v';
String _money(Object? v) => '₹${_plain(v)}';

/// Payments for doctor AND reception. Whoever accepts first closes the charge and is recorded.
class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});
  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  int _tab = 0;
  Stream<Snap>? _due, _paid;

  void _snack(String m) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m))); }

  Future<void> _accept(Rec d) async {
    final repo = context.read<OpsRepository>();
    final amt = TextEditingController(text: _plain(d['amount'])), note = TextEditingController();
    String method = 'cash';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Accept payment'),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${d['patientName']} · ${d['description']}', style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            TextField(controller: amt, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount received (₹)')),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [for (final m in ['cash', 'upi', 'card']) ChoiceChip(label: Text(m.toUpperCase()), selected: method == m, onSelected: (_) => set(() => method = m))]),
            const SizedBox(height: 10),
            TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optional)')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Collect'))],
        ),
      ),
    );
    if (ok != true) return;
    final v = num.tryParse(amt.text.trim());
    if (v == null || v <= 0) { _snack('Enter a valid amount'); return; }
    try { await repo.acceptPayment(d.id, v, method, note.text.trim()); _snack('Payment collected'); } catch (e) { _snack('$e'); }
  }

  Future<void> _newCharge() async {
    final repo = context.read<OpsRepository>();
    final pid = TextEditingController(), desc = TextEditingController(text: 'Lab / other charge'), amt = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('New charge'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: pid, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Patient ID (e.g. CP-000001)')),
          const SizedBox(height: 10),
          TextField(controller: desc, decoration: const InputDecoration(labelText: 'Description')),
          const SizedBox(height: 10),
          TextField(controller: amt, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Amount (₹)')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Add'))],
      ),
    );
    if (ok != true) return;
    final v = num.tryParse(amt.text.trim());
    if (v == null || v <= 0) { _snack('Enter a valid amount'); return; }
    try {
      final p = await repo.findPatient('', pid.text);
      if (p == null) { _snack('Patient not found'); return; }
      await repo.addCharge(p.id, desc.text.trim(), v);
      _snack('Charge added');
    } catch (e) { _snack('$e'); }
  }

  @override
  Widget build(BuildContext context) {
    final repo = context.read<OpsRepository>();
    _due ??= repo.payments('due');
    _paid ??= repo.payments('paid');
    final t = Theme.of(context).textTheme;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: _newCharge, icon: const Icon(Icons.add), label: const Text('New charge')),
      body: StreamBuilder<Snap>(
        stream: _tab == 0 ? _due : _paid,
        builder: (c, s) {
          final head = Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
            child: SegmentedButton<int>(
              segments: const [ButtonSegment(value: 0, label: Text('Due')), ButtonSegment(value: 1, label: Text('History'))],
              selected: {_tab}, onSelectionChanged: (v) => setState(() => _tab = v.first)),
          );
          if (s.hasError && !s.hasData) return Column(children: [head, Expanded(child: Center(child: Text('${s.error}')))]);
          if (!s.hasData) return Column(children: [head, const Expanded(child: Center(child: CircularProgressIndicator()))]);
          final rows = s.data!.docs;
          final today = DateTime.now();
          num total = 0;
          if (_tab == 1) {
            for (final d in rows) {
              final at = (d['paidAt'] as Timestamp?)?.toDate();
              if (at != null && at.year == today.year && at.month == today.month && at.day == today.day) total += d['amount'] as num;
            }
          }
          return Column(children: [
            head,
            if (_tab == 1) Padding(padding: const EdgeInsets.fromLTRB(20, 4, 20, 8), child: Align(alignment: Alignment.centerLeft, child: Text('Collected today: ${_money(total)}', style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800)))),
            Expanded(
              child: rows.isEmpty
                  ? Center(child: Text(_tab == 0 ? 'No payments due.' : 'No payments yet.'))
                  : ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 90), children: [
                      for (final d in rows)
                        GlassCard(
                          blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                          child: Row(children: [
                            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                              if (_tab == 0) Text('${d['patientId']} · ${d['description']}')
                              else Text('${d['description']} · ${'${d['method']}'.toUpperCase()}\nBy ${d['collectedByName']} (${d['collectedByRole'] == 'doctor' ? 'Doctor' : 'Reception'}) · ${DateFormat('d MMM, HH:mm').format((d['paidAt'] as Timestamp).toDate())}'),
                            ])),
                            Text(_money(d['amount']), style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800, color: _tab == 1 ? const Color(0xFF1B9E6E) : null)),
                            if (_tab == 0) Padding(padding: const EdgeInsets.only(left: 10), child: FilledButton(onPressed: () => _accept(d), child: const Text('Accept'))),
                          ]),
                        ),
                    ]),
            ),
          ]);
        },
      ),
    );
  }
}
