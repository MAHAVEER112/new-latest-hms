import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/api/api_client.dart';
import '../../core/glass.dart';
import '../../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  int? who; // null = choose, 0 = doctor, 1 = staff
  int staffMode = 1; // 1 reception code, 2 staff ID
  final _c = TextEditingController();

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  void _go(int? w) => setState(() { who = w; _c.clear(); context.read<AuthProvider>().error = null; });

  Widget _tile(IconData icon, Color color, String title, String sub, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        child: GlassCard(
          blur: false, margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16),
          child: Row(children: [
            IconBubble(icon: icon, color: color, size: 54),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
              Text(sub),
            ])),
            const Icon(Icons.chevron_right),
          ]),
        ),
      );

  Future<void> _becomeDoctorPhone(AuthProvider auth) async {
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text("Use this as the doctor's phone?"),
      content: const Text("This phone will stop connecting to the current doctor's phone. You can then create a new doctor account or restore a backup file here."),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Continue'))],
    ));
    if (ok == true) await auth.changeDoctorPhone();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final host = auth.isHost;
    final t = Theme.of(context).textTheme;
    final err = auth.error == null ? const SizedBox.shrink() : Padding(padding: const EdgeInsets.only(top: 10), child: Text(auth.error!, style: const TextStyle(color: Colors.red)));

    Widget body;
    if (who == null) {
      body = Column(children: [
        Text('Who is signing in?', style: t.titleMedium),
        const SizedBox(height: 14),
        _tile(Icons.medical_services_rounded, const Color(0xFF6D4CFF), 'Doctor', 'Full access with your password', () => _go(0)),
        _tile(Icons.groups_rounded, const Color(0xFF2BB7A6), 'Staff', 'Reception, Lab or Pharmacy', () => _go(1)),
      ]);
    } else if (who == 0) {
      body = Column(children: [
        Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => _go(null), icon: const Icon(Icons.arrow_back), label: const Text('Back'))),
        Text('Doctor sign-in', style: t.titleMedium),
        const SizedBox(height: 12),
        if (host) ...[
          TextField(controller: _c, obscureText: true, decoration: const InputDecoration(labelText: 'Doctor password')),
          err,
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton(onPressed: auth.busy ? null : () => auth.signIn('doctor', _c.text.trim()), child: Text(auth.busy ? 'Please wait...' : 'Sign in'))),
        ] else ...[
          const Text("Doctor sign-in works only on the doctor's own phone, where the hospital data is stored."),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton.tonal(onPressed: () => _becomeDoctorPhone(auth), child: const Text("Use this phone as the doctor's phone"))),
        ],
      ]);
    } else {
      body = Column(children: [
        Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => _go(null), icon: const Icon(Icons.arrow_back), label: const Text('Back'))),
        SegmentedButton<int>(
          segments: const [ButtonSegment(value: 1, label: Text('Reception')), ButtonSegment(value: 2, label: Text('Lab / Pharmacy'))],
          selected: {staffMode}, onSelectionChanged: (s) => setState(() { staffMode = s.first; _c.clear(); })),
        const SizedBox(height: 14),
        TextField(controller: _c, textCapitalization: TextCapitalization.characters, decoration: InputDecoration(labelText: staffMode == 1 ? 'Reception code (from doctor)' : 'Staff ID (from doctor)')),
        err,
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: auth.busy ? null : () => auth.signIn(staffMode == 1 ? 'reception' : _c.text.trim(), staffMode == 1 ? _c.text.trim() : ''),
          child: Text(auth.busy ? 'Please wait...' : 'Sign in'))),
      ]);
    }

    return Scaffold(
      appBar: host ? null : AppBar(actions: [
        PopupMenuButton<int>(
          onSelected: (_) => auth.changeDoctorPhone(),
          itemBuilder: (_) => const [PopupMenuItem(value: 1, child: Text('Change doctor phone'))],
        ),
      ]),
      body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: GlassCard(
        child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const IconBubble(icon: Icons.local_hospital_rounded, color: Color(0xFF6D4CFF), size: 60),
          const SizedBox(height: 10),
          Text('CarePoint HMS', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 18),
          body,
        ])),
      )))),
    );
  }
}
