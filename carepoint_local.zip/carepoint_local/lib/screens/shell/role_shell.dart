import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/api/api_client.dart';
import '../../core/constants/roles.dart';
import '../../core/nav_bar.dart';
import '../../core/notifications_dialog.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';
import '../admin/admin_screens.dart';
import '../appointments/appointments_screen.dart';
import '../dashboard/dashboard_screen.dart';
import '../lab/lab_screens.dart';
import '../patients/patients_screen.dart';
import '../payments/payments_screen.dart';
import '../pharmacy/pharmacy_screens.dart';
import '../queue/queue_screen.dart';
import '../staff/staff_codes_screen.dart';

/// App frame: content + floating bottom bar (first 5 sections, then "More" for the rest, notifications and sign out).
class RoleShell extends StatelessWidget {
  const RoleShell({super.key, required this.section});
  final String section;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final items = user.role.navItems;
    final primary = items.take(5).toList();
    final extra = items.skip(5).toList();
    final idx = items.indexWhere((n) => n.path == section);
    final current = idx < 0 ? 0 : idx;
    final selected = current < primary.length ? current : primary.length;

    final body = Column(children: [
      ValueListenableBuilder<bool>(
        valueListenable: Api.i.offline,
        builder: (_, off, __) => off
            ? Container(
                width: double.infinity, color: Colors.amber.shade100, padding: const EdgeInsets.all(6),
                child: const Text("Doctor's phone not reachable. Showing the last saved copy on this phone.", textAlign: TextAlign.center))
            : const SizedBox.shrink(),
      ),
      Expanded(child: _body(context)),
    ]);

    return Scaffold(
      appBar: section == 'dashboard' ? null : AppBar(title: Text(items[current].label)),
      body: SafeArea(bottom: false, child: body),
      bottomNavigationBar: GlassNavBar(
        items: [for (final n in primary) NavEntry(n.icon, n.label), const NavEntry(Icons.apps_rounded, 'More')],
        selected: selected,
        onTap: (i) {
          if (i < primary.length) {
            context.go('/app/${primary[i].path}');
          } else {
            _more(context, extra, auth);
          }
        },
      ),
    );
  }

  void _more(BuildContext context, List<NavItem> extra, AuthProvider auth) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => SafeArea(
        child: Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xF5FFFFFF), borderRadius: BorderRadius.circular(26)),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(auth.user!.displayName ?? auth.user!.email, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(auth.user!.role.label),
            ),
            const Divider(height: 1),
            for (final n in extra)
              ListTile(leading: Icon(n.icon), title: Text(n.label), onTap: () { Navigator.pop(ctx); context.go('/app/${n.path}'); }),
            ListTile(leading: const Icon(Icons.notifications_outlined), title: const Text('Notifications'), onTap: () { Navigator.pop(ctx); showNotificationsDialog(context); }),
            ListTile(leading: const Icon(Icons.logout), title: const Text('Sign out'), onTap: () { Navigator.pop(ctx); auth.signOut(); }),
          ]),
        ),
      ),
    );
  }

  Widget _body(BuildContext context) {
    switch (section) {
      case 'dashboard':
        return const TodayDashboard();
      case 'patients':
        return const PatientsScreen();
      case 'queue':
        return const QueueScreen();
      case 'appointments':
        return const AppointmentsScreen();
      case 'payments':
        return const PaymentsScreen();
      case 'samples':
      case 'results':
        return const LabTechScreen();
      case 'reviews':
        return const ReviewsScreen();
      case 'prescriptions':
        return const PrescriptionsScreen();
      case 'inventory':
        return const InventoryScreen();
      case 'invoices':
        return const InvoicesScreen();
      case 'staff':
        return const StaffCodesScreen();
      case 'reports':
        return const ReportsScreen();
      case 'audit':
        return const AuditScreen();
    }
    return const Center(child: Text('Section not available'));
  }
}
