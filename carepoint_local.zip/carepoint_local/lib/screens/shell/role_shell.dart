import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';
import '../patients/patients_screen.dart';
import '../queue/queue_screen.dart';
import '../lab/lab_screens.dart';
import '../admin/admin_screens.dart';
import '../dashboard/dashboard_screen.dart';
import '../staff/staff_codes_screen.dart';
import '../../core/api/api_client.dart';
import '../appointments/appointments_screen.dart';
import '../pharmacy/pharmacy_screens.dart';
import '../payments/payments_screen.dart';

/// Responsive shell: drawer (desktop), rail (tablet), bottom bar (mobile).
/// Module screens replace [_body] in the following modules.
class RoleShell extends StatelessWidget {
  const RoleShell({super.key, required this.section});
  final String section;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.user;
    if (user == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final items = user.role.navItems;
    final index = items.indexWhere((n) => n.path == section).clamp(0, items.length - 1);
    void go(int i) => context.go('/app/${items[i].path}');
    final w = MediaQuery.sizeOf(context).width;

    final appBar = AppBar(
      title: Text(items[index].label),
      actions: [
        if (w >= 600)
          Center(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 8), child: Text('${user.displayName ?? user.email} · ${user.role.label}'))),
        IconButton(tooltip: 'Notifications', icon: const Icon(Icons.notifications_outlined), onPressed: () => _notes(context)),
        IconButton(tooltip: 'Sign out', icon: const Icon(Icons.logout), onPressed: auth.signOut),
      ],
    );
    final inner = _body(context, items[index].label);
    final body = Column(children: [
      ValueListenableBuilder<bool>(
        valueListenable: Api.i.offline,
        builder: (_, off, __) => off
            ? Container(width: double.infinity, color: Colors.amber.shade100, padding: const EdgeInsets.all(6),
                child: const Text("Doctor's phone not reachable. Showing the last saved copy on this phone.", textAlign: TextAlign.center))
            : const SizedBox.shrink(),
      ),
      Expanded(child: inner),
    ]);

    if (w >= 1000 && items.length >= 2) {
      return Scaffold(
        appBar: appBar,
        body: Row(children: [
          SizedBox(
            width: 260,
            child: NavigationDrawer(
              selectedIndex: index,
              onDestinationSelected: go,
              children: [
                const Padding(padding: EdgeInsets.fromLTRB(28, 16, 16, 12), child: Text('CarePoint HMS', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
                for (final n in items) NavigationDrawerDestination(icon: Icon(n.icon), label: Text(n.label)),
              ],
            ),
          ),
          Expanded(child: body),
        ]),
      );
    }
    if (w >= 600 && items.length >= 2) {
      return Scaffold(
        appBar: appBar,
        body: Row(children: [
          NavigationRail(
            selectedIndex: index,
            onDestinationSelected: go,
            labelType: NavigationRailLabelType.all,
            destinations: [for (final n in items) NavigationRailDestination(icon: Icon(n.icon), label: Text(n.label))],
          ),
          Expanded(child: body),
        ]),
      );
    }
    return Scaffold(
      appBar: appBar,
      body: body,
      bottomNavigationBar: items.length >= 2
          ? NavigationBar(
              selectedIndex: index,
              onDestinationSelected: go,
              destinations: [for (final n in items) NavigationDestination(icon: Icon(n.icon), label: n.label)],
            )
          : null,
    );
  }

  Future<void> _notes(BuildContext c) async {
    try {
      final items = await c.read<OpsRepository>().notifications();
      if (!c.mounted) return;
      await showDialog(
        context: c,
        builder: (ctx) => AlertDialog(
          title: const Text('Notifications'),
          content: SizedBox(width: 360, child: items.isEmpty ? const Text('No notifications.') : ListView(shrinkWrap: true, children: [
            for (final n in items) ListTile(dense: true, title: Text('${n['title']}'), subtitle: Text('${n['body']}')),
          ])),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
        ),
      );
    } catch (e) {
      if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Widget _body(BuildContext context, String label) {
    switch (section) {
      case 'patients':
        return const PatientsScreen();
      case 'queue':
        return const QueueScreen();
      case 'samples':
      case 'results':
        return const LabTechScreen();
      case 'reviews':
        return const ReviewsScreen();
      case 'payments':
        return const PaymentsScreen();
      case 'dashboard':
        return const TodayDashboard();
      case 'appointments':
        return const AppointmentsScreen();
      case 'prescriptions':
        return const PrescriptionsScreen();
      case 'inventory':
        return const InventoryScreen();
      case 'invoices':
        return const InvoicesScreen();
      case 'staff':
        return const StaffCodesScreen();
      case 'reports':
        return const ReportsScreen();
      case 'audit':
        return const AuditScreen();
    }
    return Center(child: Text('$label module arrives in its build step.', style: Theme.of(context).textTheme.titleMedium));
  }
}
