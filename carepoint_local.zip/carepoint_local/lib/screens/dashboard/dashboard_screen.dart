import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../core/notifications_dialog.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';
import '../patients/register_patient_dialog.dart';
import '../payments/payments_screen.dart';

const String _hospital = 'City Care Hospital';
const Color _ink = Color(0xFF0B2A55);
const Color _blue = Color(0xFF0F62C9);

const Map<String, (IconData, Color)> _meta = {
  'waiting': (Icons.hourglass_empty_rounded, Color(0xFF16A34A)),
  'in_lab': (Icons.biotech_rounded, Color(0xFF2B8BE6)),
  'completed': (Icons.check_circle_outline_rounded, Color(0xFF16A34A)),
  'appointments': (Icons.event_available_outlined, Color(0xFFE5484D)),
  'reviews': (Icons.description_outlined, Color(0xFF5B5BD6)),
  'lab': (Icons.science_outlined, Color(0xFFF59E0B)),
  'current': (Icons.person_rounded, Color(0xFF0F62C9)),
  'in_consultation': (Icons.medical_services_rounded, Color(0xFF0F62C9)),
  'payments': (Icons.receipt_long_rounded, Color(0xFFF59E0B)),
  'collected': (Icons.account_balance_wallet_rounded, Color(0xFF16A34A)),
};

class _SoftIcon extends StatelessWidget {
  const _SoftIcon(this.icon, this.color, {this.size = 50});
  final IconData icon;
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color.withAlpha(34), border: Border.all(color: Colors.white.withAlpha(220), width: 1.2)),
        child: Icon(icon, color: color, size: size * .52),
      );
}

/// Blue hospital cross used as the logo.
class _Logo extends StatelessWidget {
  const _Logo();
  @override
  Widget build(BuildContext context) => const SizedBox(width: 46, height: 46, child: CustomPaint(painter: _LogoPainter()));
}

class _LogoPainter extends CustomPainter {
  const _LogoPainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 48);
    final fill = Paint()..shader = const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF3B9BF0), Color(0xFF0B4A9E)]).createShader(const Rect.fromLTWH(0, 0, 48, 48));
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(16, 4, 16, 40), const Radius.circular(3)), fill);
    canvas.drawRRect(RRect.fromRectAndRadius(const Rect.fromLTWH(4, 16, 40, 16), const Radius.circular(3)), fill);
    final white = Paint()..color = const Color(0xEBFFFFFF);
    canvas.drawRect(const Rect.fromLTWH(21, 12, 6, 24), white);
    canvas.drawRect(const Rect.fromLTWH(12, 21, 24, 6), white);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Hospital building illustration shown at the top right.
class _HospitalArt extends StatelessWidget {
  const _HospitalArt();
  @override
  Widget build(BuildContext context) {
    final w = (MediaQuery.of(context).size.width * .44).clamp(140.0, 200.0).toDouble();
    return SizedBox(width: w, height: w * .65, child: const CustomPaint(painter: _ArtPainter()));
  }
}

class _ArtPainter extends CustomPainter {
  const _ArtPainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 200);
    Paint p(Color c) => Paint()..color = c;
    RRect rr(double x, double y, double w, double h, double r) => RRect.fromRectAndRadius(Rect.fromLTWH(x, y, w, h), Radius.circular(r));
    canvas.drawOval(Rect.fromCenter(center: const Offset(110, 122), width: 208, height: 18), p(const Color(0xFF9BD48A)));
    canvas.drawRRect(rr(46, 64, 146, 50, 3), p(const Color(0xFFE9EEF6)));
    canvas.drawRect(const Rect.fromLTWH(46, 60, 146, 6), p(const Color(0xFFC9D4E4)));
    canvas.drawRRect(rr(118, 22, 52, 92, 3), p(const Color(0xFF2F7FD6)));
    final glass = p(const Color(0xB38FC2F4));
    for (final y in [56.0, 72.0, 88.0]) {
      for (final x in [122.0, 136.0, 150.0]) { canvas.drawRect(Rect.fromLTWH(x, y, 10, 10), glass); }
    }
    final cross = Path()
      ..moveTo(139, 30)..lineTo(149, 30)..lineTo(149, 38)..lineTo(157, 38)..lineTo(157, 48)..lineTo(149, 48)
      ..lineTo(149, 56)..lineTo(139, 56)..lineTo(139, 48)..lineTo(131, 48)..lineTo(131, 38)..lineTo(139, 38)..close();
    canvas.drawPath(cross, p(Colors.white));
    final win = p(const Color(0xFF3F8BE0));
    for (final y in [72.0, 88.0]) {
      for (final x in [54.0, 72.0, 90.0]) { canvas.drawRect(Rect.fromLTWH(x, y, 12, 9), win); }
    }
    canvas.drawRect(const Rect.fromLTWH(172, 76, 18, 38), p(const Color(0xFFC9DCF3)));
    canvas.drawRect(const Rect.fromLTWH(26, 96, 5, 18), p(const Color(0xFF8B6B4A)));
    canvas.drawCircle(const Offset(28, 86), 15, p(const Color(0xFF3F9B4F)));
    canvas.drawCircle(const Offset(17, 95), 10, p(const Color(0xFF4AA85A)));
    canvas.drawCircle(const Offset(40, 95), 10, p(const Color(0xFF4AA85A)));
    canvas.drawCircle(const Offset(62, 116), 6, p(const Color(0xFF4AA85A)));
    canvas.drawCircle(const Offset(80, 117), 5, p(const Color(0xFF5BB86A)));
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// Bell with an orange dot when there are notifications; tap to read them.
class _Bell extends StatefulWidget {
  const _Bell();
  @override
  State<_Bell> createState() => _BellState();
}

class _BellState extends State<_Bell> {
  bool _has = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final n = await context.read<OpsRepository>().notifications();
      if (mounted) setState(() => _has = n.isNotEmpty);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: () async { await showNotificationsDialog(context); _load(); },
        child: Container(
          width: 54, height: 54,
          decoration: BoxDecoration(
            color: Colors.white.withAlpha(220), borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white, width: 1.4),
            boxShadow: const [BoxShadow(color: Color(0x334A78B8), blurRadius: 14, offset: Offset(0, 6))],
          ),
          child: Stack(alignment: Alignment.center, children: [
            const Icon(Icons.notifications_none_rounded, size: 28, color: _ink),
            if (_has) Positioned(top: 13, right: 14, child: Container(width: 10, height: 10, decoration: BoxDecoration(color: const Color(0xFFF59E0B), shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
          ]),
        ),
      );
}

const List<Color> _white = [Colors.white, Color(0xFFF4F9FF)];

/// Today-only dashboard. Every card opens the list of patients behind that number.
class TodayDashboard extends StatelessWidget {
  const TodayDashboard({super.key});

  void _open(BuildContext c, String key, String title) =>
      Navigator.of(c).push(MaterialPageRoute(builder: (_) => StatDetailScreen(statKey: key, title: title)));

  /// Opens Payments on the History tab, as its own page with a back arrow.
  void _openPayments(BuildContext c) => Navigator.of(c).push(MaterialPageRoute(
      builder: (_) => Scaffold(appBar: AppBar(title: const Text('Payments')), body: const PaymentsScreen(initialTab: 1))));

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final hr = DateTime.now().hour;
    final greet = hr < 12 ? 'Good Morning' : hr < 17 ? 'Good Afternoon' : 'Good Evening';
    final t = Theme.of(context).textTheme;
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: context.read<OpsRepository>().stats(),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final by = <String, Map<String, dynamic>>{for (final e in s.data!) '${e['key']}': e};
        final cur = by['current'] ?? <String, dynamic>{};
        final name = '${cur['value'] ?? ''}';
        final keys = ['waiting', 'in_lab', 'completed', 'appointments', 'reviews', 'lab'].where((k) => by.containsKey(k)).toList();
        return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 20), children: [
          Row(children: [
            const _Logo(),
            const SizedBox(width: 10),
            Expanded(child: Text(_hospital, style: t.titleMedium?.copyWith(fontWeight: FontWeight.w800, color: _ink, height: 1.1))),
            const _Bell(),
          ]),
          const SizedBox(height: 14),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                FittedBox(
                  fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
                  child: Text('$greet,\n${u.displayName ?? ''} 👋', style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w800, color: _ink, height: 1.12)),
                ),
                const SizedBox(height: 8),
                Text(DateFormat('EEEE, d MMMM').format(DateTime.now()), style: t.bodyLarge?.copyWith(color: Colors.black54)),
              ]),
            ),
            Transform.translate(offset: const Offset(16, 0), child: const _HospitalArt()),
          ]),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () => _open(context, 'current', 'Current patient'),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [Color(0xFF2B84E0), Color(0xFF0B4A99)]),
                boxShadow: const [BoxShadow(color: Color(0x550F62C9), blurRadius: 24, offset: Offset(0, 12))],
              ),
              child: Row(children: [
                Container(
                  width: 62, height: 62,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withAlpha(30), border: Border.all(color: Colors.white.withAlpha(200), width: 1.6)),
                  child: const Icon(Icons.person_outline_rounded, color: Colors.white, size: 34),
                ),
                Container(width: 1, height: 54, margin: const EdgeInsets.symmetric(horizontal: 12), color: Colors.white.withAlpha(90)),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Current Patient', style: t.bodyMedium?.copyWith(color: Colors.white70)),
                    Text(name.isEmpty ? 'No patient right now' : name, maxLines: 2, overflow: TextOverflow.ellipsis, style: t.titleMedium?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
                    if (name.isNotEmpty) Text('${cur['sub']}', style: t.bodySmall?.copyWith(color: Colors.white70)),
                  ]),
                ),
                const SizedBox(width: 8),
                ElevatedButton(
                  onPressed: () => showRegisterPatientDialog(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white, foregroundColor: _blue, elevation: 4, shape: const StadiumBorder(),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14), textStyle: const TextStyle(fontWeight: FontWeight.w800)),
                  child: const Text('Add Patient +'),
                ),
              ]),
            ),
          ),
          const SizedBox(height: 22),
          Row(children: [
            Expanded(child: Text('Today’s Overview', style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800, color: _ink))),
            GlassCard(
              radius: 22, blur: false, gradient: _white, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.calendar_today_rounded, size: 16, color: _blue),
                const SizedBox(width: 8),
                Text('Today, ${DateFormat('d MMM').format(DateTime.now())}', style: const TextStyle(fontWeight: FontWeight.w600, color: _ink)),
              ]),
            ),
          ]),
          const SizedBox(height: 14),
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2,
            mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: 1.85,
            children: [
              for (final k in keys)
                GestureDetector(
                  onTap: () => _open(context, k, '${by[k]!['label']}'),
                  child: GlassCard(
                    blur: false, gradient: _white, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    child: Row(children: [
                      _SoftIcon(_meta[k]!.$1, _meta[k]!.$2, size: 46),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${by[k]!['value']}', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: _ink, height: 1.05)),
                          Text('${by[k]!['label']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: t.bodySmall?.copyWith(color: _ink, height: 1.15)),
                        ]),
                      ),
                      const Icon(Icons.chevron_right_rounded, size: 24, color: Colors.black45),
                    ]),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          GestureDetector(
            onTap: () => _openPayments(context),
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(28),
                gradient: const LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [Color(0xFF1F7DDB), Color(0xFF0B4A9E)]),
                boxShadow: const [BoxShadow(color: Color(0x550F62C9), blurRadius: 24, offset: Offset(0, 12))],
              ),
              child: Row(children: [
                Container(
                  width: 56, height: 56,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withAlpha(30), border: Border.all(color: Colors.white.withAlpha(200), width: 1.5)),
                  child: const Icon(Icons.credit_card_rounded, color: Colors.white, size: 28),
                ),
                Container(width: 1, height: 52, margin: const EdgeInsets.symmetric(horizontal: 14), color: Colors.white.withAlpha(90)),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Payment History', style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800, color: Colors.white)),
                    Text('View past payments and transactions', style: t.bodyMedium?.copyWith(color: Colors.white70)),
                  ]),
                ),
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withAlpha(50)),
                  child: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
                ),
              ]),
            ),
          ),
        ]);
      },
    );
  }
}

class StatDetailScreen extends StatelessWidget {
  const StatDetailScreen({super.key, required this.statKey, required this.title});
  final String statKey, title;

  @override
  Widget build(BuildContext context) {
    final color = (_meta[statKey] ?? _meta['waiting']!).$2;
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: context.read<OpsRepository>().detail(statKey),
        builder: (c, s) {
          if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final rows = s.data!;
          if (rows.isEmpty) return const Center(child: GlassCard(padding: EdgeInsets.all(24), child: Text('Nobody here right now.')));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Padding(padding: const EdgeInsets.only(bottom: 10), child: Text('${rows.length} ${rows.length == 1 ? 'entry' : 'entries'} today', style: Theme.of(c).textTheme.titleMedium)),
            for (final r in rows)
              GlassCard(
                blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                child: Row(children: [
                  Container(
                    width: 50, height: 50, alignment: Alignment.center,
                    decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color.lerp(color, Colors.white, .3)!, color]), boxShadow: [BoxShadow(color: color.withAlpha(110), blurRadius: 10, offset: const Offset(0, 5))]),
                    child: '${r['badge']}'.isEmpty ? const Icon(Icons.person, color: Colors.white) : Text('${r['badge']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${r['title']}', style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    Text('${r['sub']}'),
                  ])),
                  if ('${r['tag']}'.isNotEmpty) Chip(label: Text('${r['tag']}'), backgroundColor: color.withAlpha(35), side: BorderSide.none),
                ]),
              ),
          ]);
        },
      ),
    );
  }
}
