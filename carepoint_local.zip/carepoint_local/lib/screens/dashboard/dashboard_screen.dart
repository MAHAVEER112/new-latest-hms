import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';

const Map<String, (IconData, Color)> _meta = {
  'waiting': (Icons.hourglass_top_rounded, Color(0xFF2BB7A6)),
  'in_consultation': (Icons.medical_services_rounded, Color(0xFF6D4CFF)),
  'completed': (Icons.check_circle_rounded, Color(0xFF34C38F)),
  'appointments': (Icons.event_available_rounded, Color(0xFFF472B6)),
  'reviews': (Icons.biotech_rounded, Color(0xFFA06BFF)),
  'lab': (Icons.science_rounded, Color(0xFFF59E0B)),
  'in_lab': (Icons.biotech_outlined, Color(0xFF38BDF8)),
  'payments': (Icons.receipt_long_rounded, Color(0xFFF59E0B)),
  'collected': (Icons.account_balance_wallet_rounded, Color(0xFF34C38F)),
  'current': (Icons.personal_injury_rounded, Color(0xFF6D4CFF)),
};

String _val(Map e) {
  final v = e['value'];
  final n = v is num ? (v % 1 == 0 ? '${v.toInt()}' : v.toStringAsFixed(2)) : '$v';
  return e['key'] == 'collected' ? '₹$n' : n;
}

/// Today-only dashboard. Every card opens the list of patients behind that number.
class TodayDashboard extends StatelessWidget {
  const TodayDashboard({super.key});

  void _open(BuildContext c, String key, String title) =>
      Navigator.of(c).push(MaterialPageRoute(builder: (_) => StatDetailScreen(statKey: key, title: title)));

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final hr = DateTime.now().hour;
    final greet = hr < 12 ? 'Good morning' : hr < 17 ? 'Good afternoon' : 'Good evening';
    final t = Theme.of(context).textTheme;
    return StreamBuilder<List<Map<String, dynamic>>>(
      stream: context.read<OpsRepository>().stats(),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final cur = s.data!.firstWhere((e) => e['key'] == 'current', orElse: () => {});
        final cards = s.data!.where((e) => e['key'] != 'current').toList();
        final name = '${cur['value'] ?? ''}';
        return ListView(padding: const EdgeInsets.all(16), children: [
          Text('$greet, ${u.displayName ?? ''}', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: const Color(0xFF1E1B3A))),
          Text("${DateFormat('EEEE, d MMMM').format(DateTime.now())} · Today's overview", style: t.bodyMedium),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: () => _open(context, 'current', 'Current patient'),
            child: GlassCard(
              gradient: const [Color(0xDDFFC8DC), Color(0xDDCFC3FF), Color(0xDDB5DCFF)],
              padding: const EdgeInsets.all(18),
              child: Row(children: [
                IconBubble(icon: _meta['current']!.$1, color: _meta['current']!.$2, size: 58),
                const SizedBox(width: 16),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('CURRENT PATIENT', style: t.labelMedium?.copyWith(letterSpacing: 1.2, color: Colors.black54)),
                  Text(name.isEmpty ? 'No patient right now' : name, style: t.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                  if (name.isNotEmpty) Text('${cur['sub']}', style: t.bodyMedium),
                ])),
              ]),
            ),
          ),
          const SizedBox(height: 14),
          GridView.count(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2,
            mainAxisSpacing: 14, crossAxisSpacing: 14, childAspectRatio: 1.1,
            children: [
              for (final e in cards)
                GestureDetector(
                  onTap: () => _open(context, '${e['key']}', '${e['label']}'),
                  child: GlassCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      IconBubble(icon: (_meta[e['key']] ?? _meta['waiting']!).$1, color: (_meta[e['key']] ?? _meta['waiting']!).$2),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_val(e), style: t.headlineMedium?.copyWith(fontWeight: FontWeight.w800, color: const Color(0xFF1E1B3A))),
                        Text('${e['label']}', style: t.bodyMedium),
                      ]),
                    ]),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          const Center(child: Text('Tap a card to see names and queue numbers', style: TextStyle(color: Colors.black45))),
        ]);
      },
    );
  }
}

class StatDetailScreen extends StatelessWidget {
  const StatDetailScreen({super.key, required this.statKey, required this.title});
  final String statKey, title;

  @override
  Widget build(BuildContext context) {
    final color = (_meta[statKey] ?? _meta['waiting']!).$2;
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: StreamBuilder<List<Map<String, dynamic>>>(
        stream: context.read<OpsRepository>().detail(statKey),
        builder: (c, s) {
          if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final rows = s.data!;
          if (rows.isEmpty) return const Center(child: GlassCard(padding: EdgeInsets.all(24), child: Text('Nobody here right now.')));
          return ListView(padding: const EdgeInsets.all(16), children: [
            Padding(padding: const EdgeInsets.only(bottom: 10), child: Text('${rows.length} ${rows.length == 1 ? 'entry' : 'entries'} today', style: Theme.of(c).textTheme.titleMedium)),
            for (final r in rows)
              GlassCard(
                blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                child: Row(children: [
                  Container(
                    width: 50, height: 50, alignment: Alignment.center,
                    decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color.lerp(color, Colors.white, .3)!, color]), boxShadow: [BoxShadow(color: color.withAlpha(110), blurRadius: 10, offset: const Offset(0, 5))]),
                    child: '${r['badge']}'.isEmpty ? const Icon(Icons.person, color: Colors.white) : Text('${r['badge']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${r['title']}', style: Theme.of(c).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    Text('${r['sub']}'),
                  ])),
                  if ('${r['tag']}'.isNotEmpty) Chip(label: Text('${r['tag']}'), backgroundColor: color.withAlpha(35), side: BorderSide.none),
                ]),
              ),
          ]);
        },
      ),
    );
  }
}
