import 'package:flutter/material.dart';
import '../../core/glass.dart';
import 'package:provider/provider.dart';
import '../../host/backup.dart';
import '../../providers/auth_provider.dart';
import 'qr_scan_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({super.key});
  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  bool host = true;
  final _key = GlobalKey<FormState>();
  final _name = TextEditingController(), _pw = TextEditingController(), _pw2 = TextEditingController(), _ip = TextEditingController();

  @override
  void dispose() { for (final c in [_name, _pw, _pw2, _ip]) { c.dispose(); } super.dispose(); }

  Future<void> _scan(AuthProvider auth) async {
    final v = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const QrScanScreen()));
    if (v == null || !mounted) return;
    final m = RegExp(r'(\d{1,3}(?:\.\d{1,3}){3})').firstMatch(v);
    if (m == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('That QR is not a CarePoint address')));
      return;
    }
    _ip.text = m.group(1)!;
    await auth.setupClient(_ip.text);
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: GlassCard(child: Padding(
        padding: const EdgeInsets.all(24),
        child: Form(key: _key, child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.local_hospital, size: 44, color: Theme.of(context).colorScheme.primary),
          Text('Set up CarePoint', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 16),
          SegmentedButton<bool>(
            segments: const [ButtonSegment(value: true, label: Text("Doctor's phone")), ButtonSegment(value: false, label: Text('Staff phone'))],
            selected: {host}, onSelectionChanged: (s) => setState(() => host = s.first)),
          const SizedBox(height: 16),
          if (host) ...[
            const Text('This phone stores all hospital data. Keep it on and the app open.'),
            const SizedBox(height: 10),
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'Doctor name'), validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null),
            const SizedBox(height: 10),
            TextFormField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password (8+ characters)'), validator: (v) => (v ?? '').length < 8 ? 'Minimum 8 characters' : null),
            const SizedBox(height: 10),
            TextFormField(controller: _pw2, obscureText: true, decoration: const InputDecoration(labelText: 'Confirm password'), validator: (v) => v != _pw.text ? 'Does not match' : null),
          ] else ...[
            const Text("Join the doctor's Wi-Fi or hotspot, then enter the address shown on the doctor's Staff & Codes screen."),
            const SizedBox(height: 10),
            TextFormField(controller: _ip, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Doctor phone address (e.g. 192.168.43.1)'), validator: (v) => (v ?? '').trim().isEmpty ? 'Required' : null),
            const SizedBox(height: 8),
            OutlinedButton.icon(icon: const Icon(Icons.qr_code_scanner), label: const Text('Scan QR (optional)'), onPressed: auth.busy ? null : () => _scan(auth)),
          ],
          if (auth.error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(auth.error!, style: const TextStyle(color: Colors.red))),
          const SizedBox(height: 16),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: auth.busy ? null : () async {
              if (!_key.currentState!.validate()) return;
              host ? await auth.setupHost(_name.text, _pw.text) : await auth.setupClient(_ip.text);
            },
            child: Text(auth.busy ? 'Please wait...' : host ? 'Create & start' : 'Connect'))),
          if (host) TextButton.icon(
            icon: const Icon(Icons.restore),
            label: const Text('Restore from backup file'),
            onPressed: auth.busy ? null : () async {
              final b = await BackupService.pick();
              if (b != null) await auth.restoreBackup(b);
            },
          ),
        ])),
      ))))),
    );
  }
}
