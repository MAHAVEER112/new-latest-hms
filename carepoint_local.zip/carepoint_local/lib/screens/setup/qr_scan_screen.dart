import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

/// Optional camera scanner: reads the QR shown on the doctor's phone and returns its text.
class QrScanScreen extends StatefulWidget {
  const QrScanScreen({super.key, this.title = 'Scan the doctor phone QR', this.hint = "Point the camera at the QR on the doctor's phone"});
  final String title, hint;
  @override
  State<QrScanScreen> createState() => _QrScanScreenState();
}

class _QrScanScreenState extends State<QrScanScreen> {
  final MobileScannerController _ctl = MobileScannerController(formats: const [BarcodeFormat.qrCode]);
  bool _done = false;

  @override
  void dispose() {
    _ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Stack(children: [
          MobileScanner(
            controller: _ctl,
            onDetect: (capture) {
              if (_done) return;
              for (final b in capture.barcodes) {
                final v = b.rawValue;
                if (v != null && v.isNotEmpty) {
                  _done = true;
                  Navigator.of(context).pop(v);
                  return;
                }
              }
            },
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(28),
              child: Text(widget.hint, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, shadows: [Shadow(blurRadius: 8)])),
            ),
          ),
        ]),
      );
}
