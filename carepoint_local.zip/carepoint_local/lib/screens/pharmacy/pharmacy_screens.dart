import '../../core/compat.dart';
import 'package:flutter/material.dart';
import '../../core/glass.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';

void _snack(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

class PrescriptionsScreen extends StatefulWidget {
  const PrescriptionsScreen({super.key});
  @override
  State<PrescriptionsScreen> createState() => _PrescriptionsScreenState();
}

class _PrescriptionsScreenState extends State<PrescriptionsScreen> {
  String _q = '';

  Future<void> _dispense(Dc rx) async {
    final u = context.read<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    final done = <String, int>{};
    for (final d in (await repo.dispensedFor(rx.id)).docs) { done[d['medicine']] = (done[d['medicine']] ?? 0) + (d['qty'] as int); }
    final items = [for (final e in rx['items'] as List) Map<String, dynamic>.from(e)];
    final ctrls = [for (final it in items) TextEditingController(text: '${((int.tryParse('${it['quantity']}') ?? 1) - (done[it['name']] ?? 0)).clamp(0, 9999)}')];
    if (!mounted) return;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Dispense (partial allowed)'),
      content: SingleChildScrollView(child: SizedBox(width: 380, child: Column(mainAxisSize: MainAxisSize.min, children: [
        for (final (i, it) in items.indexed) Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(
          controller: ctrls[i], keyboardType: TextInputType.number,
          decoration: InputDecoration(border: const OutlineInputBorder(), labelText: '${it['name']} ${it['dosage']} · ${it['frequency']} · ${it['food']}',
              helperText: 'Prescribed ${it['quantity']}, already dispensed ${done[it['name']] ?? 0}'))),
      ]))),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Dispense & invoice'))],
    ));
    if (ok != true || !mounted) return;
    try {
      await repo.dispense(org: u.organizationId, uid: u.uid, rxId: rx.id, patientName: rx['patientName'],
          lines: [for (final (i, it) in items.indexed) if ((int.tryParse(ctrls[i].text) ?? 0) > 0) (it['name'] as String, int.parse(ctrls[i].text))]);
      if (mounted) _snack(context, 'Dispensed. Invoice created.');
    } catch (e) { if (mounted) _snack(context, '$e'); }
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    return Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'Search by patient name', border: OutlineInputBorder()),
          onChanged: (v) => setState(() => _q = v.toLowerCase()))),
      Expanded(child: StreamBuilder<Snap>(
        stream: context.read<OpsRepository>().prescriptions(u.organizationId),
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('Error: ${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs.where((d) => '${d['patientName']}'.toLowerCase().contains(_q)).toList();
          if (docs.isEmpty) return const Center(child: Text('No prescriptions.'));
          return ListView(children: [for (final d in docs) GlassCard(blur: false, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4), child: ListTile(
            title: Text('${d['patientName']}'),
            subtitle: Text([for (final it in d['items'] as List) '${it['name']} ${it['dosage']} x${it['quantity']}'].join('\n')),
            isThreeLine: true,
            trailing: u.role.value == 'pharmacy' ? FilledButton(onPressed: () => _dispense(d), child: const Text('Dispense')) : null,
          ))]);
        },
      )),
    ]);
  }
}

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  Future<void> _add(BuildContext c) async {
    final u = c.read<AuthProvider>().user!;
    final repo = c.read<OpsRepository>();
    final name = TextEditingController(), batch = TextEditingController(), stock = TextEditingController(), price = TextEditingController();
    DateTime? exp;
    final ok = await showDialog<bool>(context: c, builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
      title: const Text('Add stock'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Medicine name')),
        TextField(controller: batch, decoration: const InputDecoration(labelText: 'Batch number')),
        TextField(controller: stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantity')),
        TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Unit price')),
        TextButton.icon(icon: const Icon(Icons.event), label: Text(exp == null ? 'Expiry date' : DateFormat.yMMMd().format(exp!)),
            onPressed: () async { final d = await showDatePicker(context: ctx, initialDate: DateTime.now().add(const Duration(days: 365)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 3650))); if (d != null) set(() => exp = d); }),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')), FilledButton(onPressed: () {
        if (name.text.trim().isNotEmpty && batch.text.trim().isNotEmpty && exp != null && (int.tryParse(stock.text) ?? 0) > 0 && double.tryParse(price.text) != null) Navigator.pop(ctx, true);
      }, child: const Text('Save'))],
    )));
    if (ok != true) return;
    try {
      await repo.addStock(org: u.organizationId, uid: u.uid, name: name.text, batch: batch.text, expiry: exp!, stock: int.parse(stock.text), price: double.parse(price.text));
    } catch (e) { if (c.mounted) _snack(c, '$e'); }
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _add(context), icon: const Icon(Icons.add), label: const Text('Add stock')),
      body: StreamBuilder<Snap>(
        stream: context.read<OpsRepository>().inventory(u.organizationId),
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('Error: ${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final docs = s.data!.docs.toList()..sort((a, b) => '${a['nameLower']}'.compareTo('${b['nameLower']}'));
          if (docs.isEmpty) return const Center(child: Text('No inventory yet.'));
          final now = DateTime.now();
          return ListView(children: [for (final d in docs) Builder(builder: (_) {
            final e = (d['expiry'] as Timestamp).toDate();
            final expired = e.isBefore(now), soon = e.isBefore(now.add(const Duration(days: 60)));
            final low = (d['stock'] as int) < 10;
            return ListTile(
              title: Text('${d['name']}  ·  Batch ${d['batch']}'),
              subtitle: Text('Stock ${d['stock']} · Price ${d['price']} · Exp ${DateFormat.yMMMd().format(e)}'),
              trailing: expired ? const Chip(label: Text('Expired')) : soon ? const Chip(label: Text('Expiring')) : low ? const Chip(label: Text('Low')) : null,
            );
          })]);
        },
      ),
    );
  }
}

class InvoicesScreen extends StatelessWidget {
  const InvoicesScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    return StreamBuilder<Snap>(
      stream: repo.invoices(u.organizationId),
      builder: (c, s) {
        if (s.hasError) return Center(child: Text('Error: ${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('No invoices.'));
        return ListView(children: [for (final d in s.data!.docs) GlassCard(blur: false, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4), child: ListTile(
          title: Text('${d['patientName']} · Total ${(d['total'] as num).toStringAsFixed(2)}'),
          subtitle: Text([for (final l in d['lines'] as List) '${l['name']} x${l['qty']} @ ${l['price']}'].join('\n')),
          isThreeLine: true,
          trailing: d['status'] == 'paid' ? const Chip(label: Text('Paid')) : u.role.value == 'pharmacy' ? FilledButton(onPressed: () => repo.markPaid(d.id), child: const Text('Mark paid')) : const Chip(label: Text('Unpaid')),
        ))]);
      },
    );
  }
}
