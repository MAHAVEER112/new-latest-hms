import 'package:flutter/material.dart';
import '../../core/glass.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/clinical_repository.dart';
import '../patients/patient_history_screen.dart';

const kLabTests = ['CBC', 'Blood Glucose (Fasting)', 'Blood Glucose (PP)', 'HbA1c', 'Lipid Profile', 'Liver Function', 'Kidney Function', 'Thyroid Panel', 'Urinalysis', 'CRP', 'ESR', 'Vitamin D', 'Vitamin B12', 'Dengue', 'Malaria', 'Typhoid (Widal)', 'Pregnancy Test', 'X-Ray', 'ECG', 'Ultrasound', 'CT Scan', 'MRI'];

class _Med {
  final c = {for (final k in ['name', 'dosage', 'frequency', 'duration', 'quantity', 'instructions']) k: TextEditingController()};
  String food = 'After food';
  bool m = false, a = false, e = false;
}

class ConsultationPage extends StatefulWidget {
  const ConsultationPage({super.key, required this.queueId, required this.patientDocId, required this.patientName});
  final String queueId, patientDocId, patientName;
  @override
  State<ConsultationPage> createState() => _ConsultationPageState();
}

class _ConsultationPageState extends State<ConsultationPage> {
  final _key = GlobalKey<FormState>();
  final _v = {for (final k in ['bp', 'pulse', 'temp', 'height', 'weight', 'spo2']) k: TextEditingController()};
  final _cl = {for (final k in ['chiefComplaint', 'symptoms', 'diagnosis', 'observations', 'notes', 'treatmentPlan']) k: TextEditingController()};
  final _labNotes = TextEditingController();
  final _minutes = TextEditingController(text: '30');
  final _custom = <String>[];
  final _meds = <_Med>[];
  final _tests = <String>{};
  String _priority = 'routine';
  bool _busy = false;

  Widget _f(TextEditingController c, String label, {bool req = false, TextInputType? kt, int lines = 1}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextFormField(controller: c, keyboardType: kt, maxLines: lines, decoration: InputDecoration(labelText: label),
            validator: req ? (v) => (v ?? '').trim().isEmpty ? 'Required' : null : (kt == TextInputType.number ? (v) => (v ?? '').isNotEmpty && double.tryParse(v!) == null ? 'Number' : null : null)),
      );

  Future<void> _addCustom() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add other test'),
        content: TextField(controller: c, autofocus: true, decoration: const InputDecoration(labelText: 'Test name')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Add'))],
      ),
    );
    if (name == null || name.isEmpty) return;
    setState(() { if (!kLabTests.contains(name) && !_custom.contains(name)) _custom.add(name); _tests.add(name); });
  }

  Future<void> _save() async {
    if (!_key.currentState!.validate()) return;
    final meds = <Map<String, String>>[];
    for (final m in _meds) {
      if (m.c['name']!.text.trim().isEmpty) continue;
      meds.add({...{for (final e in m.c.entries) e.key: e.value.text.trim()}, 'food': m.food,
        'timing': [if (m.m) 'Morning', if (m.a) 'Afternoon', if (m.e) 'Evening'].join(', ')});
    }
    final u = context.read<AuthProvider>().user!;
    setState(() => _busy = true);
    try {
      await context.read<ClinicalRepository>().saveConsultation(
        org: u.organizationId, uid: u.uid, queueId: widget.queueId, patientDocId: widget.patientDocId, patientName: widget.patientName,
        vitals: {for (final e in _v.entries) e.key: e.value.text.trim()}, clinical: {for (final e in _cl.entries) e.key: e.value.text.trim()},
        meds: meds, tests: _tests.toList(), priority: _priority, labNotes: _labNotes.text.trim(), labMinutes: int.tryParse(_minutes.text.trim()) ?? 30);
      if (!mounted) return;
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Consultation saved')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final h = Theme.of(context).textTheme.titleMedium;
    return Scaffold(
      appBar: AppBar(title: Text('Consultation: ${widget.patientName}'), actions: [
        IconButton(tooltip: 'Patient history', icon: const Icon(Icons.history), onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PatientHistoryScreen(patientDocId: widget.patientDocId, name: widget.patientName)))),
      ]),
      body: Form(
        key: _key,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Text('Vitals', style: h),
          const SizedBox(height: 8),
          Wrap(spacing: 10, children: [
            for (final e in {'bp': 'BP (e.g. 120/80)', 'pulse': 'Pulse', 'temp': 'Temp', 'height': 'Height cm', 'weight': 'Weight kg', 'spo2': 'SpO2 %'}.entries)
              SizedBox(width: 150, child: _f(_v[e.key]!, e.value, kt: e.key == 'bp' ? null : TextInputType.number)),
          ]),
          Text('Clinical', style: h),
          const SizedBox(height: 8),
          _f(_cl['chiefComplaint']!, 'Chief complaint', req: true),
          _f(_cl['symptoms']!, 'Symptoms', lines: 2),
          _f(_cl['diagnosis']!, 'Diagnosis', req: true),
          _f(_cl['observations']!, 'Clinical observations', lines: 2),
          _f(_cl['notes']!, 'Medical notes', lines: 2),
          _f(_cl['treatmentPlan']!, 'Treatment plan', lines: 2),
          Row(children: [Text('Prescription', style: h), const Spacer(), TextButton.icon(onPressed: () => setState(() => _meds.add(_Med())), icon: const Icon(Icons.add), label: const Text('Add medicine'))]),
          for (final (i, m) in _meds.indexed)
            GlassCard(blur: false, child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
              Row(children: [Expanded(child: _f(m.c['name']!, 'Medicine name')), IconButton(icon: const Icon(Icons.delete), onPressed: () => setState(() => _meds.removeAt(i)))]),
              Wrap(spacing: 10, children: [
                SizedBox(width: 140, child: _f(m.c['dosage']!, 'Dosage')),
                SizedBox(width: 140, child: _f(m.c['frequency']!, 'Frequency')),
                SizedBox(width: 120, child: _f(m.c['duration']!, 'Duration')),
                SizedBox(width: 100, child: _f(m.c['quantity']!, 'Quantity')),
              ]),
              Wrap(spacing: 8, children: [
                FilterChip(label: const Text('Morning'), selected: m.m, onSelected: (v) => setState(() => m.m = v)),
                FilterChip(label: const Text('Afternoon'), selected: m.a, onSelected: (v) => setState(() => m.a = v)),
                FilterChip(label: const Text('Evening'), selected: m.e, onSelected: (v) => setState(() => m.e = v)),
                ChoiceChip(label: const Text('Before food'), selected: m.food == 'Before food', onSelected: (_) => setState(() => m.food = 'Before food')),
                ChoiceChip(label: const Text('After food'), selected: m.food == 'After food', onSelected: (_) => setState(() => m.food = 'After food')),
              ]),
              const SizedBox(height: 10),
              _f(m.c['instructions']!, 'Instructions'),
            ]))),
          const SizedBox(height: 8),
          Text('Laboratory orders', style: h),
          Wrap(spacing: 8, runSpacing: 4, children: [
            for (final t in [...kLabTests, ..._custom]) FilterChip(label: Text(t), selected: _tests.contains(t), onSelected: (v) => setState(() => v ? _tests.add(t) : _tests.remove(t))),
            ActionChip(avatar: const Icon(Icons.add, size: 18), label: const Text('Other test'), onPressed: _addCustom),
          ]),
          if (_tests.isNotEmpty) ...[
            const SizedBox(height: 10),
            SegmentedButton<String>(segments: const [ButtonSegment(value: 'routine', label: Text('Routine')), ButtonSegment(value: 'urgent', label: Text('Urgent'))],
                selected: {_priority}, onSelectionChanged: (s) => setState(() => _priority = s.first)),
            const SizedBox(height: 10),
            _f(_labNotes, 'Test instructions / clinical notes', lines: 2),
            _f(_minutes, 'Expected time in lab (minutes). General queue continues meanwhile', kt: TextInputType.number),
          ],
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'Saving...' : 'Save & complete consultation')),
        ]),
      ),
    );
  }
}
