import '../../core/compat.dart';
import 'package:flutter/material.dart';
import '../../core/glass.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';

class AppointmentsScreen extends StatefulWidget {
  const AppointmentsScreen({super.key});
  @override
  State<AppointmentsScreen> createState() => _AppointmentsScreenState();
}

class _AppointmentsScreenState extends State<AppointmentsScreen> {
  String _f = 'upcoming';
  final _fmt = DateFormat('EEE d MMM, HH:mm');

  Future<DateTime?> _pick(DateTime? init) async {
    final d = await showDatePicker(context: context, initialDate: init ?? DateTime.now(), firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime.now().add(const Duration(days: 730)));
    if (d == null || !mounted) return null;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(init ?? DateTime.now().add(const Duration(hours: 1))));
    return t == null ? null : DateTime(d.year, d.month, d.day, t.hour, t.minute);
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _create() async {
    final u = context.read<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    final pid = TextEditingController(), reason = TextEditingController();
    DateTime? when;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, set) => AlertDialog(
        title: const Text('New appointment'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: pid, decoration: const InputDecoration(labelText: 'Patient ID (e.g. CP-000001)')),
          const SizedBox(height: 10),
          TextField(controller: reason, decoration: const InputDecoration(labelText: 'Reason / follow-up reason')),
          TextButton.icon(icon: const Icon(Icons.event), label: Text(when == null ? 'Pick date & time' : _fmt.format(when!)),
              onPressed: () async { final w = await _pick(when); if (w != null) set(() => when = w); }),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () { if (when != null && pid.text.trim().isNotEmpty) Navigator.pop(ctx, true); }, child: const Text('Create')),
        ],
      )),
    );
    if (ok != true) return;
    try {
      final p = await repo.findPatient(u.organizationId, pid.text);
      if (p == null) return _snack('Patient not found');
      await repo.createAppointment(org: u.organizationId, uid: u.uid, patient: p, when: when!, reason: reason.text.trim());
      _snack('Appointment created');
    } catch (e) { _snack('Failed: $e'); }
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    final can = u.role.value == 'receptionist' || u.role.value == 'doctor';
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: can ? FloatingActionButton.extended(onPressed: _create, icon: const Icon(Icons.add), label: const Text('New')) : null,
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: Wrap(spacing: 8, children: [
          for (final f in ['upcoming', 'overdue', 'completed', 'cancelled'])
            ChoiceChip(label: Text(f), selected: _f == f, onSelected: (_) => setState(() => _f = f)),
        ])),
        Expanded(child: StreamBuilder<Snap>(
          stream: repo.appointments(u.organizationId),
          builder: (c, s) {
            if (s.hasError) return Center(child: Text('Error: ${s.error}'));
            if (!s.hasData) return const Center(child: CircularProgressIndicator());
            final now = DateTime.now();
            final docs = s.data!.docs.where((d) {
              final st = d['status'], t = (d['dateTime'] as Timestamp).toDate();
              return switch (_f) {
                'upcoming' => st == 'scheduled' && !t.isBefore(now),
                'overdue' => st == 'scheduled' && t.isBefore(now),
                _ => st == _f,
              };
            }).toList();
            if (docs.isEmpty) return const Center(child: Text('No appointments.'));
            return ListView(children: [for (final d in docs) GlassCard(blur: false, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4), child: ListTile(
              title: Text('${d['patientName']} · ${d['patientId']}'),
              subtitle: Text('${_fmt.format((d['dateTime'] as Timestamp).toDate())}\n${d['reason'] ?? ''}'),
              isThreeLine: true,
              trailing: (can && d['status'] == 'scheduled') ? Wrap(children: [
                IconButton(tooltip: 'Reschedule', icon: const Icon(Icons.edit_calendar), onPressed: () async {
                  final w = await _pick((d['dateTime'] as Timestamp).toDate());
                  if (w != null) await repo.updateAppointment(d.id, {'dateTime': Timestamp.fromDate(w), 'reminded24': false, 'reminded2': false});
                }),
                IconButton(tooltip: 'Complete', icon: const Icon(Icons.check_circle), onPressed: () => repo.updateAppointment(d.id, {'status': 'completed'})),
                IconButton(tooltip: 'Cancel', icon: const Icon(Icons.cancel), onPressed: () => repo.updateAppointment(d.id, {'status': 'cancelled'})),
              ]) : null,
            ))]);
          },
        )),
      ]),
    );
  }
}
