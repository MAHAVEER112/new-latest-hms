import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../core/constants/roles.dart';
import '../../core/glass.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/clinic_repository.dart';
import '../consult/consultation_page.dart';
import '../lab/lab_screens.dart';

/// Two queues: General, and Lab (patients sent for tests with a waiting time).
/// While lab patients wait, the doctor keeps calling the general queue.
class QueueScreen extends StatefulWidget {
  const QueueScreen({super.key});
  @override
  State<QueueScreen> createState() => _QueueScreenState();
}

class _QueueScreenState extends State<QueueScreen> {
  int _view = 0;
  Stream<Snap>? _s;

  String _wait(Timestamp? t) => t == null ? '-' : '${DateTime.now().difference(t.toDate()).inMinutes} min';

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<ClinicRepository>();
    final isDoctor = u.role == UserRole.doctor;
    _s ??= repo.queue(u.organizationId);
    return StreamBuilder<Snap>(
      stream: _s,
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        final all = s.data!.docs;
        final lab = all.where((d) => d['status'] == 'in_lab').toList();
        final general = all.where((d) => d['status'] != 'in_lab').toList();
        final waiting = general.where((d) => d['status'] == 'waiting').toList();

        Future<void> set(String id, String st) async {
          try { await repo.setQueueStatus(id, st, u.uid); } catch (e) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$e'))); }
        }

        Widget generalTile(Rec d) {
          final st = '${d['status']}';
          final id = d.id;
          final fromLab = d['labOrderId'] != null;
          final actions = <Widget>[];
          if (isDoctor) {
            if (st == 'waiting') {
              actions..add(TextButton(onPressed: () => set(id, 'called'), child: const Text('Call')))..add(TextButton(onPressed: () => set(id, 'skipped'), child: const Text('Skip')));
            } else if (st == 'called') {
              actions..add(TextButton(onPressed: () => set(id, 'called'), child: const Text('Recall')))..add(FilledButton(onPressed: () => set(id, 'in_consultation'), child: const Text('Start')));
            } else if (st == 'in_consultation') {
              actions
                ..add(FilledButton(
                  onPressed: () => Navigator.of(c).push(MaterialPageRoute(builder: (_) => ConsultationPage(queueId: id, patientDocId: '${d['patientDocId']}', patientName: '${d['patientName']}'))),
                  child: const Text('Consult')))
                ..add(TextButton(onPressed: () => set(id, 'completed'), child: const Text('Complete')));
              if (fromLab) {
                actions.insert(0, TextButton(
                  onPressed: () => Navigator.of(c).push(MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Lab reports')), body: const ReviewsScreen()))),
                  child: const Text('Reports')));
              }
            } else if (st == 'skipped') {
              actions.add(TextButton(onPressed: () => set(id, 'waiting'), child: const Text('Requeue')));
            }
          }
          return GlassCard(
            blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12),
            child: Row(children: [
              CircleAvatar(backgroundColor: const Color(0xFF6D4CFF), foregroundColor: Colors.white, child: Text('${d['tokenNumber']}')),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('${d['patientId']} · ${st.replaceAll('_', ' ')}${fromLab ? ' · back from lab' : ''} · ${_wait(d['checkedInAt'] as Timestamp?)}'),
              ])),
              Wrap(spacing: 2, children: actions),
            ]),
          );
        }

        Widget labTile(Rec d) {
          final ready = d['labReady'] == 1;
          final by = (d['labReadyBy'] as Timestamp?)?.toDate();
          final mins = by?.difference(DateTime.now()).inMinutes;
          final info = ready
              ? 'Report ready'
              : by == null ? 'In lab' : mins! > 0 ? 'Back by ${DateFormat('HH:mm').format(by)} (${mins} min left)' : 'Overdue by ${-mins} min';
          return GlassCard(
            blur: false, margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(12),
            child: Row(children: [
              CircleAvatar(backgroundColor: ready ? const Color(0xFF34C38F) : const Color(0xFF38BDF8), foregroundColor: Colors.white, child: Text('${d['tokenNumber']}')),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${d['patientName']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                Text('${d['patientId']}'),
                Text(info, style: TextStyle(color: ready ? const Color(0xFF1B9E6E) : Colors.black54, fontWeight: ready ? FontWeight.w700 : FontWeight.w400)),
              ])),
              if (isDoctor) FilledButton(onPressed: () => set(d.id, 'called'), child: const Text('Call back')),
            ]),
          );
        }

        return ListView(padding: const EdgeInsets.all(16), children: [
          SegmentedButton<int>(
            segments: [ButtonSegment(value: 0, label: Text('General (${general.length})')), ButtonSegment(value: 1, label: Text('Lab (${lab.length})'))],
            selected: {_view}, onSelectionChanged: (v) => setState(() => _view = v.first)),
          const SizedBox(height: 14),
          if (_view == 0) ...[
            if (isDoctor)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Align(alignment: Alignment.centerLeft, child: FilledButton.icon(
                  onPressed: waiting.isEmpty ? null : () => set(waiting.first.id, 'called'),
                  icon: const Icon(Icons.campaign), label: Text('Call next (${waiting.length} waiting)'))),
              ),
            if (general.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(24), child: Text("No patients in today's general queue."))),
            for (final d in general) generalTile(d),
          ] else ...[
            const Padding(padding: EdgeInsets.only(bottom: 10), child: Text('Patients sent for lab tests. While they wait, keep calling the general queue.')),
            if (lab.isEmpty) const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Nobody is in the lab queue.'))),
            for (final d in lab) labTile(d),
          ],
        ]);
      },
    );
  }
}
