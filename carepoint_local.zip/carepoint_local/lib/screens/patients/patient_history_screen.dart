import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../repositories/clinical_repository.dart';
import '../lab/lab_screens.dart';

/// Every saved visit of one patient: complaint, vitals, diagnosis, medicines, lab results with PDFs.
class PatientHistoryScreen extends StatefulWidget {
  const PatientHistoryScreen({super.key, required this.patientDocId, required this.name});
  final String patientDocId, name;
  @override
  State<PatientHistoryScreen> createState() => _PatientHistoryScreenState();
}

class _PatientHistoryScreenState extends State<PatientHistoryScreen> {
  Future<Map<String, dynamic>>? _f;

  Widget _line(String label, Object? v) {
    final s = '${v ?? ''}'.trim();
    if (s.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Text.rich(TextSpan(children: [TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.w700)), TextSpan(text: s)])),
    );
  }

  String _vitals(Map v) {
    const names = {'bp': 'BP', 'pulse': 'Pulse', 'temp': 'Temp', 'height': 'Height', 'weight': 'Weight', 'spo2': 'SpO2'};
    return [for (final e in names.entries) if ('${v[e.key] ?? ''}'.isNotEmpty) '${e.value} ${v[e.key]}'].join('  ·  ');
  }

  @override
  Widget build(BuildContext context) {
    _f ??= context.read<ClinicalRepository>().history(widget.patientDocId);
    return Scaffold(
      appBar: AppBar(title: Text(widget.name)),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _f,
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          final p = Map<String, dynamic>.from(s.data!['patient']);
          final visits = (s.data!['visits'] as List).cast<Map>();
          final allergies = '${p['allergies'] ?? ''}'.trim();
          return ListView(padding: const EdgeInsets.all(16), children: [
            GlassCard(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${p['name']}', style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                Text('${p['patientId']} · ${p['age']} yrs · ${p['gender']} · ${p['phone']}'),
                if (allergies.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Allergies: $allergies', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700))),
              ]),
            ),
            const SizedBox(height: 12),
            Text('${visits.length} ${visits.length == 1 ? 'visit' : 'visits'}', style: Theme.of(c).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (visits.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('No visits recorded yet.'))),
            for (final v in visits)
              GlassCard(
                blur: false, margin: const EdgeInsets.only(bottom: 10),
                child: ExpansionTile(
                  shape: const Border(), collapsedShape: const Border(),
                  title: Text(DateFormat('d MMM y, HH:mm').format(DateTime.parse('${v['date']}').toLocal()), style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${v['diagnosis'] ?? ''}'),
                  childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                  expandedCrossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _line('Complaint', v['complaint']),
                    _line('Symptoms', v['symptoms']),
                    _line('Vitals', _vitals((v['vitals'] as Map?) ?? {})),
                    _line('Observations', v['observations']),
                    _line('Diagnosis', v['diagnosis']),
                    _line('Notes', v['notes']),
                    _line('Treatment plan', v['plan']),
                    if ((v['meds'] as List).isNotEmpty) ...[
                      const Text('Medicines', style: TextStyle(fontWeight: FontWeight.w700)),
                      for (final m in (v['meds'] as List))
                        Text('• ${m['name']} ${m['dosage']} · ${m['frequency']} · ${m['timing']} · ${m['food']} · ${m['duration']} · qty ${m['quantity']}'),
                      const SizedBox(height: 6),
                    ],
                    if ((v['labs'] as List).isNotEmpty) ...[
                      const Text('Lab tests', style: TextStyle(fontWeight: FontWeight.w700)),
                      for (final l in (v['labs'] as List))
                        Row(children: [
                          Expanded(child: Text('• ${l['test']} (${l['status']})${'${l['notes'] ?? ''}'.isEmpty ? '' : ' - ${l['notes']}'}')),
                          if (l['hasReport'] == true) TextButton.icon(icon: const Icon(Icons.picture_as_pdf, size: 18), label: const Text('PDF'), onPressed: () => openReport(c, '${l['id']}')),
                        ]),
                    ],
                    if (v['review'] != null) ...[
                      const SizedBox(height: 6),
                      _line('Doctor review', (v['review'] as Map)['interpretation']),
                      _line('Review comments', (v['review'] as Map)['comments']),
                    ],
                  ],
                ),
              ),
          ]);
        },
      ),
    );
  }
}
