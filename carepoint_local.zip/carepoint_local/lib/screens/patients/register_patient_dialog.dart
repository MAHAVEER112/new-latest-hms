import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/clinic_repository.dart';

/// Register-patient pop-up used by the dashboard button and the Patients screen. Returns true if a patient was added.
Future<bool> showRegisterPatientDialog(BuildContext context) async {
  final u = context.read<AuthProvider>().user!;
  final repo = context.read<ClinicRepository>();
  final messenger = ScaffoldMessenger.of(context);
  final key = GlobalKey<FormState>();
  final name = TextEditingController(), phone = TextEditingController(), age = TextEditingController(), allergies = TextEditingController();
  String gender = 'Female';
  final ok = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: const Text('Register patient'),
        content: Form(
          key: key,
          child: SingleChildScrollView(
            child: SizedBox(
              width: 380,
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => (v ?? '').trim().length < 2 ? 'Required' : null),
                const SizedBox(height: 10),
                TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone'), validator: (v) => (v ?? '').trim().length < 7 ? 'Enter a valid phone' : null),
                const SizedBox(height: 10),
                TextFormField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Age'), validator: (v) { final n = int.tryParse(v ?? ''); return (n == null || n < 0 || n > 120) ? 'Age 0-120' : null; }),
                const SizedBox(height: 10),
                DropdownButtonFormField<String>(
                  value: gender, decoration: const InputDecoration(labelText: 'Gender'),
                  items: const ['Female', 'Male', 'Other'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                  onChanged: (v) => set(() => gender = v!)),
                const SizedBox(height: 10),
                TextFormField(controller: allergies, decoration: const InputDecoration(labelText: 'Allergies (optional)')),
              ]),
            ),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () { if (key.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('Register')),
        ],
      ),
    ),
  );
  if (ok != true) return false;
  try {
    final pid = await repo.registerPatient(org: u.organizationId, uid: u.uid, name: name.text, phone: phone.text, gender: gender, age: int.parse(age.text), allergies: allergies.text);
    messenger.showSnackBar(SnackBar(content: Text('Registered. Patient ID: $pid')));
    return true;
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text('Registration failed: $e')));
    return false;
  }
}
