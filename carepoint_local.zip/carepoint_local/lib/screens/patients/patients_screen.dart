import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/roles.dart';
import '../../core/compat.dart';
import '../../providers/auth_provider.dart';
import 'patient_history_screen.dart';
import '../../repositories/clinic_repository.dart';

class PatientsScreen extends StatefulWidget {
  const PatientsScreen({super.key});
  @override
  State<PatientsScreen> createState() => _PatientsScreenState();
}

class _PatientsScreenState extends State<PatientsScreen> {
  final _q = TextEditingController();
  Future<List<Doc>>? _future;

  void _search() {
    final u = context.read<AuthProvider>().user!;
    setState(() => _future = context.read<ClinicRepository>().searchPatients(u.organizationId, _q.text));
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _search());
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  void _snack(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<void> _register() async {
    final u = context.read<AuthProvider>().user!;
    final repo = context.read<ClinicRepository>();
    final key = GlobalKey<FormState>();
    final name = TextEditingController(), phone = TextEditingController(), age = TextEditingController(), allergies = TextEditingController();
    String gender = 'Female';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Register patient'),
          content: Form(
            key: key,
            child: SingleChildScrollView(
              child: SizedBox(
                width: 380,
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  TextFormField(controller: name, decoration: const InputDecoration(labelText: 'Full name'), validator: (v) => (v ?? '').trim().length < 2 ? 'Required' : null),
                  const SizedBox(height: 10),
                  TextFormField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone'), validator: (v) => (v ?? '').trim().length < 7 ? 'Enter a valid phone' : null),
                  const SizedBox(height: 10),
                  TextFormField(controller: age, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Age'), validator: (v) { final n = int.tryParse(v ?? ''); return (n == null || n < 0 || n > 120) ? 'Age 0-120' : null; }),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(value: gender, decoration: const InputDecoration(labelText: 'Gender'),
                      items: const ['Female', 'Male', 'Other'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                      onChanged: (v) => set(() => gender = v!)),
                  const SizedBox(height: 10),
                  TextFormField(controller: allergies, decoration: const InputDecoration(labelText: 'Allergies (optional)')),
                ]),
              ),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
            FilledButton(onPressed: () { if (key.currentState!.validate()) Navigator.pop(ctx, true); }, child: const Text('Register')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    try {
      final pid = await repo.registerPatient(org: u.organizationId, uid: u.uid, name: name.text, phone: phone.text,
          gender: gender, age: int.parse(age.text), allergies: allergies.text);
      _snack('Registered. Patient ID: $pid');
      _search();
    } catch (e) {
      _snack('Registration failed: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final canRegister = u.role == UserRole.receptionist || u.role == UserRole.doctor;
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: canRegister ? FloatingActionButton.extended(onPressed: _register, icon: const Icon(Icons.person_add), label: const Text('Register')) : null,
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: TextField(
            controller: _q,
            onSubmitted: (_) => _search(),
            decoration: InputDecoration(labelText: 'Search by name', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: _search)),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Doc>>(
            future: _future,
            builder: (c, s) {
              if (s.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
              if (s.hasError) return Center(child: Text('Error: ${s.error}'));
              final docs = s.data ?? [];
              if (docs.isEmpty) return const Center(child: Text('No patients found.'));
              return ListView.builder(
                itemCount: docs.length,
                itemBuilder: (c, i) {
                  final d = docs[i].data();
                  return ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(d['name'] ?? ''),
                    subtitle: Text('${d['patientId']} · ${d['age']} · ${d['gender']} · ${d['phone']}'
                        '${(d['allergies'] ?? '').toString().isNotEmpty ? '\nAllergies: ${d['allergies']}' : ''}'),
                    isThreeLine: (d['allergies'] ?? '').toString().isNotEmpty,
                    onTap: u.role == UserRole.doctor ? () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PatientHistoryScreen(patientDocId: docs[i].id, name: '${d['name']}'))) : null,
                    trailing: u.role == UserRole.receptionist
                        ? FilledButton.tonal(
                            onPressed: () async {
                              try {
                                final t = await context.read<ClinicRepository>().checkIn(org: u.organizationId, uid: u.uid,
                                    patientDocId: docs[i].id, patientName: d['name'], patientId: d['patientId']);
                                _snack('Checked in. Token #$t');
                              } catch (e) {
                                _snack('Check-in failed: $e');
                              }
                            },
                            child: const Text('Check in'))
                        : null,
                  );
                },
              );
            },
          ),
        ),
      ]),
    );
  }
}
