import 'package:flutter/material.dart';
import '../../core/glass.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/compat.dart';
import '../../providers/auth_provider.dart';
import '../../repositories/ops_repository.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: context.read<OpsRepository>().stats(),
        builder: (c, s) {
          if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          return GridView.extent(maxCrossAxisExtent: 240, padding: const EdgeInsets.all(16), mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.5, children: [
            for (final e in s.data!) GlassCard(blur: false, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text('${e['value']}', style: Theme.of(c).textTheme.headlineMedium),
              Text('${e['label']}'),
            ]))),
          ]);
        },
      );
}

class StaffScreen extends StatelessWidget {
  const StaffScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    final repo = context.read<OpsRepository>();
    return StreamBuilder<Snap>(
      stream: repo.staff(u.organizationId),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        return ListView(children: [for (final d in s.data!.docs) ListTile(
          leading: const CircleAvatar(child: Icon(Icons.badge)),
          title: Text('${d['displayName'] ?? d['email']}'),
          subtitle: Text('${d['email']} · ${d['role']}'),
          trailing: d.id == u.uid ? const Text('You') : Switch(value: d['active'] == true, onChanged: (v) async {
            try { await repo.setStaffActive(d.id, v); } catch (e) { if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$e'))); }
          }),
        )]);
      },
    );
  }
}

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: context.read<OpsRepository>().revenue(),
        builder: (c, s) {
          if (s.hasError) return Center(child: Text('${s.error}'));
          if (!s.hasData) return const Center(child: CircularProgressIndicator());
          return Center(child: GlassCard(blur: false, child: Padding(padding: const EdgeInsets.all(32), child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Pharmacy revenue (paid invoices)', style: Theme.of(c).textTheme.titleMedium),
            Text((s.data!['total'] as num).toStringAsFixed(2), style: Theme.of(c).textTheme.displaySmall),
            Text('${s.data!['count']} paid invoices'),
          ]))));
        },
      );
}

class AuditScreen extends StatelessWidget {
  const AuditScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final u = context.watch<AuthProvider>().user!;
    return StreamBuilder<Snap>(
      stream: context.read<OpsRepository>().audit(u.organizationId),
      builder: (c, s) {
        if (s.hasError && !s.hasData) return Center(child: Text('${s.error}'));
        if (!s.hasData) return const Center(child: CircularProgressIndicator());
        if (s.data!.docs.isEmpty) return const Center(child: Text('No audit entries.'));
        return ListView(children: [for (final d in s.data!.docs) ListTile(
          title: Text('${d['action']}'),
          subtitle: Text('${d['actorName'] ?? d['actorUid']} · ${DateFormat('d MMM HH:mm').format((d['createdAt'] as Timestamp).toDate())}'),
        )]);
      },
    );
  }
}
