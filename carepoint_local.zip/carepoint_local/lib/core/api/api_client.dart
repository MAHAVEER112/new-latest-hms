import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../compat.dart';

class ApiException implements Exception {
  ApiException(this.message, [this.status]);
  final String message;
  final int? status;
  @override
  String toString() => message;
}

/// Talks to the doctor's phone (127.0.0.1 on the doctor's own phone, the doctor's Wi-Fi address on staff phones).
/// GET results are saved on this phone, so a department still sees its last data if the doctor's phone is unreachable.
class Api {
  Api._();
  static final i = Api._();
  static String base = 'http://127.0.0.1:8080';
  String? token, mode;
  void Function()? onUnauthorized;
  final offline = ValueNotifier<bool>(false);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    token = p.getString('cp_token');
    mode = p.getString('cp_mode');
    final host = p.getString('cp_host');
    if (mode == 'client' && host != null) base = 'http://$host:8080';
  }

  Future<void> setMode(String m, {String? host}) async {
    final p = await SharedPreferences.getInstance();
    mode = m;
    await p.setString('cp_mode', m);
    host == null ? await p.remove('cp_host') : await p.setString('cp_host', host);
    base = m == 'host' ? 'http://127.0.0.1:8080' : 'http://$host:8080';
    await _clearCache(p);
  }

  void useHost(String host) => base = 'http://$host:8080';

  Future<void> reset() async {
    final p = await SharedPreferences.getInstance();
    await p.remove('cp_mode'); await p.remove('cp_host'); await p.remove('cp_token');
    mode = null; token = null;
    await _clearCache(p);
  }

  Future<void> _clearCache(SharedPreferences p) async {
    for (final k in p.getKeys().where((k) => k.startsWith('cache:')).toList()) { await p.remove(k); }
  }

  Future<void> setToken(String? t) async {
    token = t;
    final p = await SharedPreferences.getInstance();
    if (t == null) { await p.remove('cp_token'); await _clearCache(p); } else { await p.setString('cp_token', t); }
  }

  Future<dynamic> _send(String m, String path, [Object? body, Duration? timeout]) async {
    final req = http.Request(m, Uri.parse('$base$path'))..headers['Content-Type'] = 'application/json';
    if (token != null) req.headers['Authorization'] = 'Bearer $token';
    if (body != null) req.body = jsonEncode(body, toEncodable: (o) => o is Timestamp ? o.toIso() : o);
    http.Response res;
    try {
      res = await http.Response.fromStream(await req.send().timeout(timeout ?? const Duration(seconds: 8)));
    } catch (_) {
      throw ApiException("Cannot reach the doctor's phone. Check Wi-Fi and that the doctor's app is open.");
    }
    final data = res.body.isEmpty ? null : jsonDecode(res.body);
    if (res.statusCode == 401 && token != null && path != '/auth/login') { await setToken(null); onUnauthorized?.call(); }
    if (res.statusCode >= 400) throw ApiException((data is Map ? data['error'] : null) ?? 'Request failed (${res.statusCode})', res.statusCode);
    return data;
  }

  Future<dynamic> get(String path) async {
    try {
      final d = await _send('GET', path);
      offline.value = false;
      (await SharedPreferences.getInstance()).setString('cache:$path', jsonEncode(d));
      return d;
    } on ApiException catch (e) {
      if (e.status == null) {
        final c = (await SharedPreferences.getInstance()).getString('cache:$path');
        if (c != null) { offline.value = true; return jsonDecode(c); }
      }
      rethrow;
    }
  }

  Future<dynamic> post(String p, [Object? b, Duration? t]) => _send('POST', p, b ?? {}, t);
  Future<dynamic> patch(String p, Object b) => _send('PATCH', p, b);

  Future<List<int>> getBytes(String path) async {
    final req = http.Request('GET', Uri.parse('$base$path'));
    if (token != null) req.headers['Authorization'] = 'Bearer $token';
    try {
      final res = await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 60)));
      if (res.statusCode >= 400) throw ApiException('Report not available', res.statusCode);
      return res.bodyBytes;
    } on ApiException {
      rethrow;
    } catch (_) {
      throw ApiException("Cannot reach the doctor's phone.");
    }
  }
}
