import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

enum QrKind { wifi, host, staffId, unknown }

class QrResult {
  const QrResult(this.kind, {this.a = '', this.b = ''});
  final QrKind kind;

  /// wifi: network name, password · host: address · staffId: the ID
  final String a, b;
}

Map<String, String> _wifiFields(String body) {
  final out = <String, String>{};
  final cur = StringBuffer();
  void flush() {
    final part = cur.toString();
    cur.clear();
    final i = part.indexOf(':');
    if (i > 0) out[part.substring(0, i).toUpperCase()] = part.substring(i + 1);
  }
  for (var i = 0; i < body.length; i++) {
    final ch = body[i];
    if (ch == r'\' && i + 1 < body.length) {
      cur.write(body[++i]);
    } else if (ch == ';') {
      flush();
    } else {
      cur.write(ch);
    }
  }
  if (cur.isNotEmpty) flush();
  return out;
}

/// Understands every CarePoint QR: Wi-Fi code, doctor phone address / web page link, or a staff ID.
QrResult parseQr(String raw) {
  final v = raw.trim();
  if (v.toUpperCase().startsWith('WIFI:')) {
    final f = _wifiFields(v.substring(5));
    final ssid = f['S'] ?? '';
    if (ssid.isNotEmpty) return QrResult(QrKind.wifi, a: ssid, b: f['P'] ?? '');
  }
  final lower = v.toLowerCase();
  final ip = RegExp(r'(\d{1,3}(?:\.\d{1,3}){3})').firstMatch(v);
  if (ip != null && (lower.startsWith('carepoint://') || lower.startsWith('http') || RegExp(r'^\d{1,3}(\.\d{1,3}){3}(:\d+)?$').hasMatch(v))) {
    return QrResult(QrKind.host, a: ip.group(1)!);
  }
  final id = v.toUpperCase();
  if (RegExp(r'^[A-Z]{3,6}-\d{6}$').hasMatch(id)) return QrResult(QrKind.staffId, a: id);
  return const QrResult(QrKind.unknown);
}

/// Text inside a Wi-Fi QR: staff phones (and the phone camera) can join the network by scanning it.
String wifiQrData(String ssid, String pass) {
  String esc(String s) => s.replaceAllMapped(RegExp(r'([\\;,:"])'), (m) => '\\${m[1]}');
  return pass.isEmpty ? 'WIFI:T:nopass;S:${esc(ssid)};;' : 'WIFI:T:WPA;S:${esc(ssid)};P:${esc(pass)};;';
}

Future<void> showWifiJoinDialog(BuildContext context, String ssid, String password) => showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Join this Wi-Fi'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Network', style: TextStyle(fontSize: 12, color: Colors.black54)),
          SelectableText(ssid, style: Theme.of(ctx).textTheme.titleLarge),
          if (password.isNotEmpty) ...[
            const SizedBox(height: 10),
            const Text('Password', style: TextStyle(fontSize: 12, color: Colors.black54)),
            SelectableText(password, style: Theme.of(ctx).textTheme.titleLarge),
          ],
          const SizedBox(height: 12),
          const Text("Open this phone's Wi-Fi settings, choose the network and enter the password. Then come back and sign in. (The phone's own camera app can also join this QR in one tap.)"),
        ]),
        actions: [
          if (password.isNotEmpty) TextButton(onPressed: () => Clipboard.setData(ClipboardData(text: password)), child: const Text('Copy password')),
          FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Done')),
        ],
      ),
    );
