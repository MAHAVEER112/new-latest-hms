import 'dart:ui';
import 'package:flutter/material.dart';

/// Pearl background with pastel pink, lavender and aqua glows behind the glass.
class AppBackground extends StatelessWidget {
  const AppBackground({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF3F8FF), Color(0xFFEAF3FE), Color(0xFFF4F9FF)]),
          ),
        ),
        const Positioned(top: -90, left: -90, child: _Orb(320, Color(0xFFBFDBFE))),
        const Positioned(top: 230, right: -140, child: _Orb(340, Color(0xFF93C5FD))),
        const Positioned(bottom: -120, left: -50, child: _Orb(320, Color(0xFFBAE6FD))),
        child,
      ]);
}

class _Orb extends StatelessWidget {
  const _Orb(this.size, this.color);
  final double size;
  final Color color;
  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: Container(
          width: size, height: size,
          decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [color.withAlpha(115), color.withAlpha(0)])),
        ),
      );
}

/// Liquid-glass panel: frosted blur, bright rim, top gloss and a soft shadow falling to the lower right.
class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.margin, this.padding, this.blur = true, this.radius = 26, this.tint, this.gradient});
  final Widget child;
  final EdgeInsetsGeometry? margin, padding;
  final bool blur;
  final double radius;
  final Color? tint;
  final List<Color>? gradient;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    final c = tint ?? Colors.white;
    Widget body = Container(
      padding: padding,
      foregroundDecoration: BoxDecoration(
        borderRadius: r,
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0x40FFFFFF), Color(0x00FFFFFF)], stops: [0, .4]),
      ),
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: gradient ?? [c.withAlpha(blur ? 170 : 195), c.withAlpha(blur ? 80 : 120)]),
        border: Border.all(color: Colors.white.withAlpha(215), width: 1.4),
      ),
      child: child,
    );
    if (blur) body = ClipRRect(borderRadius: r, child: BackdropFilter(filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16), child: body));
    return Container(
      margin: margin,
      decoration: BoxDecoration(borderRadius: r, boxShadow: const [
        BoxShadow(color: Color(0x334A78B8), blurRadius: 28, offset: Offset(8, 14)),
        BoxShadow(color: Color(0xCCFFFFFF), blurRadius: 8, offset: Offset(-3, -3)),
      ]),
      child: body,
    );
  }
}

/// Glossy glass-ball icon with a coloured glow.
class IconBubble extends StatelessWidget {
  const IconBubble({super.key, required this.icon, required this.color, this.size = 46});
  final IconData icon;
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(color, Colors.white, .4)!, color]),
          border: Border.all(color: Colors.white.withAlpha(170), width: 1.2),
          boxShadow: [BoxShadow(color: color.withAlpha(120), blurRadius: 14, offset: const Offset(0, 8))],
        ),
        child: Icon(icon, color: Colors.white, size: size * .52),
      );
}
