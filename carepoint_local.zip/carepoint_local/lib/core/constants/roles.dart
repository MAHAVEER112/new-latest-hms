import 'package:flutter/material.dart';

class NavItem {
  final String label;
  final IconData icon;
  final String path;
  const NavItem(this.label, this.icon, this.path);
}

enum UserRole {
  doctor('doctor', 'Doctor'),
  admin('admin', 'Hospital Admin'),
  receptionist('receptionist', 'Receptionist'),
  labTechnician('lab_technician', 'Lab'),
  labVerifier('lab_verifier', 'Lab Verifier'),
  pharmacy('pharmacy', 'Pharmacy Staff');

  final String value;
  final String label;
  const UserRole(this.value, this.label);

  static UserRole? parse(String? v) {
    for (final r in UserRole.values) {
      if (r.value == v) return r;
    }
    return null;
  }

  List<NavItem> get navItems => switch (this) {
        UserRole.doctor => const [
            NavItem('Dashboard', Icons.dashboard, 'dashboard'),
            NavItem('Queue', Icons.people_alt, 'queue'),
            NavItem('Patients', Icons.folder_shared, 'patients'),
            NavItem('Appointments', Icons.event, 'appointments'),
            NavItem('Payments', Icons.payments_rounded, 'payments'),
            NavItem('Lab Reports', Icons.biotech, 'reviews'),
            NavItem('Staff & Codes', Icons.vpn_key, 'staff'),
          ],
        UserRole.admin => const [
            NavItem('Dashboard', Icons.dashboard, 'dashboard'),
            NavItem('Staff', Icons.badge, 'staff'),
            NavItem('Invites', Icons.person_add, 'invites'),
            NavItem('Reports', Icons.bar_chart, 'reports'),
            NavItem('Audit Log', Icons.shield, 'audit'),
          ],
        UserRole.receptionist => const [
            NavItem('Dashboard', Icons.dashboard, 'dashboard'),
            NavItem('Patients', Icons.folder_shared, 'patients'),
            NavItem('Appointments', Icons.event, 'appointments'),
            NavItem('Queue', Icons.people_alt, 'queue'),
                      NavItem('Payments', Icons.payments_rounded, 'payments'),
          ],
        UserRole.labTechnician => const [
            NavItem('Lab Queue', Icons.science, 'samples'),
          ],
        UserRole.labVerifier => const [
            NavItem('Verification', Icons.verified, 'verification'),
            NavItem('History', Icons.history, 'history'),
          ],
        UserRole.pharmacy => const [
            NavItem('Prescriptions', Icons.medication, 'prescriptions'),
            NavItem('Inventory', Icons.inventory_2, 'inventory'),
            NavItem('Invoices', Icons.receipt_long, 'invoices'),
          ],
      };
}
