import 'package:flutter/material.dart';

class NavItem {
  final String label;
  final IconData icon;
  final String path;
  const NavItem(this.label, this.icon, this.path);
}

enum UserRole {
  doctor('doctor', 'Doctor'),
  admin('admin', 'Hospital Admin'),
  receptionist('receptionist', 'Receptionist'),
  labTechnician('lab_technician', 'Lab'),
  labVerifier('lab_verifier', 'Lab Verifier'),
  pharmacy('pharmacy', 'Pharmacy Staff');

  final String value;
  final String label;
  const UserRole(this.value, this.label);

  static UserRole? parse(String? v) {
    for (final r in UserRole.values) {
      if (r.value == v) return r;
    }
    return null;
  }

  List<NavItem> get navItems => switch (this) {
        UserRole.doctor => const [
            NavItem('Dashboard', Icons.home_rounded, 'dashboard'),
            NavItem('Queue', Icons.person_outline_rounded, 'queue'),
            NavItem('Patients', Icons.badge_outlined, 'patients'),
            NavItem('Appointments', Icons.calendar_month_outlined, 'appointments'),
            NavItem('Payments', Icons.credit_card_rounded, 'payments'),
            NavItem('Lab Reports', Icons.biotech, 'reviews'),
            NavItem('Staff & Codes', Icons.vpn_key, 'staff'),
          ],
        UserRole.admin => const [
            NavItem('Dashboard', Icons.home_rounded, 'dashboard'),
            NavItem('Staff', Icons.badge, 'staff'),
            NavItem('Invites', Icons.person_add, 'invites'),
            NavItem('Reports', Icons.bar_chart, 'reports'),
            NavItem('Audit Log', Icons.shield, 'audit'),
          ],
        UserRole.receptionist => const [
            NavItem('Dashboard', Icons.home_rounded, 'dashboard'),
            NavItem('Patients', Icons.badge_outlined, 'patients'),
            NavItem('Appointments', Icons.calendar_month_outlined, 'appointments'),
            NavItem('Queue', Icons.person_outline_rounded, 'queue'),
                      NavItem('Payments', Icons.credit_card_rounded, 'payments'),
          ],
        UserRole.labTechnician => const [
            NavItem('Lab Queue', Icons.science, 'samples'),
          ],
        UserRole.labVerifier => const [
            NavItem('Verification', Icons.verified, 'verification'),
            NavItem('History', Icons.history, 'history'),
          ],
        UserRole.pharmacy => const [
            NavItem('Prescriptions', Icons.medication, 'prescriptions'),
            NavItem('Inventory', Icons.inventory_2, 'inventory'),
            NavItem('Invoices', Icons.receipt_long, 'invoices'),
          ],
      };
}
