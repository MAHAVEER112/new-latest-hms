import 'dart:ui';
import 'package:flutter/material.dart';

class NavEntry {
  const NavEntry(this.icon, this.label);
  final IconData icon;
  final String label;
}

/// Floating glass bottom bar; the selected tab sits in a soft violet pill (as in the design).
class GlassNavBar extends StatelessWidget {
  const GlassNavBar({super.key, required this.items, required this.selected, required this.onTap});
  final List<NavEntry> items;
  final int selected;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    const primary = Color(0xFF0B4A9E);
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 0, 10, 8),
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            boxShadow: const [BoxShadow(color: Color(0x334A78B8), blurRadius: 24, offset: Offset(0, 10))],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
              child: Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(color: Colors.white.withAlpha(200), borderRadius: BorderRadius.circular(30), border: Border.all(color: Colors.white, width: 1.4)),
                child: Row(children: [
                  for (var i = 0; i < items.length; i++)
                    Expanded(
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTap: () => onTap(i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 2),
                          decoration: i == selected
                              ? BoxDecoration(
                                  borderRadius: BorderRadius.circular(24),
                                  gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFE3EEFF), Color(0xFFD3E5FF)]),
                                  boxShadow: const [BoxShadow(color: Color(0x330F62C9), blurRadius: 10, offset: Offset(0, 4))])
                              : null,
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Icon(items[i].icon, size: 24, color: i == selected ? primary : Colors.black54),
                            const SizedBox(height: 2),
                            FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(items[i].label, style: TextStyle(fontSize: 11, fontWeight: i == selected ? FontWeight.w800 : FontWeight.w500, color: i == selected ? primary : Colors.black54)),
                            ),
                          ]),
                        ),
                      ),
                    ),
                ]),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
