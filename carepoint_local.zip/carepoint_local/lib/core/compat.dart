import 'dart:async';

final _iso = RegExp(r'^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$');

class Timestamp implements Comparable<Timestamp> {
  Timestamp.fromDate(DateTime d) : _d = d.toUtc();
  final DateTime _d;
  DateTime toDate() => _d.toLocal();
  String toIso() => _d.toIso8601String();
  @override
  int compareTo(Timestamp o) => _d.compareTo(o._d);
}

/// A record returned by the API. ISO date strings become [Timestamp].
class Rec {
  Rec(Map<String, dynamic> m)
      : _m = {for (final e in m.entries) e.key: (e.value is String && _iso.hasMatch(e.value)) ? Timestamp.fromDate(DateTime.parse(e.value)) : e.value};
  final Map<String, dynamic> _m;
  String get id => _m['id'] as String;
  dynamic operator [](String k) => _m[k];
  Map<String, dynamic> data() => _m;
}

class Snap {
  Snap(this.docs);
  final List<Rec> docs;
}

typedef QS = Snap;
typedef Dc = Rec;
typedef Doc = Rec;

Snap snapOf(dynamic list) => Snap([for (final e in list as List) Rec(Map<String, dynamic>.from(e as Map))]);

/// Live updates by polling the API every few seconds.
/// Each listener gets its own timer, so a screen can switch away from a stream and come back to it
/// (for example the Due / History tabs in Payments) without "Stream has already been listened to".
Stream<T> poll<T>(Future<T> Function() f, {Duration every = const Duration(seconds: 3)}) => Stream<T>.multi((c) {
      var busy = false, done = false;
      Future<void> tick() async {
        if (busy || done) return;
        busy = true;
        try {
          final v = await f();
          if (!done) c.add(v);
        } catch (e) {
          if (!done) c.addError(e);
        } finally {
          busy = false;
        }
      }
      tick();
      final t = Timer.periodic(every, (_) => tick());
      c.onCancel = () { done = true; t.cancel(); };
    });
