import 'package:flutter/material.dart';

/// Liquid-glass look: pearl background, glossy violet pill buttons, frosted pill inputs.
class AppTheme {
  static const primary = Color(0xFF0F62C9);
  static const teal = Color(0xFF2BB7A6);
  static const ink = Color(0xFF0B2A55);

  static ThemeData get light {
    final cs = ColorScheme.fromSeed(seedColor: primary).copyWith(primary: primary, secondary: teal);
    OutlineInputBorder b(Color c, [double w = 1]) => OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: BorderSide(color: c, width: w));
    return ThemeData(
      useMaterial3: true,
      colorScheme: cs,
      scaffoldBackgroundColor: Colors.transparent,
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0, foregroundColor: ink,
        titleTextStyle: TextStyle(color: ink, fontSize: 20, fontWeight: FontWeight.w800),
      ),
      navigationBarTheme: const NavigationBarThemeData(backgroundColor: Color(0xB3FFFFFF), indicatorColor: Color(0x330F62C9), elevation: 0),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xB3FFFFFF),
        contentPadding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
        border: b(const Color(0xCCFFFFFF)), enabledBorder: b(const Color(0xCCFFFFFF)), focusedBorder: b(primary, 1.6),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          foregroundColor: Colors.white, disabledForegroundColor: Colors.white70,
          backgroundColor: Colors.transparent, disabledBackgroundColor: Colors.transparent, shadowColor: Colors.transparent, elevation: 0,
          shape: const StadiumBorder(), padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 15),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
          backgroundBuilder: (context, states, child) {
            final off = states.contains(WidgetState.disabled);
            return DecoratedBox(
              decoration: ShapeDecoration(
                shape: const StadiumBorder(side: BorderSide(color: Color(0x66FFFFFF), width: 1)),
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                    colors: off ? const [Color(0xFFC9C6D6), Color(0xFFB4B0C6)] : const [Color(0xFF4BA3F2), Color(0xFF0F62C9)]),
                shadows: off ? null : const [BoxShadow(color: Color(0x550F62C9), blurRadius: 16, offset: Offset(0, 8))],
              ),
              child: child,
            );
          },
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: ink, backgroundColor: const Color(0x66FFFFFF), shape: const StadiumBorder(),
          side: const BorderSide(color: Color(0xCCFFFFFF), width: 1.4), padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 14),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: primary, foregroundColor: Colors.white, shape: StadiumBorder(), elevation: 6),
      chipTheme: const ChipThemeData(
        shape: StadiumBorder(), side: BorderSide(color: Color(0xCCFFFFFF)),
        backgroundColor: Color(0x80FFFFFF), selectedColor: Color(0x400F62C9),
      ),
      segmentedButtonTheme: SegmentedButtonThemeData(
        style: SegmentedButton.styleFrom(
          backgroundColor: const Color(0x80FFFFFF), selectedBackgroundColor: const Color(0x400F62C9),
          foregroundColor: ink, selectedForegroundColor: ink,
        ),
      ),
      snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating, shape: StadiumBorder(), backgroundColor: Color(0xE60B2A55)),
    );
  }
}
