import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../repositories/ops_repository.dart';

/// Shows the notification list for the signed-in role.
Future<void> showNotificationsDialog(BuildContext c) async {
  try {
    final items = await c.read<OpsRepository>().notifications();
    if (!c.mounted) return;
    await showDialog(
      context: c,
      builder: (ctx) => AlertDialog(
        title: const Text('Notifications'),
        content: SizedBox(
          width: 360,
          child: items.isEmpty
              ? const Text('No notifications.')
              : ListView(shrinkWrap: true, children: [for (final n in items) ListTile(dense: true, title: Text('${n['title']}'), subtitle: Text('${n['body']}'))]),
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
      ),
    );
  } catch (e) {
    if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text('$e')));
  }
}
