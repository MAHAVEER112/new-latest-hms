import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../providers/auth_provider.dart';
import '../screens/auth/login_screen.dart';
import '../screens/setup/setup_screen.dart';
import '../screens/shell/role_shell.dart';

GoRouter buildRouter(AuthProvider auth) => GoRouter(
      initialLocation: '/splash',
      refreshListenable: auth,
      redirect: (context, state) {
        final loc = state.matchedLocation;
        switch (auth.status) {
          case AuthStatus.loading:
            return loc == '/splash' ? null : '/splash';
          case AuthStatus.needsSetup:
            return loc == '/setup' ? null : '/setup';
          case AuthStatus.signedOut:
          case AuthStatus.noAccess:
            return loc == '/login' ? null : '/login';
          case AuthStatus.signedIn:
            final role = auth.user!.role;
            final home = '/app/${role.navItems.first.path}';
            if (!loc.startsWith('/app/')) return home;
            return role.navItems.map((n) => '/app/${n.path}').contains(loc) ? null : home;
        }
      },
      routes: [
        GoRoute(path: '/splash', builder: (_, __) => const Scaffold(body: Center(child: CircularProgressIndicator()))),
        GoRoute(path: '/setup', builder: (_, __) => const SetupScreen()),
        GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
        GoRoute(path: '/app/:section', builder: (_, s) => RoleShell(section: s.pathParameters['section']!)),
      ],
    );
