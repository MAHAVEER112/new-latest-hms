import '../core/constants/roles.dart';

class AppUser {
  final String uid;
  final String email;
  final String? displayName;
  final UserRole role;
  final String organizationId;
  const AppUser({
    required this.uid,
    required this.email,
    required this.role,
    required this.organizationId,
    this.displayName,
  });
}
