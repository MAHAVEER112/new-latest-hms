import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'providers/auth_provider.dart';
import 'repositories/auth_repository.dart';
import 'repositories/clinic_repository.dart';
import 'repositories/clinical_repository.dart';
import 'repositories/ops_repository.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        Provider(create: (_) => AuthRepository()),
        Provider(create: (_) => ClinicRepository()),
        Provider(create: (_) => ClinicalRepository()),
        Provider(create: (_) => OpsRepository()),
        ChangeNotifierProvider(create: (c) => AuthProvider(c.read<AuthRepository>())),
      ],
      child: const CarePointApp(),
    ),
  );
}
