import 'package:flutter/foundation.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../core/api/api_client.dart';
import '../host/backup.dart';
import '../host/server.dart';
import '../models/app_user.dart';
import '../repositories/auth_repository.dart';

enum AuthStatus { loading, needsSetup, signedOut, signedIn, noAccess }

class AuthProvider extends ChangeNotifier {
  AuthProvider(this._repo) {
    Api.i.onUnauthorized = () { user = null; status = AuthStatus.signedOut; notifyListeners(); };
    _init();
  }
  final AuthRepository _repo;
  AuthStatus status = AuthStatus.loading;
  AppUser? user;
  String? error;
  bool busy = false;
  bool get isHost => Api.i.mode == 'host';

  Future<void> _init() async {
    try {
      await Api.i.load();
      if (Api.i.mode == null) { status = AuthStatus.needsSetup; }
      else {
        if (isHost) { await LocalServer.i.start(); await WakelockPlus.enable(); }
        bool setup = true;
        try { setup = (await Api.i.get('/status'))['setup'] == true; } catch (_) {}
        if (isHost && !setup) { status = AuthStatus.needsSetup; }
        else { user = await _repo.restore(); status = user == null ? AuthStatus.signedOut : AuthStatus.signedIn; }
      }
    } catch (e) { error = '$e'; status = AuthStatus.needsSetup; }
    notifyListeners();
  }

  Future<bool> setupHost(String name, String pw) => _run(() async {
        await Api.i.setMode('host');
        await LocalServer.i.start();
        await WakelockPlus.enable();
        await Api.i.post('/setup', {'name': name, 'password': pw});
        user = await _repo.signIn('doctor', pw);
        status = AuthStatus.signedIn;
      });

  Future<bool> setupClient(String ip) => _run(() async {
        final host = ip.trim();
        if (host.isEmpty) throw ApiException("Enter the doctor phone's address");
        Api.i.useHost(host);
        final s = await Api.i.get('/status');
        if (s is! Map || s['app'] != 'carepoint') throw ApiException('That is not a CarePoint doctor phone');
        if (s['setup'] != true) throw ApiException('The doctor has not finished setup yet');
        await Api.i.setMode('client', host: host);
        status = AuthStatus.signedOut;
      });

  /// Replace all data on this phone with a backup file; this phone becomes the doctor's phone.
  Future<bool> restoreBackup(List<int> bytes) => _run(() async {
        final snap = BackupService.parse(bytes);
        if (Api.i.mode != 'host') await Api.i.setMode('host');
        await LocalServer.i.start();
        await BackupService.autoBackup(LocalServer.i.st, tag: '-before-restore');
        await LocalServer.i.st.restore(snap);
        await BackupService.restoreFiles(snap);
        await Api.i.setToken(null);
        await WakelockPlus.enable();
        user = null;
        status = AuthStatus.signedOut;
      });

  Future<bool> signIn(String id, String secret) => _run(() async {
        user = await _repo.signIn(id, secret);
        status = user == null ? AuthStatus.noAccess : AuthStatus.signedIn;
      });

  Future<bool> _run(Future<void> Function() action) async {
    busy = true; error = null; notifyListeners();
    try { await action(); return true; } on ApiException catch (e) { error = e.message; } catch (e) { error = '$e'.replaceFirst('Exception: ', ''); } finally { busy = false; notifyListeners(); }
    return false;
  }

  Future<void> signOut() async { await _repo.signOut(); user = null; status = AuthStatus.signedOut; notifyListeners(); }
  Future<void> changeDoctorPhone() async { await Api.i.reset(); user = null; status = AuthStatus.needsSetup; notifyListeners(); }
}
